/* CourtLine Options navigation; preserved existing update/theme button handlers. */
(() => {
 'use strict';
 const trigger=document.getElementById('optionsButton'),menu=document.getElementById('courtlineOptionsMenu');
 const hiddenUpdates=document.getElementById('checkForUpdates'),hiddenThemes=document.getElementById('themeButton');
 if(!trigger||!menu||!hiddenUpdates||!hiddenThemes)return;
 if(menu.parentNode!==document.body)document.body.appendChild(menu);
 const hint=document.getElementById('courtlineOptionsUpdateHint'),badge=document.getElementById('courtlineUpdateBadge');
 function sync(){hint.hidden=badge.hidden;}
 function close(focus=false){if(menu.hidden)return;menu.hidden=true;trigger.setAttribute('aria-expanded','false');document.body.classList.remove('theme-menu-open');window.dispatchEvent(new Event('courtline-modal-change'));if(focus)trigger.focus();}
 function open(){menu.hidden=false;trigger.setAttribute('aria-expanded','true');document.body.classList.add('theme-menu-open');window.dispatchEvent(new Event('courtline-modal-change'));const r=trigger.getBoundingClientRect();menu.style.left=Math.max(8,Math.min(innerWidth-menu.offsetWidth-8,r.right-menu.offsetWidth))+'px';menu.style.top=Math.max(8,Math.min(innerHeight-menu.offsetHeight-8,r.bottom+6))+'px';sync();}
 trigger.addEventListener('click',e=>{e.stopPropagation();menu.hidden?open():close(true);});
 document.getElementById('courtlineOptionsClose').addEventListener('click',()=>close(true));
 document.getElementById('courtlineOptionsUpdates').addEventListener('click',()=>{close();hiddenUpdates.click();});
 document.getElementById('courtlineOptionsThemes').addEventListener('click',()=>{close();hiddenThemes.click();});
 const pair=document.getElementById('courtlineOptionsPair'),pairStatus=document.getElementById('courtlinePairStatus');
 pair.addEventListener('click',async()=>{
  if(pair.disabled)return;pair.disabled=true;pairStatus.textContent='Opening device enrollment scanner…';close();
  try{const result=await window.pywebview.api.scan_stats_helper();pairStatus.textContent=result===null?'Pairing canceled. Existing connection unchanged.':'Device enrollment handled by the app.';}
  catch(_){pairStatus.textContent='Could not complete pairing. Check Backend Device Management and try again.';open();}
  finally{pair.disabled=false;}
 });
 document.addEventListener('pointerdown' ,e=>{if(!menu.hidden&&!menu.contains(e.target)&&!trigger.contains(e.target))close();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!menu.hidden){e.preventDefault();close(true);}});
 window.addEventListener('resize',()=>close());
 if(badge)new MutationObserver(sync).observe(badge,{attributes:true,attributeFilter:['hidden']});
 sync();
})();
