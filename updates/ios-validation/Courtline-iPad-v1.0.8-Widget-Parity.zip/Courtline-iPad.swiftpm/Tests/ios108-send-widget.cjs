const {JSDOM,ResourceLoader,VirtualConsole}=require('/workspace/scratch/4d9aa462dfa7/android_source/test-tools/node_modules/jsdom');const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const dir=path.resolve(__dirname,'../Web'),clone=x=>JSON.parse(JSON.stringify(x));
const sections={vmix:{revision:'vmix-r1',value:{address:'http://192.0.2.50:8088'}}};
for(let i=0;i<4;i++)for(const [kind,value] of Object.entries({connection:{eventSlot:i,court:i+1,visible:true,remoteURL:'https://app.scoreholio.com/overlay?account=fixture-account&did=device'+i},event:{adminURL:'',name:'Event '+i},exports:{auto:false,seconds:60},matchup:{enabled:false},automation:{dry_run:true,poll_seconds:.5,alarm_delay:5,match_alerts:false,require_matchup_stats:false,rows:[{id:'a'+i,enabled:true,trigger:'Round complete',command:'Function=Cut&Input=2',delay:3,matchup:'singles'}]},telestrator:{source:'Camera '+(i+1),profile:{dry_run:false,rows:[{id:'t'+i,enabled:true,trigger:'Button press',command:'Function=Cut&Input=3',delay:0}]}}}))sections[kind+':'+i]={revision:kind+'-'+i+'-r1',value};
const snapshot=()=>clone({schemaVersion:1,sections,capabilities:{editable:Object.keys(sections),readOnly:[],actions:[],backendOnly:[],unavailable:[]},lock:{enabled:false,revision:''}});
const automation=Array.from({length:4},()=>({running:false,armed:false,status:{},alarms:[],logs:[],dry_run:true}));
let widgetMode=200;let nativePrompts=0;let patches=[],calls=[],errors=[],offline=false,failAuth=false,n=1,holdGet=false,releaseGet=null,unsupported=0,saveWarning=false,rejectPatch=false,dropRestore=false;
class Loader extends ResourceLoader{fetch(url){const file=path.join(dir,new URL(url).pathname.split('/').pop());return fs.existsSync(file)?Promise.resolve(fs.readFileSync(file)):Promise.resolve(Buffer.from(''));}}
const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(fs.readFileSync(path.join(dir,'index.html'),'utf8'),{url:'https://courtline.test/index.html',runScripts:'dangerously',resources:new Loader(),pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
 w.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});w.ResizeObserver=class{observe(){}disconnect(){}};w.confirm=()=>true;w.HTMLElement.prototype.scrollIntoView=function(){};w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new w.Event('close'));};w.fetch=async()=>({ok:true,json:async()=>({})});
 const config={ui:{urls:['','','',''],pairings:[null,null,null,null],visibleCourts:[true,true,true,true],vmixInputs:['local-browser','','',''],telestratorSources:['','','',''],vmixHost:'http://192.0.2.9:8088',scoreholioStats:{helperURL:'http://192.0.2.40:8765/api/stats?key=fixture',auto:false,seconds:10}}};
 w.CourtlineAndroid={unlockSettings:()=>{nativePrompts++;},load:()=>JSON.stringify(config),save:()=>true,dispatch(text){const {method,args}=JSON.parse(text);calls.push({method,args});const [id,url,op,payload]=args;const reply=(value,error)=>setTimeout(()=>w.platformReply(id,value,error),0);
 if(['open','telestrator'].includes(method))return;
 if(method==='sendWidget'){if(widgetMode==='deny')return reply(null,'Control access required');if(widgetMode==='timeout')return reply(null,'Delivery unconfirmed; not retried');if(widgetMode==='malformed')return reply({text:'missing status'});return reply({status:widgetMode,text:'fixture'});}
 if(method==='companion'){if(op==='session')return reply({role:'main',dataAuthority:'backend',settingsLock:{enabled:false,revision:''}});if(op==='getLive')return reply({snapshot:null,updatedAt:1,stale:false});return reply({holder:null,waiting:[],selection:{court:null,revision:0,pending:null,error:''}});}
 if(method==='settingsLock')return reply({enabled:false,revision:'',nativeUnlocked:true});
 if(method==='controlSettings'){
  if(offline)return reply(null,'Offline');if(op==='get'){if(unsupported===404)return reply({httpStatus:404,error:'Not found.'});const snap=snapshot();if(unsupported===99)snap.schemaVersion=99;if(holdGet){releaseGet=()=>reply(snap);return;}return reply(snap);}if(op==='state')return reply({automation,live:{},telestrator:{}});
  if(op==='action')return reply({ok:true,state:{automation}});
  if(op==='backup')return reply({format:'courtline-backend-settings',schemaVersion:1,createdAt:new Date().toISOString(),sections:Object.fromEntries(Object.entries(sections).map(([n,s])=>[n,clone(s.value)])),httpStatus:200});
  if(op==='restore'){
   if(payload.action==='preview'){w.fixtureRestore=payload.backup;return reply({previewId:'fixture-preview',changes:['vmix'],stagedSections:clone(payload.backup.sections),derivedEvents:[],automationWillStop:true,controlSettings:snapshot()});}
   if(rejectPatch)return reply({httpStatus:409,error:'Restore conflict',code:'conflict',controlSettings:snapshot()});
   for(const [n,v] of Object.entries(w.fixtureRestore.sections)){sections[n].value=clone(v);sections[n].revision='restored-'+(++nRestore);}
   if(dropRestore)return reply(null,'Connection lost after request');
   return reply({...snapshot(),restored:true,changed:true,automationStopped:true});
  }
  if(op==='patch'){patches.push(clone(payload));if(rejectPatch)return reply({httpStatus:400,error:'Fixture validation: choose a valid court'});if(failAuth)return reply({httpStatus:403,error:'Unlock expired'});const old=sections[payload.section];if(old.revision!==payload.expectedRevision)return reply({httpStatus:409,error:'Conflict',code:'conflict',controlSettings:snapshot()});old.value=clone(payload.value);old.revision='new-'+(++n);return reply({...snapshot(),...(saveWarning?{warning:'Settings saved; runtime needs Backend restart.'}:{})});}
 }
 if(method==='restoreLocalPreferences'){config.ui.vmixInputs=clone(op.vmixInputs);config.ui.autoRefresh=op.autoRefresh;config.ui.scoreholioStats.auto=op.statsAuto;config.ui.scoreholioStats.seconds=op.statsSeconds;return reply(clone(config));}
 if(method==='persistSettings')return reply(true);
 if(method==='statsHelper')return reply({records:[]});if(method==='request')return reply({status:200,text:'{}'});if(method==='checkUpdates')return reply({status:200,text:'[]'});
 reply(null,'Unsupported mock '+method);
 }};

 const mock=w.CourtlineAndroid;delete w.CourtlineAndroid;
 w.CourtlinePageID='ios-fixture-page';w.CourtlineIOS={sessionRole:()=>mock.sessionRole?.()||'main',settingsUnlocked:()=>mock.settingsUnlocked?.()??true};
 w.CourtlineNative={load:mock.load,save:mock.save,unlockSettings:()=>mock.unlockSettings?.(),switchRole:()=>{}};
 for(const name of ['open','telestrator','scanStatsHelper','statsHelper','statsAssignments','settingsLock','companion','controlSettings','restoreLocalPreferences','exportSettings','importSettings','persistSettings','snapshot','sendWidget','request','checkUpdates','downloadUpdate'])w.CourtlineNative[name]=(...args)=>mock.dispatch(JSON.stringify({pageId:w.CourtlinePageID,method:name,args}));
}});
let nRestore=0;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{await sleep(650);const w=dom.window,d=w.document;assert.equal(errors.length,0,errors.join('\n'));const target='https://app.scoreholio.com/overlay?account=fixture-account&did=device0';
 w.renderCompanionSnapshot({visibleCourts:[true,true,true,true],courts:[{kind:'assigned',sourceType:'backend',name:'Test event',widgetUrl:target,matchup:[{players:['Alice']},{players:['Bob']}]},{kind:'empty'},{kind:'empty'},{kind:'empty'}]});
 const card=d.querySelector('.court-card'),button=card.querySelector('[data-send-vmix]'),feedback=card.querySelector('[data-vmix-feedback]');assert(!button.disabled);
 const startRequests=calls.filter(c=>c.method==='request').length;
 for(const mode of [200,503,'malformed','deny','timeout',204]){widgetMode=mode;const before=calls.filter(c=>c.method==='sendWidget').length;button.click();for(let i=0;i<100&&button.disabled;i++)await sleep(5);await sleep(20);const sent=calls.filter(c=>c.method==='sendWidget');assert.equal(sent.length,before+1,'one native call, no replay');const args=sent.at(-1).args;assert(args[0].startsWith('ios-fixture-page:'));assert.equal(args[1],0);assert.equal(args[2],'local-browser');assert.equal(args[3],target);assert.equal(args[4],sections.vmix.value.address);assert.equal(feedback.dataset.state,typeof mode==='number'&&mode<300?'success':'error');if(feedback.dataset.state==='success')assert.equal(feedback.textContent,'Accepted by vMix');else assert.match(feedback.textContent,/Failed or unconfirmed/);assert(!button.disabled);}
 assert.equal(calls.filter(c=>c.method==='request').length,startRequests,'Send never uses generic request');assert(w.CourtlineDetector.slots[0].alarms.some(a=>a.kind==='vmix_error'));assert.equal(errors.length,0,errors.join('\n'));console.log('PASS actual Send UI → dedicated native bridge: bound arguments,2xx success, HTTP/malformed/denied/uncertain errors, no retry, queue recovery, alarm, no generic transport.');w.close();})().catch(e=>{console.error(e);dom.window.close();process.exitCode=1;});
