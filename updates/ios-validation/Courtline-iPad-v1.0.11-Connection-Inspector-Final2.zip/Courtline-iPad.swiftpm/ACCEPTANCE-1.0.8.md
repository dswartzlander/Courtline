# iPad 1.0.8 acceptance checklist

Automated evidence must be recorded separately from physical acceptance.

- Native compiler/runtime evidence: see the corresponding exact-package GitHub CI record; native tests use a fake transport, not a real vMix computer.
- [ ] Open/import the complete package in Swift Playgrounds and validate its AppleProductTypes manifest, installation, bundle/version, and runtime resources.
- [ ] Fresh and revoked Companion: Options > Pair Device opens camera without Settings PIN. Cancel keeps connection; used/expired QR rejected safely.
- [ ] Owner enables Control and configures per-device PIN; wrong/unset PIN denied; correct PIN promotes. No credentials enter Web storage.
- [ ] Cold launch Companion; ordinary background/resume and Live/Settings navigation retain valid grant. Explicit switch/revoke/reset invalidates correctly.
- [ ] Two clients: Pull clean hydration, draft preservation, Apply conflict, offline/reconnect and no silent replay.
- [ ] Backup review shows actual changes; canceled preview no mutation; successful restore stops automation when required; timeout no retry.
- [ ] 12.9-inch iPad landscape/portrait: four courts, independent settings, readable expanded Singles stats; Unknown/Doubles restore four cards.
- [ ] Full-area native Telestrator hides behind dialogs; lease touch gating, court switching and return navigation.
- [ ] Camera/local-network permissions, LAN reconnect, native file import/export and vMix dry-run behavior.
- [ ] One automatic update check per cold launch; manual checks work; only iPad ZIP offered; cancel no install.

JavaScript DOM fixtures and real Backend HTTP tests cannot substitute for these native/device checks.
