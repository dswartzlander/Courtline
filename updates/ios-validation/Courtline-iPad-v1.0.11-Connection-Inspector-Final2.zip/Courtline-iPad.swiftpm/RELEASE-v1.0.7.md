# iPad 1.0.7 candidate
- Native-managed enrollment, per-device Control PIN, Companion cold launch and revocation flow.
- Backend-authoritative full shared settings, Pull/Apply, conflict handling and reviewed backup restore.
- Evidence-based Singles Stats with doubled player area; preserve Unknown/Doubles layout.
- Retain iPad independent court stacks and full-area Telestrator dialog.
- Platform-correct iPad ZIP updater and accessible Options > Pair Device.

Native build and physical-device verification are pending. No publication or install is represented by this source change.
