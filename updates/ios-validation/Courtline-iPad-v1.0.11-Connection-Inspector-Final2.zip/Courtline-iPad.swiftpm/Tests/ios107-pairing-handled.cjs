const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
function callback(file,start,end){const s=fs.readFileSync(file,'utf8'),a=s.indexOf(start);assert(a>=0);const b=s.indexOf(end,a);assert(b>a);return s.slice(a+start.length,b);}
(async()=>{
 for(const result of [null,{paired:true,handled:true}]){
  let parses=0,saves=0,message='';const code=callback('Web/stats-data.js',"document.getElementById('scanStatsHelper').addEventListener('click',async()=>{",'\n  });');
  const ctx={busy:false,next:0,api:{scan_stats_helper:async()=>result},say:v=>message=v,D:{event:()=>{parses++;throw Error('Should not parse native handled response');}},url:{value:'unchanged'},save:async()=>saves++,window:{collectStatsSettings:()=>({seconds:10})},Date};vm.createContext(ctx);await vm.runInContext('(async()=>{'+code+'})()',ctx);assert.equal(parses,0);assert.equal(saves,0);assert.equal(ctx.url.value,'unchanged');assert.equal(ctx.busy,false);if(result===null)assert.equal(message,'Scan canceled.');
  const scan={disabled:false},submit={disabled:false},pin={value:'old'},note={textContent:''};let savedCalls=0;const code2=callback('Web/settings-lock.js',"dialog.querySelector('[data-scan-helper]').addEventListener('click',async()=>{",'\n  });');
  const context={dialog:{querySelector:s=>s==='[data-scan-helper]'?scan:submit},pin,message:note,window:{pywebview:{api:{scan_stats_helper:async()=>result}},saveScannedStatsHelper:async()=>{savedCalls++;throw Error('Should not parse handled response');}}};vm.createContext(context);await vm.runInContext('(async()=>{'+code2+'})()',context);assert.equal(savedCalls,0);assert.equal(scan.disabled,false);assert.equal(submit.disabled,false);assert.equal(pin.value,'');if(result===null)assert.match(note.textContent,/canceled/);
 }
 console.log('PASS actual Stats and Settings scan callbacks: native paired+handled bypass parsing/save, null cancel preserves configuration, busy/buttons reset.');
})().catch(e=>{console.error(e);process.exitCode=1;});
