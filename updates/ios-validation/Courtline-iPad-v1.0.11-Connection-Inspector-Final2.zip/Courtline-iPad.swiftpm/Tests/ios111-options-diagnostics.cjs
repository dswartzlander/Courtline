const {JSDOM}=require('/workspace/scratch/4d9aa462dfa7/android_source/test-tools/node_modules/jsdom');
const fs=require('fs'),assert=require('assert/strict');
const html=fs.readFileSync('Web/index.html','utf8'),script=fs.readFileSync('Web/courtline-options.js','utf8');
for(const mode of ['unpaired','revoked','paired-companion','missing','throws']){
 const dom=new JSDOM(html,{runScripts:'outside-only',url:'https://fixture.invalid'}),w=dom.window,d=w.document;
 let nativeCalls=0,forbidden=0,args;
 w.CourtlineIOS={sessionRole:()=> 'viewer',settingsUnlocked:()=>false,needsEnrollment:()=>mode!=='paired-companion'};
 w.CourtlineNative={connectionDiagnostics(...a){nativeCalls++;args=a;if(mode==='throws')throw Error('http://pc/?key=en_SECRET PIN=1234');},unlockSettings(){forbidden++;},scanStatsHelper(){forbidden++;}};
 w.pywebview={api:{scan_stats_helper(){forbidden++;throw Error('No QR expected');}}};
 if(mode==='missing')delete w.CourtlineNative.connectionDiagnostics;
 w.eval(script);
 const options=d.getElementById('optionsButton'),button=d.getElementById('courtlineOptionsDiagnostics'),menu=d.getElementById('courtlineOptionsMenu'),status=d.getElementById('courtlineDiagnosticsStatus');
 options.click();assert(!menu.hidden);assert(!button.disabled);button.click();
 assert.equal(forbidden,0);assert.equal(nativeCalls,mode==='missing'?0:1);
 if(mode==='missing'||mode==='throws'){
  assert(!menu.hidden);assert.equal(status.textContent,'Connection Diagnostics could not open. Reopen the app and try again.');assert(!status.textContent.includes('en_SECRET'));assert(!status.textContent.includes('1234'));
 }else{
  assert(menu.hidden);assert.deepEqual(args,[]);assert.equal(status.textContent,'');
  // Native Cancel returns no callback or Web state; re-open and explicitly invoke again.
  options.click();button.click();assert.equal(nativeCalls,2);assert.equal(forbidden,0);
 }
 if(menu.hidden)options.click();
 d.getElementById('courtlineOptionsClose').click();assert(menu.hidden);assert.equal(d.activeElement,options);
 dom.window.close();
}
console.log('PASS actual Options Diagnostics: unpaired/revoked Companion entry, zero args/PIN/QR, native-cancel reopen, safe missing/throwing bridge fallback. Native owns input/HTTP/stale callbacks.');
