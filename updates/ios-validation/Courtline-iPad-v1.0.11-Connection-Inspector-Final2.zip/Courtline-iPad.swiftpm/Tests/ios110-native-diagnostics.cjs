'use strict';
const fs=require('fs'),assert=require('assert'),path=require('path');const root=path.resolve(__dirname,'..');
const b=fs.readFileSync(path.join(root,'CourtlineSessionBroker.swift'),'utf8'),s=fs.readFileSync(path.join(root,'HelperQRScanner.swift'),'utf8');
const p=b.slice(b.indexOf('private static func probePath'),b.indexOf('private func fetch'));
assert(p.includes('Self.lanOrigin(host.absoluteString)==host'));assert(p.includes('using:.tcp'));assert(p.includes('deadline:.now()+3'));assert(p.includes('connection.cancel()'));assert(!p.includes('.send('));assert(!p.includes('X-Courtline-Key'));assert(!p.includes('dataTask'));
assert(b.includes('e.code == NSURLErrorNotConnectedToInternet'));assert(b.includes('sourceDomain'));assert(b.includes('Bundle.main.object(forInfoDictionaryKey:"NSLocalNetworkUsageDescription")'));assert(b.includes('self.valid(captured) else{done("PAIR_CHANGED")'));assert(b.includes('allowed.contains(state)'));
assert(s.includes('AVCaptureDevice.RotationCoordinator(device:camera,previewLayer:self.preview)'));assert(s.includes('videoRotationAngleForHorizonLevelPreview'));assert(s.includes('rotation.observe('));assert(s.includes('override func viewDidAppear'));assert(s.includes('override func viewWillTransition'));assert(s.includes('rotationObservation=nil;rotationCoordinator=nil'));assert(!s.includes('case .landscapeRight: angle = 0'));
console.log('PASS source guards: exact-origin bounded TCP diagnostic/no payload or retry, enum-only effective flags, camera rotation coordinator lifecycle. Not hardware proof.');
