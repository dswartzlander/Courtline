const assert=require('node:assert/strict');const Model=require('../Web/backend-control-model.js');
const snap=(revision,value)=>({schemaVersion:1,sections:{'automation:0':{revision,value}}});
const a=new Model(),b=new Model();a.reset('A');b.reset('A');let server=snap('r1',{dry_run:true,rows:[]});a.accept(server);b.accept(server);assert.equal(a.sections['automation:0'].dirty,false);
a.edit('automation:0',{dry_run:false,rows:[]});b.edit('automation:0',{dry_run:true,rows:[{id:'b'}]});assert.equal(a.request('automation:0').expectedRevision,'r1');
server=snap('r2',a.request('automation:0').value);a.committed('automation:0',server,a.epoch);b.accept(server);assert.equal(b.sections['automation:0'].conflict,true);assert.throws(()=>b.request('automation:0'),/changed/);assert.equal(b.sections['automation:0'].draft.rows[0].id,'b');b.reload('automation:0');assert.deepEqual(b.sections['automation:0'].draft,server.sections['automation:0'].value);
a.edit('automation:0',{dry_run:true,rows:[]});a.offline();assert.throws(()=>a.request('automation:0'),/unavailable/);assert.throws(()=>a.edit('automation:0',{}),/Reconnect/);a.accept(server);assert.equal(a.sections['automation:0'].dirty,true);
const epoch=a.epoch;a.reset('B');assert.equal(a.accept(server,epoch),false);assert.equal(a.loaded,false);assert.equal(Object.keys(a.sections).length,0);assert.throws(()=>a.accept({schemaVersion:99}),/Unsupported/);
console.log('PASS model: initial read no write, clean/dirty hydration, two-client CAS conflict, explicit reload, offline draft/no queued writes, reconnect and identity switch.');
