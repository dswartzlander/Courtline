import UIKit

// Native-only secure text field: the PIN never enters WKWebView or stored state.
final class DevicePINController: UIViewController, UITextFieldDelegate {
    var submitted: ((String) -> Void)?
    var cancelled: (() -> Void)?
    private let input = UITextField()
    private let error = UILabel()
    private var completed = false
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.9)
        let card = UIStackView();card.axis = .vertical;card.spacing = 14
        card.isLayoutMarginsRelativeArrangement = true;card.layoutMargins = UIEdgeInsets(top:24,left:24,bottom:24,right:24)
        card.backgroundColor = UIColor(red:0.067,green:0.149,blue:0.216,alpha:1)
        card.layer.cornerRadius = 16;card.layer.borderWidth = 1;card.layer.borderColor = UIColor(red:0.4,green:0.8,blue:0.72,alpha:1).cgColor
        let title=UILabel();title.text="Unlock Settings";title.font = .boldSystemFont(ofSize:24);title.textColor = .white
        let description=UILabel();description.text="Enter your Device PIN to unlock Control settings.";description.numberOfLines=0;description.font = .systemFont(ofSize:16);description.textColor = .white
        let row=UIStackView();row.axis = .horizontal;row.spacing=12;row.alignment = .center
        let label=UILabel();label.text="PIN";label.textColor = .white;label.font = .boldSystemFont(ofSize:16)
        input.isSecureTextEntry=true;input.keyboardType = .numberPad;input.textContentType = nil;input.autocorrectionType = .no;input.spellCheckingType = .no;input.delegate=self;input.textColor = .white;input.font = .systemFont(ofSize:22);input.borderStyle = .roundedRect;input.backgroundColor = UIColor(red:0.035,green:0.094,blue:0.15,alpha:1);input.accessibilityLabel="Device PIN"
        let unlock=UIButton(type:.system);unlock.setTitle("Unlock",for:.normal);unlock.addTarget(self,action:#selector(unlockPIN),for:.touchUpInside)
        row.addArrangedSubview(label);row.addArrangedSubview(input);row.addArrangedSubview(unlock);input.widthAnchor.constraint(greaterThanOrEqualToConstant:90).isActive=true
        unlock.widthAnchor.constraint(equalToConstant:90).isActive=true
        error.textColor = .systemRed;error.numberOfLines=0;error.isHidden=true
        let back=UIButton(type:.system);back.setTitle("Back to Live",for:.normal);back.addTarget(self,action:#selector(cancelPIN),for:.touchUpInside)
        for b in [unlock,back] {b.backgroundColor = UIColor(red:0.10,green:0.27,blue:0.30,alpha:1);b.setTitleColor(.white,for:.normal);b.layer.cornerRadius=8;b.heightAnchor.constraint(greaterThanOrEqualToConstant:48).isActive=true}
        for v in [title,description,row,error,back] {card.addArrangedSubview(v)}
        card.translatesAutoresizingMaskIntoConstraints=false;view.addSubview(card)
        let width=card.widthAnchor.constraint(equalToConstant:470);width.priority = .defaultHigh
        let center=card.centerYAnchor.constraint(equalTo:view.safeAreaLayoutGuide.centerYAnchor);center.priority = .defaultLow
        NSLayoutConstraint.activate([width,center,card.widthAnchor.constraint(lessThanOrEqualTo:view.safeAreaLayoutGuide.widthAnchor,constant:-32),card.centerXAnchor.constraint(equalTo:view.centerXAnchor),card.topAnchor.constraint(greaterThanOrEqualTo:view.safeAreaLayoutGuide.topAnchor,constant:16),card.bottomAnchor.constraint(lessThanOrEqualTo:view.keyboardLayoutGuide.topAnchor,constant:-16)])
    }
    func textField(_ textField:UITextField,shouldChangeCharactersIn range:NSRange,replacementString string:String)->Bool {
        guard string.allSatisfy({$0.isASCII && $0.isNumber}),let r=Range(range,in:textField.text ?? "") else{return false}
        return (textField.text ?? "").replacingCharacters(in:r,with:string).count<=8
    }
    @objc private func unlockPIN(){guard !completed else{return};let pin=input.text ?? "";guard pin.range(of:"^[0-9]{4,8}$",options:.regularExpression) != nil else{error.text="Enter a 4–8 digit PIN.";error.isHidden=false;return};completed=true;input.text="";view.endEditing(true);let callback=submitted;submitted=nil;cancelled=nil;dismiss(animated:true){callback?(pin)}}
    @objc private func cancelPIN(){guard !completed else{return};completed=true;input.text="";view.endEditing(true);let callback=cancelled;submitted=nil;cancelled=nil;dismiss(animated:true){callback?()}}
    override func viewDidDisappear(_ animated:Bool){super.viewDidDisappear(animated);input.text="";if !completed {completed=true;cancelled?()}}
}
