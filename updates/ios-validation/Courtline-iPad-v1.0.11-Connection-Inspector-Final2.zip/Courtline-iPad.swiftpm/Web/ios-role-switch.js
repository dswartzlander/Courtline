'use strict';
// Delegate to the native, server-verified Control/Companion session flow.
(() => {
  const badge=document.getElementById('liveIndicator');
  if(!badge)return;
  badge.addEventListener('click',()=>{
    if(!window.CourtlineNative?.switchRole)return;
    if(confirm('Switch between Control and Companion? Control requires approval in Backend Device Management and the PIN configured for this device. Companion is read-only. The enrollment QR is only needed to pair a device.')){
      window.CourtlineNative.switchRole();
    }
  });
})();
