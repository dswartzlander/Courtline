'use strict';
// Adapter for the existing Control View. No second editor or settings store.
(()=>{
 const model=new window.BackendControlModel(),extraFields=new Map();let active=false,ready=false,domReady=false,role='main',busy=false,token='',expires=0,policyRevision='',status,pull,state=null,lastState=0,stateWork=null,rendering=false,persistentWarning='',actionError='';
 const unbind=[];const listen=(node,type,fn)=>{node.addEventListener(type,fn);unbind.push(()=>node.removeEventListener(type,fn));};
 const api=()=>window.pywebview.api,id=()=>window.CourtlineCompanion?.deviceId||'';
 let pollWork=null;
 let writeChain=Promise.resolve(),writeGeneration=0,writes=0;
 const clone=x=>JSON.parse(JSON.stringify(x));
 const auth=()=>({deviceId:id(),unlockToken:Date.now()<expires?token:''});
 const paired=()=>active&&role==='main';
 function setMessage(text){if(status&&status.textContent!==text)status.textContent=text;if(status)status.hidden=!text;}
 function sectionNode(name){if(extraFields.has(name))return extraFields.get(name).node;if(name==='vmix')return document.querySelector('.vmix-host-field');const i=Number(name.split(':')[1]),card=document.querySelector('.court-card[data-slot="'+i+'"]');if(name.startsWith('connection:'))return card?.querySelector('.device-event-settings');if(name.startsWith('telestrator:'))return card?.querySelector('.telestrator-button-settings');return card?.querySelector('.automation-settings:not(.device-event-settings):not(.telestrator-button-settings)');}
 function supported(name){return name==='vmix'||/^(connection|automation|telestrator|event|exports|matchup):[0-3]$/.test(name);}
 function statusUI(){
  if(!domReady||!paired())return;
  setMessage(model.error||actionError||persistentWarning||(!model.loaded?'Connecting to Backend… Control fields are read-only until loaded.':!model.online?'Backend offline · Last known settings, read-only.':Object.values(model.sections).some(s=>s.conflict)?'Backend changed. Unsaved drafts are retained; review conflicting sections.':''));
  for(const name of ['vmix',...Array.from({length:4},(_,i)=>['connection:'+i,'automation:'+i,'telestrator:'+i,'event:'+i,'exports:'+i,'matchup:'+i]).flat()]){
   const node=sectionNode(name);if(!node)continue;
   const disabled=!model.online||!model.loaded||model.snapshot?.capabilities?.readOnly?.includes(name);for(const control of node.querySelectorAll('input,select,button')){
    if(control.matches('[data-vmix-input]'))continue;
    if(disabled){if(control.dataset.backendDisabled!=='true')control.dataset.backendPriorDisabled=String(control.disabled);control.dataset.backendDisabled='true';control.disabled=true;}else if(control.dataset.backendDisabled==='true'){control.disabled=control.dataset.backendPriorDisabled==='true'||control.dataset.busy==='true';delete control.dataset.backendDisabled;delete control.dataset.backendPriorDisabled;}
   }
   const s=model.sections[name],feedback=node.querySelector('[data-backend-feedback]');const feedbackText=s?.conflict?'Conflict: Backend changed while you edited. Your draft is retained. Reload this section before applying.':s?.dirty?(name==='vmix'?'Unsaved address · Test Connection to test and save':'Unsaved changes · Apply to send to Backend'):'';if(feedback&&feedback.textContent!==feedbackText)feedback.textContent=feedbackText;
  }
 }
 async function request(op,payload={}){
  const epoch=model.epoch,target=model.identity;
  const result=await api().control_settings(target,op,{...payload,...auth()});
  if(epoch!==model.epoch||target!==model.identity)throw Error('Backend connection changed. Previous response ignored.');
  if(result.httpStatus===404){model.offline('Backend update required. Install '+(['backup','restore'].includes(op)?'Test37':'Test36')+' or newer on the PC, then Pull from Backend.');statusUI();throw Error(model.error);}
  if(result.httpStatus>=400){if(result.httpStatus===409&&result.controlSettings)model.accept(result.controlSettings,epoch);if([401,403].includes(result.httpStatus)){token='';expires=0;window.CourtlineSettingsLock?.relock();if(result.httpStatus===403)window.CourtlineSettingsLock?.prompt();}statusUI();const error=Error(result.error||'Backend request failed.');error.httpStatus=result.httpStatus;error.connection=result.connection;error.saved=result.saved;error.testedAddress=result.testedAddress;throw error;}
  return {result,epoch};
 }
 function hydrate(){
  if(!domReady||!paired()||!model.loaded)return;
  rendering=true;
  try{
   for(const [name,s] of Object.entries(model.sections))if(supported(name)&&!s.dirty){
    if(name.startsWith('automation:')||name.startsWith('telestrator:'))window.desktopHydrateBackendProfile?.(name,clone(s.value));
    else window.desktopHydrateBackendFields?.(name,clone(s.value));
    for(const field of extraFields.get(name)?.fields||[]){const v=s.value[field.key];if(field.type==='checkbox')field.input.checked=!!v;else field.input.value=v??'';}
   }
   const extra=Object.keys(model.sections).filter(n=>!supported(n));
   const note=document.getElementById('backendCapabilities');if(note)note.textContent='Use Backend PC for account login, folder selection, PIN administration and application installation. All shared settings below use Backend state. iPad browser-widget destinations stay local.'+(extra.length?' Additional unsupported schema sections: '+extra.join(', '):'');
  }finally{rendering=false;}
  statusUI();
 }
 function poll(){if(pollWork)return pollWork;pollWork=performPoll().finally(()=>{pollWork=null;});return pollWork;}
 async function performPoll(){
  if(!active||role!=='main'||busy||writes||document.hidden)return false;
  busy=true;const epoch=model.epoch,generation=writeGeneration;
  try{
   if(!ready){const session=await api().companion(model.identity,'session');if(epoch!==model.epoch)return;if(session.role!=='main'){role=session.role;return;}if(session.dataAuthority!=='backend')throw Error('This Helper does not support shared Backend settings.');ready=true;}
   const {result}=await request('get');if(generation!==writeGeneration||writes)return;if(!model.accept(result,epoch))return;
   const revision=result.lock?.revision;if(policyRevision&&revision&&revision!==policyRevision){token='';expires=0;}policyRevision=revision||policyRevision;hydrate();return true;
  }catch(e){if(epoch===model.epoch){model.offline((/Unsupported Backend settings|Invalid Backend settings/.test(e.message)?'Backend update required. Install a compatible Backend version on the PC.':e.message)+' · No changes are queued for reconnect.');statusUI();}}
  finally{busy=false;}
 }
 function edit(name,value){if(rendering||!paired()||!model.loaded)return;model.edit(name,value);statusUI();}
 function profileDraft(name,profile){
  const s=model.sections[name];if(!s)throw Error('Pull Backend settings before editing.');
  const tel=name.startsWith('telestrator:'),base=clone(s.draft),old=tel?base.profile:base;
  // Preserve every Backend-only option and per-row metadata that has no iPad field.
  const rows=profile.rows.map(r=>({...old.rows.find(x=>x.id===r.id),...r}));
  Object.assign(old,profile,{rows});if(tel){delete old.poll_seconds;delete old.alarm_delay;base.source=window.desktopGetTelestratorSource?.(Number(name.split(':')[1]))||'';}
  return base;
 }
 async function apply(name,value){
  if(value!==undefined)edit(name,value);
  if(window.CourtlineSettingsLock?.locked()){window.CourtlineSettingsLock.prompt();throw Error('Unlock Settings before applying Backend changes.');}
  const epochAtApply=model.epoch;writeGeneration++;writes++;
  const task=writeChain.catch(()=>{}).then(async()=>{
  if(epochAtApply!==model.epoch)throw Error('Backend changed before Apply. Nothing was sent.');
  const payload=model.request(name),sent=JSON.stringify(payload.value);
  const {result,epoch}=await request('patch',payload);
  // Edits made while the request was running remain drafts against the new revision.
  const current=model.sections[name],later=current&&JSON.stringify(current.draft)!==sent?clone(current.draft):null;
  model.committed(name,result,epoch);if(later)model.edit(name,later);hydrate();persistentWarning=result.warning||'';setMessage(persistentWarning||'Saved to Backend.');return clone(model.sections[name].value);
  });writeChain=task;return task.finally(()=>{writes--;});
 }
 async function testAndSaveVmix(address){
  if(!paired()||!model.online)throw Error('Connect to Backend as Main before testing and saving.');
  if(model.snapshot?.capabilities?.testAndSaveConnection!==true)throw Error('Backend update required. Install Test38 or newer for Test Connection to save the tested address. Nothing was saved.');
  if(window.CourtlineSettingsLock?.locked()){window.CourtlineSettingsLock.prompt();throw Error('Unlock Settings before testing and saving.');}
  const payload=model.request('vmix'),epoch=model.epoch;writeGeneration++;writes++;
  const task=writeChain.catch(()=>{}).then(async()=>{
   if(epoch!==model.epoch)throw Error('Backend connection changed. Test canceled; nothing sent.');
   let result;try{({result}=await request('action',{action:'test-and-save-connection',address,expectedRevision:payload.expectedRevision}));}
   catch(error){const rejected=error.saved===false||[400,401,403,404,409,410,422].includes(error.httpStatus);if(rejected&&error.connection?.ok)throw Error('Connection passed for '+(error.testedAddress||address)+', but the address was NOT saved: '+error.message);if(!rejected)throw Error('Test/save was not confirmed: '+error.message+'. Backend may have saved the tested address; Pull and verify before retrying.');throw Error('Connection test/save failed; nothing saved: '+error.message);}
   if(result.saved!==true||result.connection?.ok!==true||result.testedAddress!==address||result.sections?.vmix?.value?.address!==address||typeof result.sections?.vmix?.revision!=='string')throw Error('Backend did not confirm the exact tested address was saved. Pull and verify before retrying.');
   const current=model.sections.vmix,later=current&&current.draft.address!==address?clone(current.draft):null;
   model.committed('vmix',result,epoch);if(later)model.edit('vmix',later);hydrate();persistentWarning=result.warning||'';
   return {saved:true,state:persistentWarning||later?'warning':'success',message:'Connected to '+address+' and saved to Backend.'+(later?' Your newer address edits remain unsaved; test them to save.':'')+(persistentWarning?' '+persistentWarning:'')};
  });writeChain=task;return task.finally(()=>{writes--;});
 }
 async function action(action,slot,extra={}){
  if(!model.online)throw Error('Reconnect to Backend before running controls.');
  const {result}=await request('action',{action,...(slot===undefined?{}:{slot}),...extra});if(result.state){state=result.state;lastState=Date.now();}return result;
 }
 async function getState(){
  if(!model.online)return Array.from({length:4},()=>({status:{page:{state:'Backend offline'}},alarms:[],logs:[],running:false,armed:false}));
  if(Date.now()-lastState>1000&&!stateWork)stateWork=request('state').then(({result})=>{state=result;lastState=Date.now();}).finally(()=>stateWork=null);
  if(stateWork)await stateWork;
  return Array.from({length:4},(_,i)=>{const v=state?.automation?.[i]||{},p=model.sections['automation:'+i]?.value,t=model.sections['telestrator:'+i]?.value;return {...v,status:v.status||{},alarms:v.alarms||[],logs:v.logs||[],dry_run:p?.dry_run,telestrator_count:t?.profile?.rows?.filter(r=>r.enabled&&r.command).length||0,telestrator_dry_run:t?.profile?.dry_run};});
 }
 function addExtras(name,node,specs){
  const fields=[];for(const [key,title,type,min,max] of specs){
   const label=document.createElement('label');label.dataset.backendAdded='true';label.textContent=title;const input=document.createElement(type==='select'?'select':'input');
   if(type==='select'){for(const [value,text] of [['','Unassigned'],['0','Event slot 1'],['1','Event slot 2'],['2','Event slot 3'],['3','Event slot 4']])input.add(new Option(text,value));}
   else input.type=type;if(min!==undefined)input.min=min;if(max!==undefined)input.max=max;
   label.append(input);node.append(label);input.oninput=input.onchange=()=>{if(rendering||!model.online)return;const base=clone(model.sections[name].draft);base[key]=type==='checkbox'?input.checked:type==='number'||type==='select'?(input.value===''?null:Number(input.value)):input.value;edit(name,base);};fields.push({key,input,type});
  }extraFields.set(name,{node,fields});
 }
 function addButton(parent,text,fn){const b=document.createElement('button');b.type='button';b.textContent=text;b.dataset.backendAdded='true';b.onclick=async()=>{b.dataset.busy='true';b.disabled=true;actionError='';try{await fn();}catch(e){actionError=e.message;setMessage(actionError);}finally{delete b.dataset.busy;b.disabled=false;statusUI();}};parent.append(b);return b;}
 function mount(){
  if(!domReady||!paired()||pull)return;
  document.body.classList.add('backend-connected');document.getElementById('exportSettings').textContent='Export All Settings';document.getElementById('importSettings').textContent='Import All Settings';const anchor=document.getElementById('exportSettings');
  pull=document.createElement('button');pull.type='button';pull.textContent='Pull from Backend';pull.dataset.backendAdded='true';pull.onclick=async()=>{if(pull.disabled)return;const button=pull;button.disabled=true;try{await window.CourtlineBackendControl.pull();}catch(e){actionError=e.message;setMessage(actionError);}finally{button.disabled=false;}};pull.className='control-button settings-file-button';pull.dataset.backendPull='true';pull.title='Pull current Backend settings into Control View; unsaved drafts are preserved';anchor.before(pull);
  status=document.createElement('p');status.id='backendSyncStatus';status.setAttribute('role','status');anchor.parentElement.append(status);
  const note=document.createElement('small');note.id='backendCapabilities';anchor.parentElement.append(note);
  for(let i=0;i<4;i++){
   const connection=sectionNode('connection:'+i),automation=sectionNode('automation:'+i);
   if(connection)addExtras('connection:'+i,connection,[['eventSlot','Backend event slot','select'],['court','Backend court number','number',1,128]]);
   if(automation)addExtras('automation:'+i,automation,[['match_alerts','Match alerts','checkbox'],['require_matchup_stats','Require matchup stats','checkbox']]);
   for(const [kind,title,specs] of [
    ['event','Event slot '+(i+1)+' · Backend',[['adminURL','Event admin URL (manual assignments only)','url'],['name','Event name','text']]],
    ['exports','Event slot '+(i+1)+' · Exports',[['auto','Automatic event exports','checkbox'],['seconds','Refresh interval (seconds)','number',30,3600]]],
    ['matchup','Court '+(i+1)+' · Matchup refresh',[['enabled','Automatic matchup refresh','checkbox']]]]){
    const details=document.createElement('details');details.dataset.backendAdded='true';const heading=document.createElement('summary');heading.textContent=title;details.append(heading);connection?.append(details);addExtras(kind+':'+i,details,specs);
   }
  }
  for(const name of ['vmix',...Array.from({length:4},(_,i)=>['connection:'+i,'automation:'+i,'telestrator:'+i,'event:'+i,'exports:'+i,'matchup:'+i]).flat()]){
   const node=sectionNode(name);if(!node)continue;
   const feedback=document.createElement('p');feedback.dataset.backendFeedback='true';feedback.setAttribute('role','status');node.append(feedback);
   addButton(node,'Reload Backend section',()=>{if(model.sections[name]?.dirty&&!confirm('Discard this section’s unsaved draft and use the Backend version?'))return;model.reload(name);window.desktopInvalidateBackendProfile?.(name);hydrate();});
   if(/^(connection|event|exports|matchup):/.test(name))addButton(node,'Apply Changes',()=>apply(name));
   if(name.startsWith('exports:')||name.startsWith('matchup:'))addButton(node,'Refresh now',()=>action(name.startsWith('exports:')?'refresh-stats':'refresh-matchup',Number(name.split(':')[1])));
   listen(node,'input',()=>{if(rendering||!model.online)return;if(name.startsWith('automation:')||name.startsWith('telestrator:')){const p=window.desktopReadBackendProfile?.(name);if(p)edit(name,profileDraft(name,p));}});
   listen(node,'change',()=>{if(rendering||!model.online)return;if(name.startsWith('automation:')||name.startsWith('telestrator:')){const p=window.desktopReadBackendProfile?.(name);if(p)edit(name,profileDraft(name,p));}});
   // Copy/add/remove/shortcut picker mutations are drafts too.
   listen(node,'click',()=>{setTimeout(()=>{if(rendering||!model.online)return;if(name.startsWith('automation:')||name.startsWith('telestrator:')){const p=window.desktopReadBackendProfile?.(name);if(p)edit(name,profileDraft(name,p));}},0);});
  }
  listen(document,'courtline-modal-change',()=>{if(!paired()||!model.online||rendering)return;for(let i=0;i<4;i++)for(const kind of ['automation','telestrator']){const name=kind+':'+i,p=window.desktopReadBackendProfile?.(name);if(p)edit(name,profileDraft(name,p));}});
  hydrate();statusUI();
 }
 async function exportBackup(){
  if(!paired()||!model.online)throw Error('Connect as Main before exporting Backend settings.');
  const epoch=model.epoch;await writeChain.catch(()=>{});if(epoch!==model.epoch)throw Error('Backend changed. Export canceled.');
  const {result}=await request('backup');
  const backup=clone(result.backup||result);delete backup.httpStatus;return window.CourtlineConnectedBackup.make(backup,window.desktopCollectUI());
 }
 async function importBackup(text){
  if(!paired()||!model.online)throw Error('Connect as Main before restoring Backend settings.');
  if(window.CourtlineSettingsLock?.locked()){window.CourtlineSettingsLock.prompt();throw Error('Unlock Settings before restoring.');}
  const parsed=window.CourtlineConnectedBackup.parse(text),epoch=model.epoch;
  await writeChain.catch(()=>{});await poll();if(epoch!==model.epoch||!model.online)throw Error('Backend changed or disconnected. Nothing restored.');
  const fingerprint=()=>JSON.stringify(Object.fromEntries(Object.entries(model.sections).map(([n,v])=>[n,v.draft])));
  const draftBefore=fingerprint(),localBefore=window.CourtlineConnectedBackup.local(window.desktopCollectUI());
  const expectedRevisions=Object.fromEntries(Object.entries(model.sections).map(([n,v])=>[n,v.remoteRevision||v.revision]));
  const {result:preview}=await request('restore',{action:'preview',backup:parsed.backend,expectedRevisions});
  if(!preview.stagedSections)throw Error('Backend did not provide the exact restore preview. Update Backend; nothing restored.');
  const lines=['Restore only the reviewed shared Backend settings and listed iPad preferences. Pairing credentials, PIN, account sign-in, export folder and installation settings are NOT imported.',preview.automationWillStop?'This will stop Backend monitoring and pending automation commands. Restart monitoring yourself after review.':'Shared settings are unchanged. Active Backend monitoring will remain unchanged.', 'Remote Mode event identities follow their device links; saved derived event details are not forced onto a new link. Derived event slots: '+((preview.derivedEvents||[]).map(i=>Number(i)+1).join(', ')||'none'), 'Unsaved Control View drafts will be replaced after successful restore.'];
  for(const name of preview.changes||[])lines.push(name+'\n'+window.CourtlineConnectedBackup.differences(model.sections[name]?.value,preview.stagedSections?.[name]).join('\n'));
  if(parsed.android)lines.push('iPad local preferences\n'+(window.CourtlineConnectedBackup.differences(localBefore,parsed.android).join('\n')||'No changes.'));
  if(!await window.CourtlineConnectedBackup.review(lines))return {canceled:true};
  if(epoch!==model.epoch||fingerprint()!==draftBefore||JSON.stringify(localBefore)!==JSON.stringify(window.CourtlineConnectedBackup.local(window.desktopCollectUI())))throw Error('Settings or connection changed during review. Preview the backup again; nothing restored.');
  writeGeneration++;writes++;
  const progress=document.createElement('dialog');progress.textContent='Restoring reviewed settings…';progress.addEventListener('cancel',event=>event.preventDefault());document.body.append(progress);progress.showModal();
  const task=writeChain.catch(()=>{}).then(async()=>{
   if(epoch!==model.epoch)throw Error('Backend changed. Nothing restored.');
   let response;try{response=await request('restore',{action:'restore',previewId:preview.previewId,confirmed:true});}catch(e){if([400,401,403,404,409,410,422].includes(e.httpStatus))throw Error('Restore rejected; no settings were restored: '+e.message);throw Error('Restore was not confirmed: '+e.message+'. The Backend may already have saved it. Pull and verify current settings before retrying; no automatic retry was sent.');}const {result}=response;
   model.sections={};model.accept(result,epoch);for(const name of Object.keys(model.sections))if(/^(automation|telestrator):/.test(name))window.desktopInvalidateBackendProfile?.(name);hydrate();persistentWarning=result.warning||'';
   if(parsed.android){
    let localPersisted=false;try{
     await window.desktopFlushUI();if(epoch!==model.epoch)throw Error('Connection changed; local preference restore skipped.');
     await api().restore_local_preferences(model.identity,parsed.android);localPersisted=true;
     if(epoch!==model.epoch)throw Error('Connection changed after local save; new connection UI was not modified.');
     window.desktopRestoreLocalPreferences(parsed.android);
    }catch(e){throw Error('Backend settings WERE restored. '+(localPersisted?'iPad preferences were saved, but the current screen could not be updated: ':'iPad preference restore was not completed: ')+e.message+'. Do not repeat the Backend restore automatically.');}
   }
   setMessage(persistentWarning||'Backend settings restored.');return result;
  });writeChain=task;return task.finally(()=>{writes--;progress.close();progress.remove();});
 }
 function clearUnlock(){const grant=token;token='';expires=0;if((grant||window.CourtlineManagedSessions)&&model.identity)api().settings_lock(model.identity,{action:'lock',deviceId:id(),unlockToken:grant}).catch(()=>{});}
 window.CourtlineBackendControl={get active(){return active;},get model(){return model;},
  beginIdentity(url){clearUnlock();for(const remove of unbind.splice(0))remove();model.reset(url);persistentWarning='';actionError='';state=null;lastState=0;ready=false;active=!!url;role='main';if(active)window.stopLocalCourtlineWorkers?.();document.querySelectorAll('[data-backend-added],[data-backend-feedback],#backendSyncStatus,#backendCapabilities').forEach(n=>n.remove());pull=status=null;extraFields.clear();document.body.classList.remove('backend-connected');if(domReady){const testResult=document.getElementById('vmixConnectionResult');testResult.textContent='';delete testResult.dataset.state;document.getElementById('testVmixConnection').disabled=false;const refresh=document.getElementById('refreshButton');delete refresh.dataset.backendPull;refresh.textContent='Refresh';refresh.title='Refresh all courts now';refresh.setAttribute('aria-label','Refresh all courts');document.getElementById('exportSettings').textContent='Export Settings';document.getElementById('importSettings').textContent='Import Settings';}},
  identifyFailed(error){role=window.CourtlineCompanion?.role||'main';ready=false;model.offline('Backend session unavailable: '+error.message);mount();statusUI();},
  async identify(url,session){if(url!==model.identity)return;role=session.role;active=session.dataAuthority==='backend';ready=true;if(active)window.stopLocalCourtlineWorkers?.();if(paired())await poll();mount();},
  acceptUnlock(result){token=result.unlockToken||'';expires=Number(result.expiresAt)||0;policyRevision=result.revision||policyRevision;},clearUnlock,
  uiChanged(ui){if(rendering||!paired()||!model.loaded||!model.online)return;const vm=model.sections.vmix;if(vm&&ui.vmixHost!==undefined)edit('vmix',{...vm.draft,address:ui.vmixHost});for(let i=0;i<4;i++){const name='connection:'+i,s=model.sections[name];if(s)edit(name,{...s.draft,remoteURL:ui.urls[i]||'',visible:ui.visibleCourts[i]!==false});const tel=model.sections['telestrator:'+i];if(tel)edit('telestrator:'+i,{...tel.draft,source:ui.telestratorSources[i]||''});}},
  saveProfile:async(i,p,tel=false)=>{const name=(tel?'telestrator:':'automation:')+i;const saved=await apply(name,profileDraft(name,p));return tel?{...p,...saved.profile}:saved;},
  action,getState,apply,poll,testAndSaveVmix,exportBackup,importBackup,async pull(){actionError='';const epoch=model.epoch;if(writes)setMessage('Waiting for the current save before pulling Backend settings…');await writeChain.catch(()=>{});if(epoch!==model.epoch)return;let completed=await poll();if(!completed&&epoch===model.epoch&&active&&ready&&!writes&&!document.hidden)completed=await poll();if(!completed){if(model.online)setMessage('Pull is waiting for the current save. Try again when it finishes.');return;}if(model.online){setMessage(Object.values(model.sections).some(s=>s.dirty)?'Pulled Backend settings. Unsaved drafts were preserved.':'Pulled current Backend settings.');}}};
 window.addEventListener('courtline-ready',()=>{setTimeout(()=>{domReady=true;mount();poll();},0);setInterval(poll,2000);});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){if(!window.CourtlineManagedSessions)clearUnlock();}else poll();});
})();
