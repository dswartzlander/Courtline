// Native Swift owns credentials and PIN entry. This adapter only hydrates safe UI state.
'use strict';
(() => {
 window.CourtlineDeviceName='CourtLine iPad';
 window.CourtlineManagedSessions=true;
 const config=JSON.parse(window.CourtlineNative.load());
 localStorage.setItem('courtline-scoreholio-v2',JSON.stringify(config.ui||{}));
 localStorage.removeItem('courtline-companion-role-v1');
 window.CourtlineInitialRole=window.CourtlineIOS.sessionRole();
 window.CourtlineInitialSettingsUnlocked=window.CourtlineIOS.settingsUnlocked()===true;
 document.body.classList.toggle('companion-viewer',window.CourtlineInitialRole!=='main');
})();
