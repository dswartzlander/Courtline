'use strict';
// Scoped Control/Companion clients consume Backend-authoritative court state.
// vMix remains responsible for synchronizing the telestrator drawing canvas.
(() => {
  const roleKey='courtline-companion-role-v1',idKey='courtline-companion-device-id-v1',nameKey='courtline-companion-name-v1';
  const uuid=()=>crypto.randomUUID().replace(/-/g,'');
  let deviceId=localStorage.getItem(idKey)||uuid();localStorage.setItem(idKey,deviceId);
  let role=window.CourtlineManagedSessions?(window.CourtlineInitialRole||'viewer'):'main',url='',lastControl=null,lastLive=0,busy=false,backendAuthority=false;
  let lastCourtWork=null,vmixCourtQueue=Promise.resolve(),liveIdentity=0;
  let lastConfirmedCourtRevision=null;
  // Only a Helper-confirmed vMix court change may refresh everyone’s browser.
  // A pending request or a failed vMix switch must not interrupt drawing.
  function refreshOnConfirmedCourt(selection){
    if(!Number.isInteger(selection?.revision))return;
    if(lastConfirmedCourtRevision===null){
      // A device joining an already selected court gets its normal initial page load.
      // If it joins during a switch, reload once that request is confirmed.
      lastConfirmedCourtRevision=selection.pending?selection.revision-1:selection.revision;
    }
    if(selection.pending||selection.error||!Number.isInteger(selection.court))return;
    if(selection.revision>lastConfirmedCourtRevision){
      lastConfirmedCourtRevision=selection.revision;
      window.courtlineReloadTelestrator?.();
    }
  }
  const api=()=>window.pywebview.api;
  const helperURL=()=>{try{return window.desktopCollectUI?.().scoreholioStats?.helperURL||'';}catch(_){return '';}};
  function saveRole(value,target) {role=value;localStorage.setItem(roleKey,JSON.stringify({role,url:target}));document.body.classList.toggle('companion-viewer',role==='viewer');}
  async function identify(target) {
    const identity=++liveIdentity;lastLive=0;if(url!==(target||''))window.invalidateCompanionStatsFormat?.();url=target||'';const requestedURL=url;backendAuthority=false;
    window.CourtlineBackendControl?.beginIdentity(url);
    let cached=null;try{cached=JSON.parse(localStorage.getItem(roleKey)||'null');}catch(_){}
    if(url&&cached?.url!==url)saveRole('viewer',url); // Unknown pairing fails closed until Helper verifies it.
    else if(cached?.url===url&&['main','viewer'].includes(cached.role))saveRole(cached.role,url);
    if(!url)return role;
    try{
      const session=await api().companion(requestedURL,'session');if(identity!==liveIdentity||url!==requestedURL)return role;
      if(!['main','viewer'].includes(session.role))throw Error('Unrecognized Helper role.');
      if(session.scopedSession&&typeof session.deviceId==='string')deviceId=session.deviceId;else deviceId=localStorage.getItem(idKey)||deviceId;
      saveRole(session.role,url);
      backendAuthority=session.dataAuthority==='backend';
      await window.CourtlineBackendControl?.identify(url,session);
    }catch(error){if(identity!==liveIdentity||url!==requestedURL)return role;lastLive=0;window.invalidateCompanionStatsFormat?.();window.CourtlineBackendControl?.identifyFailed(error);/* Offline pairing never regains local command authority. */}
    return role;
  }
  const defaultName=window.CourtlineDeviceName||'CourtLine iPad';
  const normalizeName=value=>String(value??'').trim().replace(/\s+/g,' ').slice(0,60)||defaultName;
  function name(){return normalizeName(localStorage.getItem(nameKey));}
  let bar,button,grant,deny,override,label,who,availability,rename,courtLabel,saveNameButton,nameFeedback,waitingNotice;
  function createControls(){
    // Shared drawing controls stay visible in the left-side panel while on Telestrator.
    const panel=document.getElementById('telestratorSettingsContents')||document.getElementById('telestratorSettingsControls')||document.getElementById('telestratorPanel');if(!panel)return;
    const wrap=document.createElement('section');bar=wrap;wrap.className='telestrator-owner-bar';
    wrap.setAttribute('aria-label','Shared telestrator control');
    who=document.createElement('strong');who.textContent='Telestrator controller: checking…';
    courtLabel=document.createElement('span');courtLabel.className='telestrator-shared-court';courtLabel.setAttribute('aria-live','polite');courtLabel.textContent='Showing court: checking…';
    availability=document.createElement('span');availability.className='telestrator-availability';
    // The display name is local to this device, not a privileged Helper setting.
    // It is included with every telestrator control request and heartbeat.
    const nameField=document.createElement('div');nameField.className='telestrator-device-name';
    const nameLabel=document.createElement('label');nameLabel.textContent='Device Name';
    const nameId='courtlineTelestratorDeviceName';nameLabel.htmlFor=nameId;
    rename=document.createElement('input');rename.id=nameId;rename.type='text';rename.maxLength=60;
    rename.autocomplete='off';rename.value=name();rename.placeholder='e.g. Coach Mike · Tablet';
    rename.setAttribute('aria-label','Device Name shown as telestrator controller');
    saveNameButton=document.createElement('button');saveNameButton.type='button';saveNameButton.textContent='Save Name';
    nameFeedback=document.createElement('span');nameFeedback.className='telestrator-name-feedback';nameFeedback.setAttribute('role','status');nameFeedback.setAttribute('aria-live','polite');
    nameField.append(nameLabel,rename,saveNameButton,nameFeedback);
    async function saveDeviceName(){
      const value=normalizeName(rename.value);
      try{localStorage.setItem(nameKey,value);}
      catch(_){nameFeedback.textContent='Could not save device name on this device.';return;}
      rename.value=value;
      nameFeedback.textContent='Saved · '+value;
      // The new name appears on all connected devices at their next poll.
      // Renaming does not take drawing control or modify the match data.
      if(lastControl?.holder?.deviceId===deviceId){
        renderControl({...lastControl,holder:{...lastControl.holder,name:value}});
      }
      if(url){
        try{await changeControl(lastControl?.holder?.deviceId===deviceId?'heartbeat':'status');}
        catch(_){/* Local save is still retained for reconnect. */}
      }
    }
    saveNameButton.addEventListener('click',()=>void saveDeviceName());
    rename.addEventListener('keydown',event=>{
      if(event.key==='Enter'){event.preventDefault();void saveDeviceName();}
      if(event.key==='Escape'){rename.value=name();}
    });
    button=document.createElement('button');button.type='button';button.textContent='Take Control';
    grant=document.createElement('button');grant.type='button';grant.hidden=true;
    deny=document.createElement('button');deny.type='button';deny.hidden=true;deny.textContent='Decline Request';
    override=document.createElement('button');override.type='button';override.hidden=true;override.textContent='Main Override';
    label=document.createElement('span');label.className='telestrator-control-feedback';label.setAttribute('role','status');
    waitingNotice=document.createElement('span');waitingNotice.className='telestrator-request-notice';waitingNotice.setAttribute('role','status');waitingNotice.hidden=true;waitingNotice.tabIndex=-1;
    wrap.append(nameField,who,courtLabel,availability,button,grant,deny,override,label,waitingNotice);
    panel.insertBefore(wrap,panel.querySelector?.('.telestrator-toolbar')||null);
    button.addEventListener('click',async()=>{
      const holder=lastControl?.holder;
      const action=holder?.deviceId===deviceId?'release':holder?'request':'acquire';
      await changeControl(action);
    });
    grant.addEventListener('click',async()=>{const next=lastControl?.waiting?.find(row=>row.deviceId!==deviceId);if(next)await changeControl('approve',{target:next.deviceId});});
    deny.addEventListener('click',async()=>{const next=lastControl?.waiting?.find(row=>row.deviceId!==deviceId);if(next)await changeControl('deny',{target:next.deviceId});});
    override.addEventListener('click',async()=>{if(confirm('Take telestrator control from the current device?'))await changeControl('force');});
  }
  function renderControl(state){
    lastControl=state;
    if(!who)return;
    const holder=state.holder,own=holder?.deviceId===deviceId;
    const canRespond=own||role==='main'; // Helper authorizes both the holder and the Main to handle requests.
    const waiting=(Array.isArray(state.waiting)?state.waiting:[]).filter(row=>row&&row.deviceId!==deviceId);
    const waiter=waiting[0],requestCount=canRespond?waiting.length:0;
    who.textContent=holder?'Telestrator controlled by '+holder.name:'Telestrator available';
    availability.textContent=own?'You have control':state.requested?'Your request is waiting':holder?'View only':'Ready to draw';
    button.textContent=own?'Release Control':holder?state.requested?'Request Pending':'Request Control':'Take Control';
    button.disabled=!!state.requested&&!own;
    grant.hidden=!canRespond||!waiter;
    deny.hidden=!canRespond||!waiter;
    if(waiter){grant.textContent='Grant Control to '+waiter.name;deny.textContent='Decline '+waiter.name;}
    waitingNotice.hidden=!requestCount;
    if(requestCount){
      const message=requestCount===1?waiter.name+' is requesting telestrator control.':requestCount+' devices are waiting for telestrator control. First: '+waiter.name;
      if(waitingNotice.textContent!==message)waitingNotice.textContent=message;
    }
    // This badge lives outside the dialog, so it remains visible even while
    // the settings are closed or a different live tab is selected.
    const settingsButton=document.getElementById('openTelestratorSettings');
    const requestBadge=document.getElementById('telestratorRequestBadge');
    if(settingsButton){
      settingsButton.classList.toggle('has-control-request',requestCount>0);
      settingsButton.setAttribute('aria-label',requestCount?`Telestrator Settings, ${requestCount} pending control ${requestCount===1?'request':'requests'}. Tap to respond.`:'Telestrator Controls');
      settingsButton.title=requestCount?`${requestCount} telestrator control request${requestCount===1?'':'s'} waiting — tap to respond`:'Show telestrator controls';
    }
    if(requestBadge){requestBadge.hidden=requestCount===0;requestBadge.textContent=requestCount?`${requestCount} REQUEST${requestCount===1?'':'S'}`:'';}
    override.hidden=role!=='main'||!holder||own;
    const selection=state.selection||{},court=selection.court;
    refreshOnConfirmedCourt(selection);
    courtLabel.textContent='Showing '+(Number.isInteger(court)?'Court '+(court+1):'no selected court')+
      (selection.pending?' · Switching to Court '+(selection.pending.court+1)+'…':'');
    label.textContent=selection.error||'';
    const status=document.getElementById('telestratorCommandStatus');
    if(selection.error&&status)status.textContent='Court switch failed: '+selection.error;
    for(let i=0;i<4;i++){
      const courtButton=document.getElementById('telestratorCourt'+i);
      if(courtButton)courtButton.setAttribute('aria-pressed',String(court===i));
    }
    document.body.classList.toggle('telestrator-controller',!!own);
    document.body.classList.toggle('telestrator-view-only',!own);
    document.body.classList.toggle('telestrator-court-selector',role==='main'||own);
  }
  // The Main is the only device with vMix shortcut settings. A Companion may
  // request a court, but cannot execute arbitrary vMix commands itself.
  async function applyPendingCourt(selection){
    if(backendAuthority||window.CourtlineBackendControl?.active||role!=='main'||!selection?.pending||!url)return;
    const {court,revision,requestId}=selection.pending;
    if(lastCourtWork?.requestId!==requestId){
      const perform=vmixCourtQueue.then(async()=>{
        try{
          window.desktopValidateVmixAddress?.();
          await window.desktopFlushUI?.();
          await api().telestrator_switch(court);
          return {revision,requestId,success:true};
        }catch(error){return {revision,requestId,success:false,error:String(error.message||error).slice(0,200)};}
      });
      vmixCourtQueue=perform.then(()=>{},()=>{});
      lastCourtWork={requestId,promise:perform,ack:null};
    }
    const work=lastCourtWork;
    if(!work.ack){
      work.ack=work.promise.then(result=>api().companion(url,'telestrator',{action:'courtApplied',deviceId,name:name(),...result}))
        .then(state=>{renderControl(state);return state;})
        .catch(error=>{work.ack=null;throw error;});
    }
    return work.ack;
  }
  async function selectCourt(court){
    if(!Number.isInteger(court)||court<0||court>3)throw Error('Invalid court selection.');
    if(!url)return {shared:false};
    if(role!=='main'&&lastControl?.holder?.deviceId!==deviceId)throw Error('Request telestrator control before choosing a court.');
    const state=await api().companion(url,'telestrator',{action:'selectCourt',deviceId,name:name(),court});
    renderControl(state);
    if(role==='main'&&!backendAuthority&&!window.CourtlineBackendControl?.active){
      const confirmed=await applyPendingCourt(state.selection);
      if(confirmed?.selection?.error)throw Error(confirmed.selection.error);
      return {shared:true,confirmed:true};
    }
    if(backendAuthority||window.CourtlineBackendControl?.active){if(state.selection?.error)throw Error(state.selection.error);return {shared:true,confirmed:!state.selection?.pending};}
    return {shared:true,confirmed:false};
  }
  async function changeControl(action,extra={}){
    if(!url)return;
    try{
      const state=await api().companion(url,'telestrator',{action,deviceId,name:name(),...extra});
      renderControl(state);
      if(role==='main'&&state.selection?.pending)void applyPendingCourt(state.selection).catch(error=>{label.textContent=error.message;});
    }catch(e){label.textContent=e.message;renderControl({holder:null,waiting:[]});}
  }
  async function updateLive(){
    if(!url||document.hidden)return;
    if(role==='main'&&!backendAuthority&&!window.CourtlineBackendControl?.active){
      const value=window.captureCompanionState?.();
      if(!value)return;
      await api().companion(url,'publishLive',{deviceId,...value});
    }else{
      const requestedURL=url,identity=liveIdentity;let result;try{result=await api().companion(requestedURL,'getLive');}catch(error){if(url===requestedURL&&identity===liveIdentity){lastLive=0;window.invalidateCompanionStatsFormat?.();}throw error;}if(url!==requestedURL||identity!==liveIdentity)return;
      const liveKey=JSON.stringify([requestedURL,identity,result.updatedAt,result.revision,result.stale,result.courts?.map(c=>[c.stale,c.error])]);
      if(result.snapshot&&liveKey!==lastLive){
        lastLive=liveKey;window.renderCompanionSnapshot?.(result.snapshot);
      }
      document.body.classList.toggle('companion-stale',result.stale===true);
    }
  }
  async function tick(){
    if(busy||document.hidden||!url)return;
    busy=true;const requestedURL=url,identity=liveIdentity;
    try{await Promise.all([updateLive(),changeControl(lastControl?.holder?.deviceId===deviceId?'heartbeat':'status')]);}
    catch(e){if(url!==requestedURL||identity!==liveIdentity)return;lastLive=0;window.invalidateCompanionStatsFormat?.();if(label)label.textContent='Helper connection: '+e.message;document.body.classList.add('companion-stale');}
    finally{busy=false;}
  }
  function begin(){
    createControls();
    if(role==='viewer'){
      document.body.classList.add('companion-viewer');
      window.courtlineGoLive?.();
    }
    if(!url){
      // Device name stays editable before pairing; only control actions require a Helper.
      if(bar){bar.classList.add('telestrator-unpaired');who.textContent='Not connected to Windows Helper';courtLabel.textContent='No shared court';}
      return;
    }
    tick();setInterval(tick,1500);
  }
  window.CourtlineCompanion={identify,begin,selectCourt,refreshLive:updateLive,get canSelectCourt(){return role==='main'||lastControl?.holder?.deviceId===deviceId;},get backendAuthority(){return backendAuthority||window.CourtlineBackendControl?.active;},get role(){return role;},get deviceId(){return deviceId;},get deviceName(){return name();},get url(){return url;}};
})();
