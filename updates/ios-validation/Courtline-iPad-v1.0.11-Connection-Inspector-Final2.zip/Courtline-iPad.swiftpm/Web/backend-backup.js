'use strict';
window.CourtlineConnectedBackup=(()=>{
 const names=['vmix',...Array.from({length:4},(_,i)=>['connection:'+i,'event:'+i,'exports:'+i,'matchup:'+i,'automation:'+i,'telestrator:'+i]).flat()];
 const clone=x=>JSON.parse(JSON.stringify(x));
 const object=x=>x&&typeof x==='object'&&!Array.isArray(x);
 function exact(x,keys,label){if(!object(x)||Object.keys(x).some(k=>!keys.includes(k)))throw Error('Invalid '+label+'.');}
 function clean(backup){
  exact(backup,['format','schemaVersion','createdAt','sections'],'Backend backup');
  if(backup.format!=='courtline-backend-settings'||backup.schemaVersion!==1||!object(backup.sections)||Object.keys(backup.sections).length!==25||names.some(n=>!object(backup.sections[n])))throw Error('Choose a complete supported Backend settings backup.');
  for(const [name,v] of Object.entries(backup.sections)){
   const type=name.split(':')[0],keys={vmix:['address'],connection:['eventSlot','court','visible','remoteURL'],event:['adminURL','name'],exports:['auto','seconds'],matchup:['enabled'],automation:['dry_run','poll_seconds','alarm_delay','match_alerts','require_matchup_stats','rows'],telestrator:['source','profile']}[type];exact(v,keys,'section '+name);
   const profile=type==='automation'?v:type==='telestrator'?v.profile:null;
   if(profile){if(type==='telestrator')exact(profile,['dry_run','rows'],'Telestrator profile');if(!Array.isArray(profile.rows)||profile.rows.length>200)throw Error('Invalid shortcut rows.');for(const row of profile.rows)exact(row,['id','enabled','trigger','command','delay',...(type==='automation'?['matchup','overlay_hold']:[])],'shortcut row');}
  }
  return clone(backup);
 }
 function local(ui){return {vmixInputs:ui.vmixInputs.slice(),autoRefresh:ui.autoRefresh,statsAuto:ui.scoreholioStats?.auto??false,statsSeconds:ui.scoreholioStats?.seconds??10};}
 function validateLocal(v){exact(v,['vmixInputs','autoRefresh','statsAuto','statsSeconds'],'iPad preferences');if(!Array.isArray(v.vmixInputs)||v.vmixInputs.length!==4||v.vmixInputs.some(x=>typeof x!=='string'||x.length>20000)||typeof v.autoRefresh!=='boolean'||typeof v.statsAuto!=='boolean'||!Number.isFinite(v.statsSeconds)||v.statsSeconds<5||v.statsSeconds>3600)throw Error('Invalid iPad preferences.');return clone(v);}
 function make(backend,ui){return JSON.stringify({format:'courtline-connected-settings',schemaVersion:1,backend:clean(backend),android:validateLocal(local(ui))},null,2);}
 function parse(text){if(typeof text!=='string'||new TextEncoder().encode(text).length>4000000)throw Error('Settings backup is too large.');let v;try{v=JSON.parse(text);}catch(_){throw Error('Settings file is not valid JSON.');}if(v.format==='courtline-backend-settings')return {backend:clean(v),android:null};exact(v,['format','schemaVersion','backend','android'],'connected backup');if(v.format!=='courtline-connected-settings'||v.schemaVersion!==1)throw Error('Use a connected Backend settings backup. Standalone backups must be restored in standalone mode.');return {backend:clean(v.backend),android:validateLocal(v.android)};}
 function differences(before,after,path=''){const out=[];for(const key of new Set([...Object.keys(before||{}),...Object.keys(after||{})])){const a=before?.[key],b=after?.[key],p=path?path+'.'+key:key;if(JSON.stringify(a)===JSON.stringify(b))continue;if(object(a)&&object(b))out.push(...differences(a,b,p));else out.push(p+': '+JSON.stringify(a??null)+' → '+JSON.stringify(b??null));}return out;}
 async function review(lines){return new Promise(resolve=>{const dialog=document.createElement('dialog');dialog.className='backend-restore-review';const title=document.createElement('h2');title.textContent='Review settings restore';const content=document.createElement('pre');content.textContent=lines.join('\n\n');const actions=document.createElement('div'),cancel=document.createElement('button'),apply=document.createElement('button');cancel.textContent='Cancel';apply.textContent='Restore these settings';actions.append(cancel,apply);dialog.append(title,content,actions);document.body.append(dialog);let done=false;const finish=value=>{if(done)return;done=true;dialog.close();dialog.remove();resolve(value);};cancel.onclick=()=>finish(false);apply.onclick=()=>finish(true);dialog.addEventListener('cancel',e=>{e.preventDefault();finish(false);});dialog.showModal();});}
 return {make,parse,local,clean,differences,review};
})();
