'use strict';
// Platform-neutral settings state. Revision belongs to the server; drafts never auto-rebase.
(function(root){
 const clone=value=>JSON.parse(JSON.stringify(value));
 class BackendControlModel{
  constructor(){this.reset('');}
  reset(identity){this.identity=identity;this.epoch=(this.epoch||0)+1;this.sections={};this.online=false;this.loaded=false;this.error='';}
  accept(snapshot,epoch=this.epoch){
   if(epoch!==this.epoch)return false;
   if(snapshot?.schemaVersion!==1||!snapshot.sections||typeof snapshot.sections!=='object')throw Error('Unsupported Backend settings response.');
   for(const [name,incoming] of Object.entries(snapshot.sections)){
    if(typeof incoming?.revision!=='string'||incoming.value===undefined)throw Error('Invalid Backend settings section.');
    const current=this.sections[name];
    if(!current||!current.dirty)this.sections[name]={revision:incoming.revision,value:clone(incoming.value),draft:clone(incoming.value),dirty:false,conflict:false};
    else {current.value=clone(incoming.value);current.conflict=current.revision!==incoming.revision;current.remoteRevision=incoming.revision;}
   }
   this.loaded=true;this.online=true;this.error='';this.snapshot=snapshot;return true;
  }
  edit(name,value){const s=this.sections[name];if(!s||!this.online)throw Error('Reconnect to Backend before editing.');s.draft=clone(value);s.dirty=JSON.stringify(s.draft)!==JSON.stringify(s.value);}
  request(name){const s=this.sections[name];if(!this.online||!s)throw Error('Backend unavailable. No changes were sent.');if(s.conflict)throw Error('This section changed on another device. Reload it before saving.');return {schemaVersion:1,section:name,expectedRevision:s.revision,value:clone(s.draft)};}
  committed(name,snapshot,epoch){if(epoch!==this.epoch)return false;delete this.sections[name];return this.accept(snapshot,epoch);}
  reload(name){const s=this.sections[name];if(!s)return;s.revision=s.remoteRevision||s.revision;s.draft=clone(s.value);s.dirty=false;s.conflict=false;delete s.remoteRevision;}
  offline(message){this.online=false;this.error=message||'Backend disconnected. Showing last known settings; editing is disabled.';}
 }
 root.BackendControlModel=BackendControlModel;
 if(typeof module!=='undefined')module.exports=BackendControlModel;
})(typeof window==='undefined'?globalThis:window);
