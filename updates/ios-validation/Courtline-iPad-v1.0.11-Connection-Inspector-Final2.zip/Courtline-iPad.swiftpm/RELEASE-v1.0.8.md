# iPad 1.0.8 candidate

Restores explicit Send to vMix through a dedicated native BrowserNavigate bridge. Generic native request access remains denied. The existing command queue, success/error feedback, alarms and no-retry behavior are retained; malformed responses no longer report success. Shared Backend settings and per-device authorization are unchanged. Native compilation and physical-device checks must be recorded separately.
