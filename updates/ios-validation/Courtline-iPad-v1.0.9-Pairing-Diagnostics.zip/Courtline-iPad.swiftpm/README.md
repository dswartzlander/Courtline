# CourtLine iPad 1.0.9

This editable Swift Playgrounds `.swiftpm` project brings the published iPad 1.0.6 layout forward to the Android 1.0.19 / Backend Test47 shared-settings and device-session contracts. It is not an IPA. Requires iPadOS 18 or later and Swift Playgrounds. The corresponding GitHub release records the exact-package Apple SDK typecheck, unsigned compile/link, and fake-transport native test results. The Swift Playgrounds package manifest/import, installation, and physical-device acceptance remain untested; passing compiler and JavaScript/API tests does not establish camera, touch, or live-network behavior.

## Pairing and access
1. Run Backend Test47 or a compatible newer version on your Windows PC.
2. In Backend Settings > Device Management, show Pair New Device. Each enrollment QR is single-use and refreshes after successful enrollment.
3. On iPad use Options > Pair Device, available without unlocking Settings. The Control/Companion switch also opens enrollment when unpaired. Cancel does not replace an existing connection.
4. New registrations start in Companion, with Control permission off. The owner names the device, enables Control View access, and sets that device's own PIN on the PC.
5. Switch to Control and enter the device PIN in the native prompt. No shared Settings PIN or Control QR exists. A cold launch starts in Companion; ordinary background/foreground navigation must not repeatedly ask for the PIN while the native grant remains valid.

Legacy shared Main/Viewer keys have been retired. Older pairings require fresh enrollment. Control permission off returns the device to Companion. App access off/revoke/remove invalidates enrollment and requires a new QR; follow the administrator notice.

## Settings and operation
Backend is authoritative for shared court/event, vMix, Automation, Telestrator, exports, and matchup settings. Pull from Backend refreshes clean fields and preserves drafts. Existing Apply buttons submit version-checked edits; conflicts require review/reload, never blind overwrite. Saving is separate from executing automation. Local browser destinations and display preferences remain local.

Connected backup/restore uses a reviewed Backend preview and explicit commit. It excludes pairing keys, PINs, account login, folders and installer state. The portable backup schema retains its historical `android` local-preferences field for compatibility; the iPad UI describes these as local iPad preferences. A lost commit response must not be automatically replayed.

Scoreholio account login, filesystem/export-folder selection, device/PIN administration and Backend installation remain PC-only. The iPad preserves independent court settings and the full-area native Telestrator with its settings dialog. Singles Stats expands only from verified Backend format evidence; partial/unknown doubles data remains four-player layout.

## Updates and development
Options > Updates checks published stable iPad ZIP assets, not Android APKs. One quiet automatic check per app launch is intended; navigation does not repeat it. Install/reopen the downloaded Swift Playgrounds project manually. No automatic IPA install is claimed.

Edit Web sources then regenerate embedded resources with `python Tests/generate-resources.py`. The generated CourtlineResources.swift must exactly match Web before packaging. Preserve the app bundle identifier to retain existing local preferences, but never import legacy credentials into the new scoped session.

Historical RELEASE files describe old releases and are not current security or setup guidance. See ACCEPTANCE-1.0.8.md for remaining native checks.

Widget sends use authorization and assignment preflight snapshots. A command already dispatched to vMix cannot be recalled if permissions or settings subsequently change. A missing or late confirmation is reported as uncertain and is not retried automatically.

## 1.0.9 pairing diagnostics
Pairing failures now show bounded, specific guidance for transport timeout, connection, permission, expired QR, invalid response, or secure-storage failure. This diagnostic update does not establish the cause of a particular device failure and does not relax network or authentication policy. Check Backend Device Management before retrying an uncertain enrollment. Actual iPad LAN/camera testing remains required.
