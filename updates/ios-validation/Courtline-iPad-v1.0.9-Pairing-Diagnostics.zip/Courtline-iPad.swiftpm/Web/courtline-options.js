/* CourtLine Options navigation; preserved existing update/theme button handlers. */
(() => {
 'use strict';
 const trigger=document.getElementById('optionsButton'),menu=document.getElementById('courtlineOptionsMenu');
 const hiddenUpdates=document.getElementById('checkForUpdates'),hiddenThemes=document.getElementById('themeButton');
 if(!trigger||!menu||!hiddenUpdates||!hiddenThemes)return;
 if(menu.parentNode!==document.body)document.body.appendChild(menu);
 const hint=document.getElementById('courtlineOptionsUpdateHint'),badge=document.getElementById('courtlineUpdateBadge');
 function sync(){hint.hidden=badge.hidden;}
 function close(focus=false){if(menu.hidden)return;menu.hidden=true;trigger.setAttribute('aria-expanded','false');document.body.classList.remove('theme-menu-open');window.dispatchEvent(new Event('courtline-modal-change'));if(focus)trigger.focus();}
 function open(){menu.hidden=false;trigger.setAttribute('aria-expanded','true');document.body.classList.add('theme-menu-open');window.dispatchEvent(new Event('courtline-modal-change'));const r=trigger.getBoundingClientRect();menu.style.left=Math.max(8,Math.min(innerWidth-menu.offsetWidth-8,r.right-menu.offsetWidth))+'px';menu.style.top=Math.max(8,Math.min(innerHeight-menu.offsetHeight-8,r.bottom+6))+'px';sync();}
 trigger.addEventListener('click',e=>{e.stopPropagation();menu.hidden?open():close(true);});
 document.getElementById('courtlineOptionsClose').addEventListener('click',()=>close(true));
 document.getElementById('courtlineOptionsUpdates').addEventListener('click',()=>{close();hiddenUpdates.click();});
 document.getElementById('courtlineOptionsThemes').addEventListener('click',()=>{close();hiddenThemes.click();});
 function pairingError(error){
  // Only native bounded codes become user-facing diagnostics. Never echo URLs, tickets or backend text.
  const messages={
   PAIR_CHANGED:'The connection changed while pairing. Check Device Management, then scan a fresh enrollment code.',
   PAIR_TRANSPORT_POLICY:'iPad network security blocked the Backend connection. Check that the app allows your local Backend address.',
   PAIR_TIMEOUT:'Backend did not confirm enrollment in time. Check Wi-Fi and Device Management before scanning a fresh code.',
   PAIR_LOCAL_NETWORK:'The connection may be blocked by a network restriction. Check Local Network permission and Wi-Fi.',
   PAIR_OFFLINE:'Backend could not be reached. Check shared Wi-Fi and local-network access for this app.',
   PAIR_CONNECT:'iPad could not connect to the Backend address. Check that Backend is running and both devices can reach that network.',
   PAIR_NETWORK:'Backend could not be reached or its response was interrupted. Check Wi-Fi and Backend Device Management before trying a fresh code.',
   PAIR_INVALID_QR:'This is not a valid enrollment code. Use Pair New Device in Backend Device Management, not the Android installer code.',
   PAIR_EXPIRED:'That enrollment code expired or was already used. Check whether this iPad registered, then show a fresh Pair New Device code.',
   PAIR_BACKEND_REJECTED:'Backend did not accept this enrollment. Check Device Management and use a fresh Pair New Device code.',
   PAIR_RESPONSE_INVALID:'Backend responded, but this iPad could not verify the new device registration. Check Device Management before trying again.',
   PAIR_STORAGE:'The registration could not be saved securely on this iPad. Check Device Management before retrying.',
   PAIR_BUSY:'Another connection or dialog is still open. Finish it, then try Pair Device again.',
   PAIR_CAMERA_DENIED:'Camera access is not allowed. Enable camera access for CourtLine in iPad Settings.',
   PAIR_CAMERA_UNAVAILABLE:'The camera scanner could not start. Close other camera apps and try again.'
  };
  return messages[String(error?.message||'')]||'Pairing was not confirmed. Check Backend Device Management before scanning a fresh code.';
 }
 const pair=document.getElementById('courtlineOptionsPair'),pairStatus=document.getElementById('courtlinePairStatus');
 pair.addEventListener('click',async()=>{
  if(pair.disabled)return;pair.disabled=true;pairStatus.textContent='Scan the enrollment QR, then wait for Backend confirmation…';close();
  try{const result=await window.pywebview.api.scan_stats_helper();pairStatus.textContent=result===null?'Pairing canceled. Existing connection unchanged.':'Device enrollment handled by the app.';}
  catch(error){pairStatus.textContent=pairingError(error);open();}
  finally{pair.disabled=false;}
 });
 document.addEventListener('pointerdown' ,e=>{if(!menu.hidden&&!menu.contains(e.target)&&!trigger.contains(e.target))close();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!menu.hidden){e.preventDefault();close(true);}});
 window.addEventListener('resize',()=>close());
 if(badge)new MutationObserver(sync).observe(badge,{attributes:true,attributeFilter:['hidden']});
 sync();
})();
