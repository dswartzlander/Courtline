import UIKit
import AVFoundation

final class HelperQRScanner: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var result: ((String?, String?) -> Void)?
    var resultWillDismiss:(()->Void)?
    private let session = AVCaptureSession()
    private let queue = DispatchQueue(label: "courtline.qr.camera")
    private var preview: AVCaptureVideoPreviewLayer!
    private var finished = false
    private var rotationCoordinator:AVCaptureDevice.RotationCoordinator?
    private var rotationObservation:NSKeyValueObservation?
    private let hint = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Scan Backend Enrollment QR"
        view.backgroundColor = .black
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancel))
        preview = AVCaptureVideoPreviewLayer(session: session)
        preview.videoGravity = .resizeAspectFill
        view.layer.addSublayer(preview)
        hint.text = "Point the camera at the single-use enrollment QR in Backend Device Management."
        hint.textColor = .white
        hint.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        hint.numberOfLines = 0
        hint.textAlignment = .center
        hint.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(hint)
        NSLayoutConstraint.activate([
            hint.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 16),
            hint.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -16),
            hint.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -24),
            hint.heightAnchor.constraint(greaterThanOrEqualToConstant: 64)
        ])
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized: startCamera()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] allowed in
                DispatchQueue.main.async {
                    guard let self = self, !self.finished else { return }
                    if allowed { self.startCamera() }
                    else { self.complete(nil, "PAIR_CAMERA_DENIED") }
                }
            }
        default: DispatchQueue.main.async { [weak self] in self?.complete(nil, "PAIR_CAMERA_DENIED") }
        }
    }

    private func startCamera() {
        queue.async { [weak self] in
            guard let self = self else { return }
            do {
                guard let camera = AVCaptureDevice.default(for: .video) else { throw ScanError.unavailable }
                let input = try AVCaptureDeviceInput(device: camera)
                let output = AVCaptureMetadataOutput()
                self.session.beginConfiguration()
                guard self.session.canAddInput(input), self.session.canAddOutput(output) else {
                    self.session.commitConfiguration(); throw ScanError.unavailable
                }
                self.session.addInput(input)
                self.session.addOutput(output)
                output.setMetadataObjectsDelegate(self, queue: .main)
                guard output.availableMetadataObjectTypes.contains(.qr) else {
                    self.session.commitConfiguration(); throw ScanError.unavailable
                }
                output.metadataObjectTypes = [.qr]
                self.session.commitConfiguration()
                self.session.startRunning()
                DispatchQueue.main.async { [weak self] in
                    guard let self=self,!self.finished else{return}
                    let rotation=AVCaptureDevice.RotationCoordinator(device:camera,previewLayer:self.preview)
                    self.rotationCoordinator=rotation
                    self.rotationObservation=rotation.observe(\.videoRotationAngleForHorizonLevelPreview,options:[.initial,.new]) { [weak self] _,_ in
                        DispatchQueue.main.async {self?.updatePreviewOrientation()}
                    }
                    self.updatePreviewOrientation()
                }
            } catch {
                DispatchQueue.main.async { self.complete(nil, "PAIR_CAMERA_UNAVAILABLE") }
            }
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        preview.frame = view.bounds
        updatePreviewOrientation()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        updatePreviewOrientation()
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to:size,with:coordinator)
        coordinator.animate(alongsideTransition:nil) { [weak self] _ in self?.updatePreviewOrientation() }
    }
    private func updatePreviewOrientation() {
        guard !finished,let connection=preview?.connection,let rotation=rotationCoordinator else{return}
        // Camera-sensor-aware angle, recalculated for this preview layer. The
        // connection is not available during initial layout; reapply after start.
        let angle=rotation.videoRotationAngleForHorizonLevelPreview
        if connection.isVideoRotationAngleSupported(angle) {connection.videoRotationAngle=angle}
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        queue.async { [weak self] in self?.session.stopRunning() }
    }

    @objc private func cancel() { complete(nil, nil) }
    private func complete(_ text: String?, _ error: String?) {
        guard !finished else { return }
        finished = true
        rotationObservation=nil;rotationCoordinator=nil
        queue.async { [weak self] in self?.session.stopRunning() }
        resultWillDismiss?();resultWillDismiss=nil
        let callback = result
        result = nil
        dismiss(animated: true) { callback?(text, error) }
    }

    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard !finished, let object = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
              let text = object.stringValue, text.utf8.count <= 20000 else { return }
        guard let parts = URLComponents(string: text), ["http", "https"].contains(parts.scheme ?? ""),
              let host = parts.host, !host.isEmpty, !["localhost", "127.0.0.1", "::1", "[::1]"].contains(host.lowercased()),
              parts.path == "/api/stats", parts.user == nil, parts.password == nil, parts.fragment == nil,
              let key = parts.queryItems?.first(where: { $0.name == "key" })?.value, key.range(of: "^en_[a-f0-9]{64}$", options: .regularExpression) != nil else {
            hint.text = "That is not an enrollment code. Scan the current QR in Backend Device Management."; return
        }
        complete(text, nil)
    }
    private enum ScanError: Error { case unavailable }
}
