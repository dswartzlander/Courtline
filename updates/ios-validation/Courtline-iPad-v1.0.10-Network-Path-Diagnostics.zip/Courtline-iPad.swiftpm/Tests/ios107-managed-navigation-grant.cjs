// Full bundled navigation/visibility regression, adapted from promotion-settings-grant fixture.
const {JSDOM,ResourceLoader,VirtualConsole}=require('/workspace/scratch/4d9aa462dfa7/android_source/test-tools/node_modules/jsdom');const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const version=process.argv[2]||'1.0.10';if(!version){const {spawnSync}=require('node:child_process');for(const v of ['1.0.14','1.0.18']){const r=spawnSync(process.execPath,[__filename,v],{stdio:'inherit'});if(r.status!==0)process.exit(r.status||1);}process.exit(0);}
const dir=path.resolve(__dirname,'../Web'),clone=x=>JSON.parse(JSON.stringify(x));
const sections={vmix:{revision:'vmix-r1',value:{address:'http://192.0.2.50:8088'}}};
for(let i=0;i<4;i++)for(const [kind,value] of Object.entries({connection:{eventSlot:i,court:i+1,visible:true,remoteURL:'https://app.scoreholio.com/overlay?account=fixture-account&did=device'+i},event:{adminURL:'',name:'Event '+i},exports:{auto:false,seconds:60},matchup:{enabled:false},automation:{dry_run:true,poll_seconds:.5,alarm_delay:5,match_alerts:false,require_matchup_stats:false,rows:[{id:'a'+i,enabled:true,trigger:'Round complete',command:'Function=Cut&Input=2',delay:3,matchup:'singles'}]},telestrator:{source:'Camera '+(i+1),profile:{dry_run:false,rows:[{id:'t'+i,enabled:true,trigger:'Button press',command:'Function=Cut&Input=3',delay:0}]}}}))sections[kind+':'+i]={revision:kind+'-'+i+'-r1',value};
const snapshot=()=>clone({schemaVersion:1,sections,capabilities:{editable:Object.keys(sections),readOnly:[],actions:[],backendOnly:[],unavailable:[]},lock:{enabled:false,revision:''}});
const automation=Array.from({length:4},()=>({running:false,armed:false,status:{},alarms:[],logs:[],dry_run:true}));
let nativeGrant=true,nativePrompts=0;let patches=[],calls=[],errors=[],offline=false,failAuth=false,n=1,holdGet=false,releaseGet=null,unsupported=0,saveWarning=false,rejectPatch=false,dropRestore=false;
class Loader extends ResourceLoader{fetch(url){const basename=new URL(url).pathname.split('/').pop();const file=basename==='engine.js'&&process.env.REPRO_111?path.resolve(dir,'../../Courtline-Android-v1.0.11/assets/engine.js'):path.join(dir,basename);return fs.existsSync(file)?Promise.resolve(fs.readFileSync(file)):Promise.resolve(Buffer.from(''));}}
const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(fs.readFileSync(path.join(dir,'index.html'),'utf8'),{url:'https://courtline.test/index.html',runScripts:'dangerously',resources:new Loader(),pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
 w.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});w.ResizeObserver=class{observe(){}disconnect(){}};w.confirm=()=>true;w.HTMLElement.prototype.scrollIntoView=function(){};w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new w.Event('close'));};w.fetch=async()=>({ok:true,json:async()=>({})});
 const config={ui:{urls:['','','',''],pairings:[null,null,null,null],visibleCourts:[true,true,true,true],vmixInputs:['local-browser','','',''],telestratorSources:['','','',''],vmixHost:'http://192.0.2.9:8088',scoreholioStats:{helperURL:'http://192.0.2.40:8765/api/stats?key=fixture',auto:false,seconds:10}}};
 w.CourtlineAndroid={beginPage:()=>"navigation-page",sessionManaged:()=>true,sessionRole:()=> 'main',settingsUnlocked:()=>nativeGrant,unlockSettings:()=>{nativePrompts++;},load:()=>JSON.stringify(config),save:()=>true,dispatch(text){const {method,args}=JSON.parse(text);calls.push({method,args});const [id,url,op,payload]=args;const reply=(value,error)=>setTimeout(()=>w.platformReply(id,value,error),0);
 if(['open','telestrator'].includes(method))return;
 if(method==='companion'){if(op==='session')return reply({role:'main',scopedSession:true,deviceId:'session_fixture',controlAllowed:false,dataAuthority:'backend',settingsLock:{enabled:false,revision:''}});if(op==='getLive')return reply({snapshot:null,updatedAt:1,stale:false});return reply({holder:null,waiting:[],selection:{court:null,revision:0,pending:null,error:''}});}
 if(method==='settingsLock'){if(op.action==='lock')nativeGrant=false;return reply({enabled:true,revision:'policy',unlocked:nativeGrant,nativeUnlocked:nativeGrant});}
 if(method==='controlSettings'){
  if(offline)return reply(null,'Offline');if(op==='get'){if(unsupported===404)return reply({httpStatus:404,error:'Not found.'});const snap=snapshot();if(unsupported===99)snap.schemaVersion=99;if(holdGet){releaseGet=()=>reply(snap);return;}return reply(snap);}if(op==='state')return reply({automation,live:{},telestrator:{}});
  if(op==='action')return reply({ok:true,state:{automation}});
  if(op==='backup')return reply({format:'courtline-backend-settings',schemaVersion:1,createdAt:new Date().toISOString(),sections:Object.fromEntries(Object.entries(sections).map(([n,s])=>[n,clone(s.value)])),httpStatus:200});
  if(op==='restore'){
   if(payload.action==='preview'){w.fixtureRestore=payload.backup;return reply({previewId:'fixture-preview',changes:['vmix'],stagedSections:clone(payload.backup.sections),derivedEvents:[],automationWillStop:true,controlSettings:snapshot()});}
   if(rejectPatch)return reply({httpStatus:409,error:'Restore conflict',code:'conflict',controlSettings:snapshot()});
   for(const [n,v] of Object.entries(w.fixtureRestore.sections)){sections[n].value=clone(v);sections[n].revision='restored-'+(++nRestore);}
   if(dropRestore)return reply(null,'Connection lost after request');
   return reply({...snapshot(),restored:true,changed:true,automationStopped:true});
  }
  if(op==='patch'){patches.push(clone(payload));if(rejectPatch)return reply({httpStatus:400,error:'Fixture validation: choose a valid court'});if(failAuth)return reply({httpStatus:403,error:'Unlock expired'});const old=sections[payload.section];if(old.revision!==payload.expectedRevision)return reply({httpStatus:409,error:'Conflict',code:'conflict',controlSettings:snapshot()});old.value=clone(payload.value);old.revision='new-'+(++n);return reply({...snapshot(),...(saveWarning?{warning:'Settings saved; runtime needs Backend restart.'}:{})});}
 }
 if(method==='restoreLocalPreferences'){config.ui.vmixInputs=clone(op.vmixInputs);config.ui.autoRefresh=op.autoRefresh;config.ui.scoreholioStats.auto=op.statsAuto;config.ui.scoreholioStats.seconds=op.statsSeconds;return reply(clone(config));}
 if(method==='scanStatsHelper')return reply({handled:true});if(method==='persistSettings')return reply(true);
 if(method==='statsHelper')return reply({records:[]});if(method==='request')return reply({status:200,text:'{}'});if(method==='checkUpdates')return reply({status:200,text:'[]'});
 reply(null,'Unsupported mock '+method);
 }};

 const mock=w.CourtlineAndroid;delete w.CourtlineAndroid;
 w.CourtlinePageID='ios-fixture-page';w.CourtlineIOS={sessionRole:()=>mock.sessionRole?.()||'main',settingsUnlocked:()=>mock.settingsUnlocked?.()??true};
 w.CourtlineNative={load:mock.load,save:mock.save,unlockSettings:()=>mock.unlockSettings?.(),switchRole:()=>{}};
 for(const name of ['open','telestrator','scanStatsHelper','statsHelper','statsAssignments','settingsLock','companion','controlSettings','restoreLocalPreferences','exportSettings','importSettings','persistSettings','snapshot','request','checkUpdates','downloadUpdate'])w.CourtlineNative[name]=(...args)=>mock.dispatch(JSON.stringify({pageId:w.CourtlinePageID,method:name,args}));
}});
let nRestore=0;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

(async()=>{await sleep(650);const w=dom.window,d=w.document,baseline=version==='1.0.14';const lockCount=()=>calls.filter(c=>c.method==='settingsLock'&&c.args[2].action==='lock').length;const state=()=>w.dispatchEvent(new w.CustomEvent('courtline-native-settings-state',{detail:{nativeUnlocked:nativeGrant,enabled:true,revision:'policy'}}));assert.equal(w.CourtlineCompanion.role,'main');assert(nativeGrant);assert.equal(nativePrompts,0);
 const before=lockCount();for(let i=0;i<3;i++){w.courtlineGoLive();await sleep(20);if(!baseline)assert.equal(d.querySelector('#viewSettings [data-lock-state]')?.getAttribute('data-lock-state'),'unlocked','Live icon reflects validated grant');d.getElementById('viewSettings').click();await sleep(20);}
 const navLocks=lockCount()-before;assert.equal(nativeGrant,!baseline);if(baseline)assert(navLocks>0);else {assert.equal(navLocks,0);assert.equal(nativePrompts,0);assert(!d.body.classList.contains('display-mode'));}
 // Restore mock authority for an independent visibility test, not a PIN bypass.
 nativeGrant=true;state();const beforeBackground=lockCount(),promptsBefore=nativePrompts;
 let hidden=false;Object.defineProperty(d,'hidden',{configurable:true,get:()=>hidden});for(let i=0;i<3;i++){hidden=true;d.dispatchEvent(new w.Event('visibilitychange'));await sleep(20);hidden=false;d.dispatchEvent(new w.Event('visibilitychange'));await sleep(40);}
 const backgroundLocks=lockCount()-beforeBackground;assert.equal(nativeGrant,!baseline);if(baseline)assert(backgroundLocks>0);else {assert.equal(backgroundLocks,0);assert.equal(nativePrompts,promptsBefore);}
 if(!baseline){
  w.CourtlineSettingsLock.relock();await sleep(30);assert.equal(nativeGrant,false,'explicit relock still revokes');assert(lockCount()>beforeBackground);
  nativeGrant=true;state();assert(!w.CourtlineSettingsLock.locked());
  // Simulate native expiry observed by the real event handler; cannot grant access.
  nativeGrant=false;const oldPrompts=nativePrompts;state();assert(w.CourtlineSettingsLock.locked());assert(nativePrompts>oldPrompts,'native expiry must still request PIN');assert.equal(nativeGrant,false);w.courtlineGoLive();assert.equal(d.querySelector('#viewSettings [data-lock-state]')?.getAttribute('data-lock-state'),'locked','revoked native state relocks icon');
 }
 assert.equal(errors.length,0,errors.join('\n'));console.log(JSON.stringify({version,navLocks,backgroundLocks,result:'PASS',scope:'actual bundled UI; native authority mocked'}));dom.window.close();process.exit(0);})().catch(error=>{console.error(error);console.error(errors);dom.window.close();process.exitCode=1;});
