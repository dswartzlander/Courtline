import Foundation
import UIKit
import WebKit
import UniformTypeIdentifiers

private final class WeakBridge: NSObject, WKScriptMessageHandler {
    weak var owner: CourtlineViewController?
    init(_ owner: CourtlineViewController) { self.owner = owner }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        owner?.receive(message)
    }
}

private final class NoRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

final class CourtlineViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, UIDocumentPickerDelegate {
    private var settingsImportReply: String?
    private var ui: WKWebView!
    private var telestrator: WKWebView!
    private var telestratorURL: URL?
    private var companionVmixURL: URL?
    private var viewerMode = true
    private let broker = CourtlineSessionBroker()
    private var sessionTimer: Timer?
    private var nativePINOpen = false
    private var automaticUpdateChecked = false
    private var telestratorLeaseEpoch = 0
    private var courts: [WKWebView] = []
    private var urls = Array(repeating: "", count: 4)
    private var loaded = Array(repeating: false, count: 4)
    private var epochs = Array(repeating: 0, count: 4)
    private var webRoot: URL!
    private var foreground = true
    private var needsReminder = false
    private var closed = false
    private var uiGeneration = 0
    private let settingsKey = "courtline.ipadtest.config.v1"
    private let noRedirects = NoRedirects()
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 12
        config.timeoutIntervalForResource = 20
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.httpCookieStorage = nil
        config.urlCache = nil
        config.waitsForConnectivity = false
        return URLSession(configuration: config, delegate: noRedirects, delegateQueue: nil)
    }()

    private func bridgeBootstrap(_ saved: String) -> String {
        return """
        (() => {
          let settings = \(json(safeSettings(saved)));
          const page = \(json(broker.page));
          window.CourtlinePageID = page; window.CourtlineManagedSessions = true;
          let role = \(json(broker.role)), unlocked = \(broker.unlocked ? "true" : "false");
          window.CourtlineIOS = {sessionRole:()=>role,settingsUnlocked:()=>unlocked,needsEnrollment:()=>\(broker.helperURL.isEmpty || broker.revoked ? "true" : "false")};
          window.addEventListener('courtline-native-settings-state', e=>{unlocked=e.detail.nativeUnlocked===true;});
          const send = (method,args) => window.webkit.messageHandlers.courtline.postMessage({method,args,page});
          window.CourtlineNative = {
            load:()=>settings,
            save:value=>{JSON.parse(value);send('save',[value]);return true;},
            open:(slot,url)=>send('open',[slot,url]),telestrator:frame=>send('telestrator',[frame]),
            scanStatsHelper:id=>send('scanStatsHelper',[id]),switchRole:()=>send('switchRole',[]),unlockSettings:()=>send('unlockSettings',[]),
            statsHelper:(id,url,refresh)=>send('statsHelper',[id,url,refresh]),
            statsAssignments:(id,url,rows)=>send('statsAssignments',[id,url,rows]),
            settingsLock:(id,url,value)=>send('settingsLock',[id,url,value]),
            companion:(id,url,action,payload)=>send('companion',[id,url,action,payload]),
            controlSettings:(id,url,action,payload)=>send('controlSettings',[id,url,action,payload]),
            restoreLocalPreferences:(id,url,value)=>send('restoreLocalPreferences',[id,url,value]),
            exportSettings:(id,text)=>send('exportSettings',[id,text]),importSettings:id=>send('importSettings',[id]),
            persistSettings:(id,text)=>send('persistSettings',[text,id]),snapshot:(id,slot)=>send('snapshot',[id,slot]),
            request:(id,url,method,body,type)=>send('request',[id,url,method,body,type]),
            checkUpdates:(id,automatic=false)=>send('checkUpdates',[id,automatic]),downloadUpdate:(id,url,name)=>send('downloadUpdate',[id,url,name])
          };
        })();
        """
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        let root: URL
        do {
            root = try CourtlineResources.install()
        } catch {
            let label = UILabel(frame: view.bounds)
            label.text = "Courtline could not prepare its interface: " + error.localizedDescription
            label.textColor = .white
            label.numberOfLines = 0
            label.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            view.addSubview(label)
            return
        }
        webRoot = root.standardizedFileURL
        for _ in 0..<4 {
            let config = WKWebViewConfiguration()
            config.websiteDataStore = .default()
            let court = WKWebView(frame: CGRect(x: -1600, y: 0, width: 1280, height: 720), configuration: config)
            court.navigationDelegate = self
            court.isUserInteractionEnabled = false
            view.addSubview(court)
            courts.append(court)
        }
        let config = WKWebViewConfiguration()
        let content = WKUserContentController()
        content.add(WeakBridge(self), name: "courtline")
        let bootstrap = bridgeBootstrap(UserDefaults.standard.string(forKey: settingsKey) ?? "{}")
        content.addUserScript(WKUserScript(source: bootstrap, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        config.userContentController = content
        ui = WKWebView(frame: .zero, configuration: config)
        ui.navigationDelegate = self
        ui.uiDelegate = self
        ui.isOpaque = false
        ui.backgroundColor = .black
        ui.scrollView.backgroundColor = .black
        ui.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(ui)
        NSLayoutConstraint.activate([
            ui.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            ui.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            ui.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            ui.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        let browserConfig = WKWebViewConfiguration()
        browserConfig.allowsInlineMediaPlayback = true
        browserConfig.mediaTypesRequiringUserActionForPlayback = []
        telestrator = WKWebView(frame: .zero, configuration: browserConfig)
        telestrator.navigationDelegate = self
        telestrator.uiDelegate = self
        telestrator.isHidden = true
        telestrator.isOpaque = false
        telestrator.backgroundColor = .black
        telestrator.scrollView.bounces = false
        telestrator.accessibilityLabel = "vMix telestrator"
        let savedConfig = UserDefaults.standard.string(forKey: settingsKey) ?? "{}"
        let settings = (try? JSONSerialization.jsonObject(with: Data(savedConfig.utf8))) as? [String: Any]
        let savedUI = settings?["ui"] as? [String: Any]
        let helper = savedUI?["scoreholioStats"] as? [String: Any]
        telestrator.isUserInteractionEnabled = !viewerMode && (helper?["helperURL"] as? String ?? "").isEmpty
        view.addSubview(telestrator)
        ui.loadFileURL(root.appendingPathComponent("index.html"), allowingReadAccessTo: root)
        NotificationCenter.default.addObserver(self, selector: #selector(leaving), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(returning), name: UIApplication.didBecomeActiveNotification, object: nil)
        UIApplication.shared.isIdleTimerDisabled = true
        broker.changed = { [weak self] in self?.reloadManagedUI() }
        broker.accessLost = { [weak self] in self?.showAccessLost() }
        broker.coldStart { [weak self] _ in self?.reloadManagedUI() }
        sessionTimer = Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { [weak self] _ in
            guard let self=self,self.foreground,!self.broker.helperURL.isEmpty else{return}
            self.broker.refreshSession { [weak self] _ in self?.publishNativeState() }
        }
    }

    @objc private func leaving() {
        guard !closed, ui != nil else { return }
        foreground = false
        needsReminder = true
        // Stop native reads immediately, even if WebKit suspends before JS runs.
        for i in courts.indices { loaded[i] = false; epochs[i] += 1; courts[i].stopLoading() }
        ui.evaluateJavaScript("window.platformSuspend&&window.platformSuspend({preserveBackendGrant:true});window.dispatchEvent(new Event('courtline-monitoring-stopped'))", completionHandler: nil)
        UIApplication.shared.isIdleTimerDisabled = false
    }

    @objc private func returning() {
        guard !closed, ui != nil else { return }
        foreground = true
        UIApplication.shared.isIdleTimerDisabled = true
        guard needsReminder else { return }
        needsReminder = false
        // Repeat the stop on return to cover JS suspended before the previous call.
        ui.evaluateJavaScript("window.platformSuspend&&window.platformSuspend({preserveBackendGrant:true});window.dispatchEvent(new Event('courtline-monitoring-stopped'))", completionHandler: nil)

    }

    func shutdown() {
        sessionTimer?.invalidate();sessionTimer=nil
        guard !closed else { return }
        leaving()
        closed = true
        session.invalidateAndCancel()
        statsHelperSession.invalidateAndCancel()
        NotificationCenter.default.removeObserver(self)
        ui?.configuration.userContentController.removeScriptMessageHandler(forName: "courtline")
        for court in courts { court.stopLoading(); court.navigationDelegate = nil }
        telestrator?.stopLoading()
        telestrator?.navigationDelegate = nil
        telestrator?.uiDelegate = nil
        ui?.stopLoading()
        UIApplication.shared.isIdleTimerDisabled = false
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        guard let id = settingsImportReply else { return }
        settingsImportReply = nil
        reply(id, value: NSNull())
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let id = settingsImportReply else { return }
        settingsImportReply = nil
        guard let url = urls.first else { reply(id, error: "No file selected."); return }
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            guard let size = attributes[.size] as? NSNumber, size.intValue <= 4_000_000 else {
                reply(id, error: "Settings file is too large."); return
            }
            let data = try Data(contentsOf: url)
            guard data.count <= 4_000_000, let text = String(data: data, encoding: .utf8) else {
                reply(id, error: "Settings file must be UTF-8 JSON."); return
            }
            controller.dismiss(animated: true) { [weak self] in self?.reply(id, value: text) }
        } catch { reply(id, error: error.localizedDescription) }
    }

    private func json(_ value: Any) -> String {
        guard let bytes = try? JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed]),
              let string = String(data: bytes, encoding: .utf8) else { return "null" }
        return string
    }

    private func reply(_ id: String, value: Any? = nil, error: String? = nil) {
        guard !closed, ui != nil, id.hasPrefix(broker.page + ":") else { return }
        let code = "window.platformReply&&window.platformReply(\(json(id)),\(json(value ?? NSNull())),\(json(error as Any? ?? NSNull())))"
        ui.evaluateJavaScript(code, completionHandler: nil)
    }

    private func allowedOverlay(_ url: URL) -> Bool {
        url.scheme == "https" && url.host == "app.scoreholio.com" && url.user == nil && url.password == nil
    }

    private func trustedUI(_ url: URL?) -> Bool {
        guard let url = url, let root = webRoot, url.isFileURL else { return false }
        return url.standardizedFileURL.path.hasPrefix(root.path + "/")
    }

    func receive(_ message: WKScriptMessage) {
        guard !closed, foreground, message.webView === ui, message.frameInfo.isMainFrame,
              trustedUI(message.frameInfo.request.url),
              let body = message.body as? [String: Any],
              let method = body["method"] as? String,
              let args = body["args"] as? [Any], body["page"] as? String == broker.page else { return }
        if handleManaged(method,args) { return }
        switch method {
        case "scanStatsHelper":
            guard let id = args.first as? String else { return }
            guard foreground, presentedViewController == nil else { reply(id, error: "Close the current dialog first."); return }
            let scanner = HelperQRScanner()
            scanner.result = { [weak self] text, error in
                if let error = error { self?.reply(id, error: error) }
                else { self?.reply(id, value: text as Any? ?? NSNull()) }
            }
            let navigation = UINavigationController(rootViewController: scanner)
            navigation.isModalInPresentation = true
            present(navigation, animated: true)
        case "switchCompanion":
            return
        case "statsHelper": return
        case "settingsLock": return
        case "statsAssignments": return
        case "companion": return
        case "exportSettings":
            guard args.count == 2, let id = args[0] as? String, let text = args[1] as? String else { return }
            guard foreground, presentedViewController == nil, text.utf8.count <= 4_000_000,
                  let data = text.data(using: .utf8),
                  (try? JSONSerialization.jsonObject(with: data)) is [String: Any] else {
                reply(id, error: "Cannot export settings right now."); return
            }
            do {
                let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let file = directory.appendingPathComponent("Courtline-Settings.json")
                try Data(redactedExport(text).utf8).write(to: file, options: .atomic)
                let sheet = UIActivityViewController(activityItems: [file], applicationActivities: nil)
                sheet.popoverPresentationController?.sourceView = view
                sheet.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
                sheet.completionWithItemsHandler = { [weak self] _, completed, _, error in
                    defer { try? FileManager.default.removeItem(at: directory) }
                    if let error = error { self?.reply(id, error: error.localizedDescription) }
                    else { self?.reply(id, value: ["completed": completed]) }
                }
                present(sheet, animated: true)
            } catch { reply(id, error: error.localizedDescription) }
        case "importSettings":
            guard let id = args.first as? String else { return }
            guard foreground, presentedViewController == nil, settingsImportReply == nil else {
                reply(id, error: "Close the current dialog before importing settings."); return
            }
            settingsImportReply = id
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.json], asCopy: true)
            picker.delegate = self
            picker.allowsMultipleSelection = false
            present(picker, animated: true)
        case "save", "persistSettings":
            if viewerMode {
                if args.count > 1, let id = args[1] as? String { reply(id, error: "Companion mode cannot change CourtLine settings.") }
                return
            }
            guard let text = args.first as? String, text.utf8.count < 1_000_000,
                  let data = text.data(using: .utf8),
                  (try? JSONSerialization.jsonObject(with: data)) is [String: Any] else {
                if args.count > 1, let id = args[1] as? String { reply(id, error: "Invalid or oversized settings.") }
                return
            }
            UserDefaults.standard.set(safeSettings(text), forKey: settingsKey)
            // Keep future reloads seeded from the latest saved/imported configuration.
            let content = ui.configuration.userContentController
            content.removeAllUserScripts()
            content.addUserScript(WKUserScript(source: bridgeBootstrap(safeSettings(text)), injectionTime: .atDocumentStart, forMainFrameOnly: true))
            if args.count > 1, let id = args[1] as? String { reply(id, value: true) }
            if !telestrator.isHidden { loadTelestrator() }
        case "open":
            guard args.count == 2, let i = args[0] as? Int, courts.indices.contains(i),
                  let text = args[1] as? String else { return }
            guard text.isEmpty || (URL(string: text).map(allowedOverlay) == true) else { return }
            urls[i] = text; loaded[i] = false; epochs[i] += 1
            courts[i].stopLoading()
            if text.isEmpty { courts[i].loadHTMLString("", baseURL: nil) }
            else if foreground, let url = URL(string: text) { courts[i].load(URLRequest(url: url)) }
        case "snapshot":
            guard args.count == 2, let id = args[0] as? String,
                  let i = args[1] as? Int, courts.indices.contains(i) else { return }
            guard foreground, loaded[i] else { reply(id, error: "Waiting for Scoreholio overlay"); return }
            let expected = urls[i], epoch = epochs[i]
            courts[i].evaluateJavaScript("document.body ? document.body.innerText : ''") { [weak self] value, error in
                guard let self = self else { return }
                guard self.foreground, self.urls[i] == expected, self.epochs[i] == epoch else {
                    self.reply(id, error: "Court assignment or monitoring state changed"); return
                }
                if let error = error { self.reply(id, error: error.localizedDescription) }
                else { self.reply(id, value: ["url": expected, "text": value as? String ?? ""]) }
            }
        case "telestrator":
            guard let frame = args.first as? [String: Any],
                  let visible = frame["visible"] as? Bool else { return }
            telestrator.isHidden = !visible
            guard visible else { return }
            guard let x = frame["x"] as? Double, let y = frame["y"] as? Double,
                  let width = frame["width"] as? Double, let height = frame["height"] as? Double,
                  let viewportWidth = frame["viewportWidth"] as? Double,
                  [x, y, width, height, viewportWidth].allSatisfy({ $0.isFinite }),
                  width > 0, height > 0, viewportWidth > 0 else { telestrator.isHidden = true; return }
            let scale = ui.bounds.width / CGFloat(viewportWidth)
            let rect = CGRect(x: CGFloat(x) * scale, y: CGFloat(y) * scale,
                              width: CGFloat(width) * scale, height: CGFloat(height) * scale)
            telestrator.frame = ui.convert(rect.intersection(ui.bounds), to: view)
            loadTelestrator(reload: frame["reload"] as? Bool == true)
        case "request": if let id=args.first as? String { reply(id,error:"Backend owns commands and live data. Use its authorized controls.") }
        case "checkUpdates": checkCourtLineUpdates(args)
        case "downloadUpdate": openCourtLineUpdate(args)
        default: break
        }
    }

    private lazy var statsHelperSession: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 600
        config.timeoutIntervalForResource = 620
        config.httpCookieStorage = nil
        config.urlCache = nil
        return URLSession(configuration: config, delegate: noRedirects, delegateQueue: nil)
    }()

    // This is the only settings change permitted while in Viewer mode: it
    // verifies a new Helper QR key online before saving the new pairing/role.
    // Invalid or canceled scans leave the previous pairing and role unchanged.






    // Public GitHub Releases API only. Not routed through the vMix/Helper request bridge.
    private func checkCourtLineUpdates(_ args: [Any]) {
        guard let id = args.first as? String, id.hasPrefix(broker.page+":") else { return }
        let automatic = args.count > 1 && args[1] as? Bool == true
        if automatic && automaticUpdateChecked {reply(id,value:["skipped":true]);return}
        if automatic {automaticUpdateChecked=true}
        guard foreground, let url = URL(string: "https://api.github.com/repos/dswartzlander/Courtline/releases?per_page=50") else {
            reply(id, error: "CourtLine must be open to check for updates."); return
        }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        request.setValue("CourtLine-Updater", forHTTPHeaderField: "User-Agent")
        let generation = uiGeneration
        session.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self = self, self.uiGeneration == generation else { return }
                if let error = error { self.reply(id, error: error.localizedDescription); return }
                guard let response = response as? HTTPURLResponse, let data = data, data.count <= 1_000_000 else {
                    self.reply(id, error: "GitHub update response was too large or invalid."); return
                }
                self.reply(id, value: ["status": response.statusCode, "text": String(decoding: data, as: UTF8.self)])
            }
        }.resume()
    }

    private func openCourtLineUpdate(_ args: [Any]) {
        guard args.count == 3, let id = args[0] as? String,
              let address = args[1] as? String, let name = args[2] as? String,
              name.range(of: #"^Courtline-iPad-v[0-9]+\.[0-9]+(?:\.[0-9]+)?(?:-[A-Za-z0-9-]+)?\.zip$"#, options: .regularExpression) != nil,
              let url = URL(string: address), url.scheme == "https", url.host == "github.com",
              url.user == nil, url.password == nil, url.query == nil, url.fragment == nil,
              url.path.hasPrefix("/dswartzlander/Courtline/releases/download/"),
              url.lastPathComponent == name else {
            if let id = args.first as? String { reply(id, error: "Not an official CourtLine iPad ZIP release.") }
            return
        }
        UIApplication.shared.open(url, options: [:]) { [weak self] opened in
            self?.reply(id, value: opened, error: opened ? nil : "Could not open Safari to download this project.")
        }
    }



    // The remote browser has no Courtline bridge. Its address is derived only
    // from the same saved vMix setting used by the API connection.
    private func configuredTelestratorURL() -> URL? {
        guard let address=companionVmixURL?.absoluteString, let base=CourtlineSessionBroker.lanOrigin(address), var parts=URLComponents(url:base,resolvingAgainstBaseURL:false) else {return nil}
        parts.path = "/telestrator/"
        return parts.url
    }

    private func telestratorStatus(_ text: String) {
        ui.evaluateJavaScript("window.telestratorStatus&&window.telestratorStatus(\(json(text)))", completionHandler: nil)
    }

    private func loadTelestrator(reload: Bool = false) {
        guard let url = configuredTelestratorURL() else {
            telestratorURL = nil
            telestrator.stopLoading()
            telestrator.loadHTMLString("", baseURL: nil)
            telestratorStatus("Enter a valid vMix address in Settings.")
            return
        }
        guard reload || telestratorURL != url else { return }
        telestratorURL = url
        telestratorStatus("Loading " + url.absoluteString)
        telestrator.load(URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20))
    }

    private func allowedTelestrator(_ url: URL) -> Bool {
        guard let base = telestratorURL else { return url.absoluteString == "about:blank" }
        return url.scheme?.lowercased() == base.scheme?.lowercased() &&
            url.host?.lowercased() == base.host?.lowercased() &&
            effectivePort(url) == effectivePort(base) && url.user == nil && url.password == nil
    }

    private func effectivePort(_ url: URL) -> Int {
        url.port ?? (url.scheme?.lowercased() == "https" ? 443 : 80)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if webView === ui { decisionHandler(trustedUI(url) ? .allow : .cancel) }
        else if webView === telestrator {
            let allowed = allowedTelestrator(url)
            if !allowed, navigationAction.targetFrame?.isMainFrame != false {
                telestratorStatus("Blocked navigation outside saved vMix address: " + url.absoluteString)
            }
            decisionHandler(allowed ? .allow : .cancel)
        }
        else { decisionHandler(allowedOverlay(url) || url.absoluteString == "about:blank" ? .allow : .cancel) }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if webView === telestrator, navigationResponse.isForMainFrame,
           let response = navigationResponse.response as? HTTPURLResponse,
           response.statusCode >= 400 {
            telestratorStatus("HTTP " + String(response.statusCode) + " · " + (response.url?.absoluteString ?? "") + " · Check the address, then Reload.")
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if webView === telestrator, webView.url?.host != nil { telestratorStatus("Page loaded · " + (webView.url?.absoluteString ?? "")) }
        if let i = courts.firstIndex(where: { $0 === webView }) {
            loaded[i] = foreground && webView.url?.absoluteString == urls[i]
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        if webView === ui { uiGeneration += 1 }
        else if let i = courts.firstIndex(where: { $0 === webView }) { loaded[i] = false }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        if webView === telestrator, (error as NSError).code != NSURLErrorCancelled {
            let failure = error as NSError
            telestratorStatus((telestratorURL?.absoluteString ?? "Telestrator") + " · " + failure.domain + " " + String(failure.code) + ": " + error.localizedDescription + " · Check Courtline Local Network permission, then Reload.")
        }
        if let i = courts.firstIndex(where: { $0 === webView }) { loaded[i] = false }
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        self.webView(webView, didFail: navigation, withError: error)
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        if webView === ui {
            leaving()
            uiGeneration += 1
            let alert = UIAlertController(title: "Restart the test app", message: "iPadOS stopped Courtline's web view. Stop the app in Swift Playground, then press Run again. Monitoring is stopped.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            if presentedViewController == nil { present(alert, animated: true) }
        } else if webView === telestrator {
            telestratorStatus("Telestrator browser stopped. Tap Reload to reconnect.")
        } else if let i = courts.firstIndex(where: { $0 === webView }) { loaded[i] = false }
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard (webView === ui || webView === telestrator), foreground, presentedViewController == nil else { completionHandler(); return }
        let alert = UIAlertController(title: "Courtline", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard (webView === ui || webView === telestrator), foreground, presentedViewController == nil else { completionHandler(false); return }
        let alert = UIAlertController(title: "Courtline", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        guard (webView === ui || webView === telestrator), foreground, presentedViewController == nil else { completionHandler(nil); return }
        let alert = UIAlertController(title: "Courtline", message: prompt, preferredStyle: .alert)
        alert.addTextField { $0.text = defaultText }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(nil) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(alert.textFields?.first?.text) })
        present(alert, animated: true)
    }
    private func safeSettings(_ text:String) -> String {
        var root=(try? JSONSerialization.jsonObject(with:Data(text.utf8))) as? [String:Any] ?? [:]
        var u=root["ui"] as? [String:Any] ?? [:], stats=u["scoreholioStats"] as? [String:Any] ?? [:]
        stats["helperURL"]=broker.helperURL;u["scoreholioStats"]=stats;root["ui"]=u
        return json(redact(root))
    }
    private func redact(_ value:Any) -> Any {
        if let object=value as? [String:Any] {var clean:[String:Any]=[:];for (k,v) in object {if ["pin","unlockToken","sessionKey","viewerKey","settingsGrant","password","token"].contains(k){continue};clean[k]=redact(v)};return clean}
        if let list=value as? [Any]{return list.map{redact($0)}}
        if let text=value as? String {if text.range(of:"(?:ds_|en_)[a-f0-9]{64}|[?&]key=",options:.regularExpression) != nil{return ""};return text}
        return value
    }
    private func redactedExport(_ text:String) -> String {guard let o=try? JSONSerialization.jsonObject(with:Data(text.utf8)) else{return "{}"};return json(redact(o))}
    private func reloadManagedUI() {
        guard !closed,ui != nil,webRoot != nil else{return}
        viewerMode=broker.role != "main";telestrator.isUserInteractionEnabled=false;telestratorLeaseEpoch += 1;uiGeneration += 1
        _=broker.newPage()
        let content=ui.configuration.userContentController;content.removeAllUserScripts()
        let saved=safeSettings(UserDefaults.standard.string(forKey:settingsKey) ?? "{}")
        UserDefaults.standard.set(saved,forKey:settingsKey)
        content.addUserScript(WKUserScript(source:bridgeBootstrap(saved),injectionTime:.atDocumentStart,forMainFrameOnly:true))
        ui.loadFileURL(webRoot.appendingPathComponent("index.html"),allowingReadAccessTo:webRoot)
    }
    private func publishNativeState() { guard !closed,ui != nil else{return};ui.evaluateJavaScript("window.dispatchEvent(new CustomEvent('courtline-native-settings-state',{detail:{nativeUnlocked:"+(broker.unlocked ? "true":"false")+"}}))",completionHandler:nil) }
    private func showAccessLost() {
        guard !closed else{return}
        let show:()->Void = {[weak self] in
            guard let self=self,!self.closed,self.broker.revoked else{return}
            self.nativePINOpen=false
            self.showNativeError("Access lost. Please see your administrator.")
        }
        if let presented=presentedViewController {presented.dismiss(animated:true,completion:show)} else {show()}
    }
    private func showNativeError(_ message:String) {
        guard !closed,presentedViewController == nil else{return}
        let alert=UIAlertController(title:"CourtLine Backend",message:message,preferredStyle:.alert)
        alert.addAction(UIAlertAction(title:"OK",style:.default));present(alert,animated:true)
    }
    private func managedSwitch() {
        guard presentedViewController == nil else{return}
        let captured=broker.stamp
        if broker.role == "main" {
            let a=UIAlertController(title:"Switch to Companion?",message:"Control settings will be unavailable. You can unlock Control again with your Device PIN while the Backend owner allows this device.",preferredStyle:.alert)
            a.addAction(UIAlertAction(title:"Cancel",style:.cancel))
            a.addAction(UIAlertAction(title:"Switch",style:.default){[weak self] _ in guard let self=self,self.broker.valid(captured) else{return};self.broker.downgrade{[weak self] e in if let e=e{self?.showNativeError(e.localizedDescription)}}})
            present(a,animated:true)
        } else if broker.helperURL.isEmpty || broker.revoked { scanEnrollment(nil) }
        else {broker.refreshSession{[weak self] e in guard let self=self,self.broker.valid(captured) else{return};if let e=e{self.showNativeError(e.localizedDescription)}else{self.showDevicePIN()}}}
    }
    private func showDevicePIN() {
        guard !nativePINOpen,presentedViewController == nil else{return}
        if broker.unlocked {ui.evaluateJavaScript("window.dispatchEvent(new CustomEvent('courtline-native-settings-state',{detail:{nativeUnlocked:true}}))",completionHandler:nil);return}
        guard broker.controlAllowed else{showNativeError("Ask the Backend owner to enable Control for this device.");return}
        guard broker.pinAvailable else{showNativeError("Ask the Backend owner to set this device’s PIN in Device Management.");return}
        let captured=broker.stamp;nativePINOpen=true
        let a=DevicePINController();a.modalPresentationStyle = .overFullScreen;a.isModalInPresentation=true
        a.cancelled={[weak self] in guard let self=self else{return};self.nativePINOpen=false;if self.broker.valid(captured){self.ui.evaluateJavaScript("window.dispatchEvent(new Event('courtline-native-settings-cancel'))",completionHandler:nil)}}
        a.submitted={[weak self] pin in guard let self=self else{return};self.nativePINOpen=false;guard self.broker.valid(captured) else{return};self.broker.promote(pin){[weak self] e in if let e=e{self?.showNativeError(e.localizedDescription)}}}
        present(a,animated:true)
    }
    private func scanEnrollment(_ id:String?) {
        guard foreground,presentedViewController == nil else{if let id=id{reply(id,error:"Close the current dialog first.")};return}
        let captured=broker.stamp,scanner=HelperQRScanner()
        scanner.result={[weak self] text,error in
            guard let self=self,self.broker.valid(captured) else{return}
            if let error=error{if let id=id{self.reply(id,error:error)}else{self.showNativeError(error)};return}
            guard let text=text else{if let id=id{self.reply(id,value:NSNull())};return}
            self.broker.enroll(text){[weak self] e in guard let self=self else{return};if let e=e{if let id=id{self.reply(id,error:e.localizedDescription)}else{self.showNativeError(e.localizedDescription)}}
            }
        }
        let n=UINavigationController(rootViewController:scanner);n.isModalInPresentation=true;present(n,animated:true)
    }
    private func handleManaged(_ method:String,_ args:[Any]) -> Bool {
        if method=="switchRole" {managedSwitch();return true}
        if method=="unlockSettings" {showDevicePIN();return true}
        if method=="scanStatsHelper" {scanEnrollment(args.first as? String);return true}
        if method=="statsAssignments" {if let id=args.first as? String{reply(id,error:"Court assignments are owned by Backend.")};return true}
        if method=="restoreLocalPreferences" {
            guard args.count==3,let id=args[0] as? String,id.hasPrefix(broker.page+":"),args[1] as? String == broker.helperURL,broker.role=="main",broker.unlocked,let values=args[2] as? [String:Any] else{return true}
            var root=(try? JSONSerialization.jsonObject(with:Data((UserDefaults.standard.string(forKey:settingsKey) ?? "{}").utf8))) as? [String:Any] ?? [:]
            var u=root["ui"] as? [String:Any] ?? [:],stats=u["scoreholioStats"] as? [String:Any] ?? [:]
            if let inputs=values["vmixInputs"] as? [String],inputs.count==4,inputs.allSatisfy({$0.count<=120}){u["vmixInputs"]=inputs}
            if let auto=values["autoRefresh"] as? Bool{u["autoRefresh"]=auto}
            if let auto=values["statsAuto"] as? Bool{stats["auto"]=auto}
            if let n=values["statsSeconds"] as? Int,(5...3600).contains(n){stats["seconds"]=n}
            u["scoreholioStats"]=stats;root["ui"]=u;let safe=safeSettings(json(root));UserDefaults.standard.set(safe,forKey:settingsKey);reply(id,value:(try? JSONSerialization.jsonObject(with:Data(safe.utf8))) ?? [:]);return true
        }
        guard ["companion","statsHelper","settingsLock","controlSettings"].contains(method) else{return false}
        guard args.count>=3,let id=args[0] as? String,id.hasPrefix(broker.page+":"),let target=args[1] as? String,target==broker.helperURL else{if let id=args.first as? String{reply(id,error:"Backend identity changed.")};return true}
        let captured=broker.stamp
        let action=method=="statsHelper" ? "get" : method=="settingsLock" ? ((args[2] as? [String:Any])?["action"] as? String ?? "") : (args[2] as? String ?? "")
        if method=="statsHelper",args[2] as? Bool == true {reply(id,error:"Use Refresh Stats Now in Control to refresh Backend event stats.");return true}
        let payload:Any? = method=="settingsLock" ? args[2] : args.count>3 ? args[3] : nil
        broker.request(method,action:action,payload:payload,stamp:captured){[weak self] result,error in
            guard let self=self,self.broker.valid(captured) else{return}
            if let error=error{self.reply(id,error:error.localizedDescription);return}
            guard let result=result else{self.reply(id,error:"Empty Backend response.");return}
            if method=="companion",action=="getLive",let snap=result["snapshot"] as? [String:Any],let address=snap["vmixAddress"] as? String {
                let current=CourtlineSessionBroker.lanOrigin(address)
                if self.companionVmixURL != current{self.companionVmixURL=current;self.telestrator.isUserInteractionEnabled=false;if !self.telestrator.isHidden{self.loadTelestrator()}}
            }
            if method=="companion",action=="telestrator" {
                let allowed=result["canDraw"] as? Bool == true;self.telestrator.isUserInteractionEnabled=allowed;self.telestratorLeaseEpoch += 1
                let lease=self.telestratorLeaseEpoch;DispatchQueue.main.asyncAfter(deadline:.now()+3){[weak self] in guard let self=self,self.telestratorLeaseEpoch==lease else{return};self.telestrator.isUserInteractionEnabled=false}
            }
            if method != "controlSettings",let status=result["httpStatus"] as? Int,status != 200{self.reply(id,error:result["error"] as? String ?? "Backend request failed.");return}
            self.publishNativeState();self.reply(id,value:result)
        }
        return true
    }

}
