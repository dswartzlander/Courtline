# Pinned Connection Test 1.1
Separate Swift Playgrounds iPad18+ diagnostic. Does not modify CourtLine1.0.13.
Scan trusted Backend secure QR, then Run Verification. Only public identity fields survive parsing; tickets are never used. One credential-free pinned-TLS GET /api/server-identity,4second timeout matching actual app, no enrollment/control/settings request, no retry/redirect/cookie/cache/persistent storage. Copy result excludes origin, ID, fingerprint, raw errors/body and QR.
Security: same leaf DER SHA256 pin, explicit date check and Security framework server trust evaluation as1.0.13. No bypass or fallback. Background cancels; inactive permission alerts do not cancel.
This separate project may have different Local Network permission behavior. Native SDK validation and physical-device result must be reported separately; source review is not a runtime pass.

1.1 splits the SwiftUI view and result formatting into smaller expressions to address the Playgrounds type-check timeout. TLS, scanner, QR parser and registration behavior are unchanged. Physical Playgrounds launch remains unverified.
