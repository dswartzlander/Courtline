import Foundation
import CoreFoundation

// Only explicitly selected public metadata, never arbitrary dictionaries or QR text.
enum SafeDiagnosticContext {
    static func field(_ value: String?) -> String {
        guard let value = value, !value.isEmpty, value.count <= 128,
              value.unicodeScalars.allSatisfy({ CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ._()+-").contains($0) }) else { return "unavailable" }
        return value
    }

    static func endpoint(_ origin: URL) -> String {
        guard origin.scheme == "https", LANOrigin.parse(origin.absoluteString) == origin,
              let host = origin.host else { return "unavailable" }
        return "https://" + host + ":" + String(origin.port ?? 443)
    }

    static func booleanFlag(_ value: Any?) -> String {
        guard let value = value else { return "absent" }
        guard let number = value as? NSNumber,
              CFGetTypeID(number) == CFBooleanGetTypeID() else { return "invalid-type" }
        return number.boolValue ? "true" : "false"
    }

    static func privacyConfiguration(_ info: [String: Any]) -> String {
        let descriptionState: String
        if let raw = info["NSLocalNetworkUsageDescription"] {
            if let text = raw as? String {
                descriptionState = text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "empty" : "present-nonempty"
            } else {
                descriptionState = "invalid-type"
            }
        } else {
            descriptionState = "absent"
        }
        var lines = ["Runtime Local Network usage description: " + descriptionState]
        guard let rawATS = info["NSAppTransportSecurity"] else {
            lines.append("Runtime ATS dictionary: absent")
            return lines.joined(separator: "\n")
        }
        guard let ats = rawATS as? [String: Any] else {
            lines.append("Runtime ATS dictionary: invalid-type")
            return lines.joined(separator: "\n")
        }
        lines.append("Runtime ATS dictionary: present")
        for key in ["NSAllowsLocalNetworking", "NSAllowsArbitraryLoads", "NSAllowsArbitraryLoadsInWebContent", "NSAllowsArbitraryLoadsForMedia"] {
            lines.append(key + "=" + booleanFlag(ats[key]))
        }
        if let domains = ats["NSExceptionDomains"] {
            lines.append("NSExceptionDomains=" + (domains is [String: Any] ? "present (contents omitted)" : "invalid-type"))
        } else {
            lines.append("NSExceptionDomains=absent")
        }
        // Never output description contents, domain names, arbitrary plist dictionaries or values.
        lines.append("These are runtime plist declarations, not the current permission grant.")
        return lines.joined(separator: "\n")
    }

    static func runtime(bundle: Bundle = .main, osVersion: String) -> String {
        let name = bundle.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String
            ?? bundle.object(forInfoDictionaryKey: "CFBundleName") as? String
        return "Runtime bundle: " + field(bundle.bundleIdentifier)
            + "\nRuntime app: " + field(name)
            + "\nRuntime version/build: " + field(bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String)
            + "/" + field(bundle.object(forInfoDictionaryKey: "CFBundleVersion") as? String)
            + "\niPadOS: " + field(osVersion)
            + "\n" + privacyConfiguration(bundle.infoDictionary ?? [:])
    }
}
