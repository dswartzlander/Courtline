// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes
let package = Package(
 name: "CourtLine Pinned Test",
 platforms: [.iOS("18.0")],
 products: [.iOSApplication(name: "CourtLine Pinned Test", targets: ["PinnedTest"],
 bundleIdentifier: "com.cerberus.courtline.pinneddiagnostic", displayVersion: "1.2", bundleVersion: "3",
 appIcon: .placeholder(icon: .star), accentColor: .presetColor(.blue), supportedDeviceFamilies: [.pad],
 supportedInterfaceOrientations: [.portrait, .portraitUpsideDown, .landscapeLeft, .landscapeRight],
 capabilities: [.camera(purposeString: "Read public connection identity from your Backend QR; never enroll."),.localNetwork(purposeString: "This separate diagnostic checks the PC address you enter. It does not pair with CourtLine or access your settings.")],
 additionalInfoPlistContentFilePath: "AppInfo.plist")],
 targets: [.executableTarget(name: "PinnedTest", path: ".", exclude: ["AppInfo.plist", "README.md"])],
 swiftLanguageVersions: [.v5]
)
