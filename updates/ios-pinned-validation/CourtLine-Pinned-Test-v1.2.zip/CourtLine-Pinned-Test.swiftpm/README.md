# CourtLine Pinned Test 1.2

Standalone, credential-free diagnostic, not a CourtLine release. Scan the current secure Backend QR and tap Run Verification. Only public origin, Backend ID and certificate pin are retained; all ticket fields are discarded.

One HTTPS GET /api/server-identity uses an ephemeral session with no credentials or cookies. URLSession waits for connectivity, with a 15-second request/resource timeout and a 16-second hard deadline. Cellular is disabled; constrained and expensive network access are allowed. A concurrent TCP probe to the same host and port sends no application data, prohibits cellular and stops after 3 seconds. Its path observation is not a diagnosis or certificate check.

Logs include allowlisted error domains, numeric error/reason codes and fixed path labels. No full NSError descriptions/userInfo, QR payloads, tokens or PINs are logged. Output is limited to 60 lines (512 characters per line), with an additional 12KB guard and consecutive duplicate suppression.

Certificate SHA256 pin, validity, TLS server trust and Backend identity checks remain enforced. No redirects, HTTP fallback, enrollment, registration, settings changes or credential transmission. Going to background cancels the operation; no automatic retry.

Apple SDK typecheck/link and fake-network tests do not establish Swift Playgrounds preview compatibility or physical network behavior. Retry only when directed, and copy the result after completion.
