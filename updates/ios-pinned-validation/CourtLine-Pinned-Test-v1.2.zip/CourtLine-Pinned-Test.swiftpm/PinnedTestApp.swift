import SwiftUI
import UIKit

@MainActor
final class PinnedTestModel: ObservableObject {
    @Published var result = "Scan the current secure Backend QR. No enrollment will be attempted."
    @Published var scanned = false
    @Published var busy = false
    private var qr: SecureBackendQR?
    private var request: PinnedBackendRequest?
    private var generation = 0
    private var active = true

    private func appendFinal(_ line: String) {
        // One bounded terminal line remains visible even if diagnostic logging filled its cap.
        result.append("\n")
        result.append(String(line.prefix(512)))
    }

    func beginScan() {
        guard !busy else { return }
        qr = nil
        scanned = false
        result = "Waiting for a new secure Backend QR."
    }

    func accept(_ text: String?, _ error: String?) {
        guard active, !busy else { return }
        guard error == nil, let text = text, let parsed = SecureBackendQR(text) else {
            qr = nil
            scanned = false
            result = "Scan cancelled or not a supported secure QR. Previous scan cleared."
            return
        }
        qr = parsed
        scanned = true
        result = "Public Backend identity loaded. All ticket fields discarded. Tap Run Verification."
    }

    private var loggedLines = 0
    private var lastLine: String?
    private func appendLine(_ line: String) {
        guard line != lastLine, loggedLines < 60, result.utf8.count < 12000 else { return }
        lastLine = line
        loggedLines += 1
        result.append("\n")
        result.append(String(line.prefix(512)))
        if loggedLines == 60 { result.append("\nDiagnostic log capped at 60 lines.") }
    }

    func run() {
        guard active, !busy, let qr = qr else { return }
        generation += 1
        let captured: Int = generation
        busy = true
        loggedLines = 0
        lastLine = nil
        result = "GET /api/server-identity only. No key, cookie, PIN or enrollment."
        appendLine("Ephemeral session; 15-second request/resource timeout; 16-second hard deadline. Waiting enabled; cellular disabled.")
        let operation = PinnedBackendRequest(trust: qr.trust, origin: qr.origin)
        request = operation
        operation.observation = { [weak self] line in
            guard let self = self, self.generation == captured, self.busy else { return }
            self.appendLine(line)
        }
        operation.start(timeout: 15) { [weak self] status, json, error in
            guard let self = self, self.generation == captured else { return }
            self.complete(status: status, json: json, error: error, expectedID: qr.trust.backendId)
        }
    }

    private func complete(status: Int, json: [String: Any], error: Error?, expectedID: String) {
        busy = false
        request = nil
        if error != nil {
            appendFinal("Verification failed; no enrollment attempted.")
            return
        }
        let version: Int? = json["version"] as? Int
        let receivedID: String? = json["backendId"] as? String
        let schema: Bool = version == 1 && receivedID != nil
        let matches: Bool = receivedID?.lowercased() == expectedID
        if schema {
            appendLine("Identity schema: PASS")
        } else {
            appendLine("Identity schema: FAIL")
        }
        if matches {
            appendLine("Backend identity: MATCH")
        } else {
            appendLine("Backend identity: MISMATCH")
        }
        if status == 200 && schema && matches {
            appendFinal("Pinned verification PASSED. No enrollment attempted.")
        } else {
            appendFinal("Pinned verification FAILED. No enrollment attempted.")
        }
    }

    func setActive(_ value: Bool) {
        active = value
        if !value {
            generation += 1
            request?.cancel()
            request = nil
            busy = false
            appendLine("Cancelled because app entered background. No automatic retry.")
        }
    }
}

struct Scanner: UIViewControllerRepresentable {
    let completion: (String?, String?) -> Void
    func makeUIViewController(context: Context) -> UINavigationController {
        let scanner = HelperQRScanner()
        scanner.result = completion
        return UINavigationController(rootViewController: scanner)
    }
    func updateUIViewController(_ controller: UINavigationController, context: Context) {}
}

@main
struct PinnedTestApp: App {
    var body: some Scene {
        WindowGroup {
            PinnedTestView()
        }
    }
}

struct PinnedTestView: View {
    @Environment(\.scenePhase) private var phase
    @StateObject private var model = PinnedTestModel()
    @State private var scan = false

    var body: some View {
        NavigationStack {
            diagnosticForm
                .navigationTitle("Pinned Connection Test 1.2")
        }
        .sheet(isPresented: $scan) {
            Scanner(completion: acceptScan)
        }
        .onChange(of: phase) { _, newValue in
            updatePhase(newValue)
        }
    }

    private var diagnosticForm: some View {
        Form {
            informationSection
            controlsSection
            resultsSection
        }
    }

    private var informationSection: some View {
        Section("Separate read-only diagnostic") {
            Text("Scan the secure QR directly from your trusted Backend PC. Only its public address, Backend ID and certificate fingerprint are retained in memory. Pairing/recovery keys are discarded and never sent. This does not consume the QR or change any app/device registration.")
            Text("This project has a separate iPad permission identity. It cannot prove the CourtLine app has the same permissions.")
        }
    }

    private var controlsSection: some View {
        Section("Verification") {
            Button("Scan Backend QR", action: beginScan)
                .disabled(model.busy)
            Button("Run Verification", action: model.run)
                .disabled(!model.scanned || model.busy)
        }
    }

    private var resultsSection: some View {
        Section("Safe diagnostics") {
            Text(model.result)
                .font(.system(.footnote, design: .monospaced))
                .textSelection(.enabled)
            Button("Copy Result", action: copyResult)
                .disabled(model.busy)
        }
    }

    private func beginScan() {
        model.beginScan()
        scan = true
    }

    private func acceptScan(_ text: String?, _ error: String?) {
        scan = false
        model.accept(text, error)
    }

    private func copyResult() {
        UIPasteboard.general.string = model.result
    }

    private func updatePhase(_ phase: ScenePhase) {
        if phase == .background {
            model.setActive(false)
        } else if phase == .active {
            model.setActive(true)
        }
    }
}
