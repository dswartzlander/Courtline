import Foundation

enum LANOrigin {
    static func parse(_ text: String) -> URL? {
        guard let u = URLComponents(string: text), ["http","https"].contains(u.scheme?.lowercased() ?? ""), let h = u.host?.lowercased(), u.user == nil, u.password == nil, u.fragment == nil else { return nil }
        let labels = h.split(separator: ".", omittingEmptySubsequences: false)
        let v = labels.compactMap { Int($0) }
        let privateV4 = labels.count == 4 && labels.allSatisfy { !$0.isEmpty && $0.allSatisfy { $0.isASCII && $0.isNumber } } && v.count == 4 && v.allSatisfy { (0...255).contains($0) } && (v[0] == 10 || (v[0] == 192 && v[1] == 168) || (v[0] == 172 && (16...31).contains(v[1])))
        let localName = h.range(of:"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*\\.local$",options:.regularExpression) != nil
        guard privateV4 || localName else { return nil }
        guard u.port == nil || (1...65535).contains(u.port!) else { return nil }
        var clean = URLComponents(); clean.scheme = u.scheme?.lowercased(); clean.host = h; clean.port = u.port
        return clean.url
    }
}
