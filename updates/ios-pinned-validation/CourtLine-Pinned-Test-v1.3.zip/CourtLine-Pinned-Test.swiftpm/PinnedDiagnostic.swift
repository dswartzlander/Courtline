import Foundation
import Security
import CryptoKit
import Network

struct BackendTrust: Codable, Equatable {
    let backendId: String
    let certificateSha256: String
    static func valid(_ id: String, _ pin: String) -> Bool {
        UUID(uuidString:id) != nil && pin.range(of:"^[a-f0-9]{64}$",options:.regularExpression) != nil
    }
}
struct SecureBackendQR {
    let trust:BackendTrust
    let origin:URL
    init?(_ text:String) {
        guard text.utf8.count<=4096,let data=text.data(using:.utf8),let j=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any],
              j["type"] as? String=="courtline-secure",j["version"] as? Int==1,
              let id=j["backendId"] as? String,let pin=j["certificateSha256"] as? String,BackendTrust.valid(id,pin),
              let value=j["origin"] as? String,let c=URLComponents(string:value),c.scheme=="https",c.query==nil,c.fragment==nil,["","/"].contains(c.path),let url=LANOrigin.parse(value) else{return nil}
        trust=BackendTrust(backendId:id.lowercased(),certificateSha256:pin);origin=url
        // No ticket, token, name or other QR field retained.
    }
}
// Explicit leaf validity check also covers self-signed anchors, whose dates
// platform trust implementations may treat differently from intermediates.
enum BackendCertificateDates {
    static func valid(_ data:Data,now:Date=Date())->Bool {
        let b=[UInt8](data)
        func node(_ offset:Int,_ limit:Int)->(UInt8,Range<Int>,Int)? {
            guard offset>=0,offset+2<=limit,limit<=b.count else{return nil}
            let tag=b[offset],first=Int(b[offset+1]);var length=first,start=offset+2
            if first>=128 {let count=first&127;guard count>0,count<=4,start+count<=limit,b[start] != 0 else{return nil};length=0
                for j in 0..<count {length=length*256+Int(b[start+j])};start += count;guard length>=128 else{return nil}}
            guard length>=0,length<=limit-start else{return nil};return(tag,start..<(start+length),start+length)
        }
        guard let cert=node(0,b.count),cert.0==0x30,cert.2==b.count,let tbs=node(cert.1.lowerBound,cert.1.upperBound),tbs.0==0x30 else{return false}
        var pos=tbs.1.lowerBound
        if let version=node(pos,tbs.1.upperBound),version.0==0xa0 {pos=version.2}
        for _ in 0..<3 {guard let field=node(pos,tbs.1.upperBound) else{return false};pos=field.2}
        guard let validity=node(pos,tbs.1.upperBound),validity.0==0x30,let first=node(validity.1.lowerBound,validity.1.upperBound),let last=node(first.2,validity.1.upperBound),last.2==validity.1.upperBound else{return false}
        func date(_ n:(UInt8,Range<Int>,Int))->Date? {
            guard let value=String(bytes:b[n.1],encoding:.ascii) else{return nil}
            let pattern=n.0==0x17 ? "^[0-9]{12}Z$":n.0==0x18 ? "^[0-9]{14}Z$":"!"
            guard value.range(of:pattern,options:.regularExpression) != nil else{return nil}
            var normalized=value
            if n.0==0x17 {let year=Int(value.prefix(2))!;normalized=(year>=50 ? "19":"20")+value}
            let f=DateFormatter();f.locale=Locale(identifier:"en_US_POSIX");f.calendar=Calendar(identifier:.gregorian);f.timeZone=TimeZone(secondsFromGMT:0);f.dateFormat="yyyyMMddHHmmss'Z'";f.isLenient=false
            guard let d=f.date(from:normalized),f.string(from:d)==normalized else{return nil};return d
        }
        guard let start=date(first),let end=date(last) else{return false};return start<=now && now<=end && start<end
    }
}
// One immutable trust/origin per operation. No redirects, cookies, credential
// storage, HTTP fallback or platform default trust after a pin mismatch.
final class PinnedBackendRequest: NSObject, URLSessionTaskDelegate {
    let trust: BackendTrust
    let origin: URL
    var observation:((String)->Void)?
    private func note(_ message:String){if Thread.isMainThread{observation?(message)}else{let report=observation;DispatchQueue.main.async{report?(message)}}}
    #if COURTLINE_TESTING
    static var testProtocols:[AnyClass]?
    #endif
    private var pathProbe: NWConnection?
    private var session: URLSession?
    private func startPathProbe() {
        #if !COURTLINE_TESTING
        guard let host = origin.host, let port = NWEndpoint.Port(rawValue: UInt16(origin.port ?? 443)) else { return }
        // No application bytes are sent. This bounded observation is not a diagnosis.
        let parameters = NWParameters.tcp
        parameters.prohibitedInterfaceTypes = [.cellular]
        let probe = NWConnection(host: NWEndpoint.Host(host), port: port, using: parameters)
        pathProbe = probe
        probe.stateUpdateHandler = { [weak self, weak probe] state in
            guard let self = self else { return }
            switch state {
            case .ready:
                self.note("Endpoint TCP observation: ready (not a TLS or identity test)")
                probe?.cancel()
            case .waiting:
                guard let path = probe?.currentPath else { self.note("Endpoint TCP observation: waiting"); return }
                let reason: String
                switch path.unsatisfiedReason {
                case .localNetworkDenied: reason = "localNetworkDenied"
                case .cellularDenied: reason = "cellularDenied"
                case .wifiDenied: reason = "wifiDenied"
                case .notAvailable: reason = "notAvailable"
                @unknown default: reason = "unknown"
                }
                self.note("Endpoint TCP path observation: " + reason + " (not a diagnosis)")
            case .failed:
                self.note("Endpoint TCP observation: failed")
            default: break
            }
        }
        probe.start(queue: DispatchQueue(label: "CourtLine.PinnedDiagnostic.Path"))
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak probe] in probe?.cancel() }
        #endif
    }
    private func reportNetworkError(_ error: NSError) {
        let domains = [NSURLErrorDomain, "kCFErrorDomainCFNetwork", NSOSStatusErrorDomain, NSPOSIXErrorDomain]
        let domain = domains.contains(error.domain) ? error.domain : "other"
        note("URLSession error: " + domain + " " + String(error.code))
        if let reason = error.userInfo[NSURLErrorNetworkUnavailableReasonKey] as? NSNumber {
            note("Network unavailable reason code: " + reason.stringValue)
        }
        if let underlying = error.userInfo[NSUnderlyingErrorKey] as? NSError {
            let safe = domains.contains(underlying.domain) ? underlying.domain : "other"
            note("Underlying error: " + safe + " " + String(underlying.code))
        }
        // Never print descriptions, arbitrary userInfo, URLs, QR content or credentials.
    }
    func urlSession(_ session: URLSession, taskIsWaitingForConnectivity task: URLSessionTask) {
        note("URLSession waiting for connectivity (bounded by diagnostic deadline)")
    }
    private var task: URLSessionDataTask?
    private var completion: ((Int,[String:Any],Error?)->Void)?
    init(trust:BackendTrust,origin:URL) {self.trust=trust;self.origin=origin}
    static func error(_ message:String)->NSError {NSError(domain:"CourtLineSecure",code:1,userInfo:[NSLocalizedDescriptionKey:message])}
    func start(timeout:TimeInterval,done:@escaping(Int,[String:Any],Error?)->Void) {
        guard origin.scheme=="https",LANOrigin.parse(origin.absoluteString)==origin else{done(0,[:],Self.error("Invalid secure Backend address."));return}
        completion=done
        let c=URLSessionConfiguration.ephemeral
        #if COURTLINE_TESTING
        c.protocolClasses=Self.testProtocols
        #endif
        c.httpCookieStorage=nil;c.httpShouldSetCookies=false;c.urlCredentialStorage=nil;c.urlCache=nil
        c.allowsCellularAccess=false;c.waitsForConnectivity=true
        c.allowsConstrainedNetworkAccess=true;c.allowsExpensiveNetworkAccess=true
        c.requestCachePolicy = .reloadIgnoringLocalCacheData;c.timeoutIntervalForRequest=timeout;c.timeoutIntervalForResource=timeout
        let session=URLSession(configuration:c,delegate:self,delegateQueue:nil);self.session=session
        var r=URLRequest(url:origin.appendingPathComponent("api/server-identity"),cachePolicy:.reloadIgnoringLocalCacheData,timeoutInterval:timeout)
        r.setValue("application/json",forHTTPHeaderField:"Accept")
        task=session.dataTask(with:r){[weak self] data,response,error in DispatchQueue.main.async {
            guard let self=self else{return}
            guard error==nil else{self.reportNetworkError(error! as NSError);self.finish(0,[:],Self.error("Request failed; no enrollment attempted."));return}
            guard let response=response as? HTTPURLResponse else{self.note("HTTP response: MISSING");self.finish(0,[:],Self.error("Invalid Backend response."));return}
            self.note("HTTP status: "+String(response.statusCode))
            guard let data=data,data.count<=65536,let json=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] else{self.note("Identity JSON: INVALID or oversized");self.finish(response.statusCode,[:],Self.error("Invalid Backend response."));return}
            self.finish(response.statusCode,json,nil)
        }}
        startPathProbe()
        task?.resume()
        DispatchQueue.main.asyncAfter(deadline:.now()+timeout+1){[weak self] in guard let self=self,self.completion != nil else{return};self.note("Request deadline reached");self.finish(0,[:],Self.error("Secure Backend request timed out."))}
    }
    private func finish(_ status:Int,_ result:[String:Any],_ error:Error?) {
        guard let done=completion else{return};completion=nil;pathProbe?.cancel();pathProbe=nil;task?.cancel();task=nil;session?.invalidateAndCancel();session=nil;done(status,result,error)
    }
    func cancel(){finish(0,[:],Self.error("Connection cancelled."))}
    func urlSession(_ session:URLSession,task:URLSessionTask,willPerformHTTPRedirection response:HTTPURLResponse,newRequest request:URLRequest,completionHandler:@escaping(URLRequest?)->Void){note("Redirect refused");completionHandler(nil)}
    func urlSession(_ session:URLSession,task:URLSessionTask,didReceive challenge:URLAuthenticationChallenge,completionHandler:@escaping(URLSession.AuthChallengeDisposition,URLCredential?)->Void) {
        note("TLS authentication challenge received")
        guard challenge.protectionSpace.authenticationMethod==NSURLAuthenticationMethodServerTrust,
              challenge.protectionSpace.host.lowercased()==origin.host?.lowercased(),
              let serverTrust=challenge.protectionSpace.serverTrust,let cert=SecTrustGetCertificateAtIndex(serverTrust,0) else{note("TLS challenge type/host/certificate: REJECTED");completionHandler(.cancelAuthenticationChallenge,nil);return}
        guard Self.validate(serverTrust:serverTrust,cert:cert,pin:trust.certificateSha256,observe:note) else{completionHandler(.cancelAuthenticationChallenge,nil);return}
        completionHandler(.useCredential,URLCredential(trust:serverTrust))
    }
    static func validate(serverTrust:SecTrust,cert:SecCertificate,pin:String,observe:(String)->Void = {_ in})->Bool {
        let der=SecCertificateCopyData(cert) as Data
        guard BackendCertificateDates.valid(der) else{observe("Certificate date/DER check: FAIL");return false};observe("Certificate date/DER check: PASS")
        let hash=SHA256.hash(data:der).map{String(format:"%02x",$0)}.joined()
        guard hash==pin else{observe("Certificate SHA256 pin: MISMATCH");return false};observe("Certificate SHA256 pin: MATCH")
        // Exact QR-pinned certificate provides server identity across IP changes.
        // X509 evaluation still checks dates and TLS server usage, not a volatile IP.
        SecTrustSetPolicies(serverTrust,SecPolicyCreateSSL(true,nil))
        SecTrustSetAnchorCertificates(serverTrust,[cert] as CFArray)
        SecTrustSetAnchorCertificatesOnly(serverTrust,true)
        SecTrustSetNetworkFetchAllowed(serverTrust,false)
        var trustError:CFError?
        guard SecTrustEvaluateWithError(serverTrust,&trustError) else{observe("TLS server trust: FAIL code "+String(trustError.map{CFErrorGetCode($0)} ?? 0));return false};observe("TLS server trust: PASS")
        return true
    }

}

// Advertisements identify candidates only, never trust. No address sweeps and no
// credential is transmitted by discovery. Caller verifies TLS + Backend ID.
