import Foundation

// Only explicitly selected public metadata, never arbitrary dictionaries or QR text.
enum SafeDiagnosticContext {
    static func field(_ value: String?) -> String {
        guard let value = value, !value.isEmpty, value.count <= 128,
              value.unicodeScalars.allSatisfy({ CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 ._()+-").contains($0) }) else { return "unavailable" }
        return value
    }

    static func endpoint(_ origin: URL) -> String {
        guard origin.scheme == "https", LANOrigin.parse(origin.absoluteString) == origin,
              let host = origin.host else { return "unavailable" }
        return "https://" + host + ":" + String(origin.port ?? 443)
    }

    static func runtime(bundle: Bundle = .main, osVersion: String) -> String {
        let name = bundle.object(forInfoDictionaryKey: "CFBundleDisplayName") as? String
            ?? bundle.object(forInfoDictionaryKey: "CFBundleName") as? String
        return "Runtime bundle: " + field(bundle.bundleIdentifier)
            + "\nRuntime app: " + field(name)
            + "\nRuntime version/build: " + field(bundle.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String)
            + "/" + field(bundle.object(forInfoDictionaryKey: "CFBundleVersion") as? String)
            + "\niPadOS: " + field(osVersion)
    }
}
