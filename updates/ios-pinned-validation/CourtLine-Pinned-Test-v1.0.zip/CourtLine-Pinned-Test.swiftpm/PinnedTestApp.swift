import SwiftUI
import UIKit

@MainActor final class PinnedTestModel:ObservableObject {
    @Published var result="Scan the current secure Backend QR. No enrollment will be attempted."
    @Published var scanned=false
    @Published var busy=false
    private var qr:SecureBackendQR?
    private var request:PinnedBackendRequest?
    private var generation=0
    private var active=true
    func beginScan(){guard !busy else{return};qr=nil;scanned=false;result="Waiting for a new secure Backend QR."}
    func accept(_ text:String?,_ error:String?) {
        guard active,!busy else{return}
        guard error==nil,let text=text,let parsed=SecureBackendQR(text) else{qr=nil;scanned=false;result="Scan cancelled or not a supported secure QR. Previous scan cleared.";return}
        qr=parsed;scanned=true;result="Public Backend identity loaded. All ticket fields discarded. Tap Run Verification."
    }
    func run(){
        guard active,!busy,let qr=qr else{return}
        generation += 1;let captured=generation;busy=true
        result="GET /api/server-identity only. No key, cookie, PIN or enrollment.\nEphemeral session; 4-second request timeout, matching CourtLine 1.0.13."
        let operation=PinnedBackendRequest(trust:qr.trust,origin:qr.origin);request=operation
        operation.observation={[weak self] line in guard let self=self,self.generation==captured else{return};self.result += "\n"+line}
        operation.start(timeout:4){[weak self] status,json,error in
            guard let self=self,self.generation==captured else{return};self.busy=false;self.request=nil
            if error != nil {self.result += "\nVerification failed; no enrollment attempted.";return}
            let schema=json["version"] as? Int==1 && json["backendId"] is String
            let matches=(json["backendId"] as? String)?.lowercased()==qr.trust.backendId
            self.result += "\nIdentity schema: "+(schema ? "PASS":"FAIL")+"\nBackend identity: "+(matches ? "MATCH":"MISMATCH")
            self.result += status==200 && schema && matches ? "\nPinned verification PASSED. No enrollment attempted.":"\nPinned verification FAILED. No enrollment attempted."
        }
    }
    func setActive(_ value:Bool){active=value;if !value{generation += 1;request?.cancel();request=nil;busy=false;result += "\nCancelled because app entered background. No automatic retry."}}
}
struct Scanner:UIViewControllerRepresentable {
    let completion:(String?,String?)->Void
    func makeUIViewController(context:Context)->UINavigationController{let scanner=HelperQRScanner();scanner.result=completion;return UINavigationController(rootViewController:scanner)}
    func updateUIViewController(_ uiViewController:UINavigationController,context:Context){}
}
@main struct PinnedTestApp:App {var body:some Scene{WindowGroup{PinnedTestView()}}}
struct PinnedTestView:View {
    @Environment(\.scenePhase) private var phase
    @StateObject private var model=PinnedTestModel()
    @State private var scan=false
    var body:some View {
        NavigationStack{Form{
            Section("Separate read-only diagnostic"){
                Text("Scan the secure QR directly from your trusted Backend PC. Only its public address, Backend ID and certificate fingerprint are retained in memory. Pairing/recovery keys are discarded and never sent. This does not consume the QR or change any app/device registration.")
                Text("This project has a separate iPad permission identity. It cannot prove the CourtLine app has the same permissions.")
                Button("Scan Backend QR"){model.beginScan();scan=true}.disabled(model.busy)
                Button("Run Verification"){model.run()}.disabled(!model.scanned || model.busy)
            }
            Section("Safe diagnostics"){
                Text(model.result).font(.system(.footnote,design:.monospaced)).textSelection(.enabled)
                Button("Copy Result"){UIPasteboard.general.string=model.result}.disabled(model.busy)
            }
        }.navigationTitle("Pinned Connection Test")}
        .sheet(isPresented:$scan){Scanner{text,error in scan=false;model.accept(text,error)}}
        .onChange(of:phase){newValue in if newValue == .background{model.setActive(false)}else if newValue == .active{model.setActive(true)}}
    }
}
