// Verify non-blocking startup checks and local update notification for both views.
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const type=fs.existsSync(path.join(root,'assets','index.html'))?'android':'ios';
const file=path.join(root,type==='android'?'assets':'Web','courtline-updates.js');
const html=fs.readFileSync(path.join(root,type==='android'?'assets/index.html':'Web/index.html'),'utf8');
const css=fs.readFileSync(path.join(root,type==='android'?'assets/courtline-themes.css':'Web/courtline-themes.css'),'utf8');
assert.match(html,/id="courtlineUpdateBadge".*?hidden/);
assert.match(css,/\.courtline-update-trigger \.courtline-update-alert\[hidden\]\{display:none!important;/);
assert.ok(html.indexOf('courtline-updates-bridge.js')<html.indexOf('courtline-updates.js'));
const filename=type==='android'?'Courtline-Tablet-v1.0.4-Fix.apk':'Courtline-iPad-v1.0.4-Fix.zip';
const url='https://github.com/dswartzlander/Courtline/releases/download/v1.0.3/'+filename;
const update=JSON.stringify([{draft:false,prerelease:false,assets:[{name:filename,browser_download_url:url,size:5000}]}]);
const current=JSON.stringify([{draft:false,prerelease:false,assets:[{name:filename.replace('1.0.4','1.0.3'),browser_download_url:url.replaceAll('1.0.4','1.0.3'),size:5000}]}]);
function setup({storage=new Map(),response=update,controlled=false,fail=false}={}) {
  const events={};const elems={};let calls=0,resolveCheck;
  for(const id of ['checkForUpdates','courtlineUpdateBadge','courtlineUpdateDialog','courtlineUpdateStatus','courtlineUpdateDetails','courtlineUpdateDownload','courtlineUpdateClose']){
    elems[id]={hidden:id==='courtlineUpdateBadge'||id==='courtlineUpdateDialog'||id==='courtlineUpdateDownload',disabled:false,events:{},title:'',textContent:'',attrs:{},setAttribute(k,v){this.attrs[k]=v;},addEventListener(k,cb){this.events[k]=cb;}};
  }
  const win={CourtlineNative:{},sessionStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)},addEventListener:(k,fn)=>events[k]=fn,
    CourtlineUpdatesTransport:{check:async()=>{calls++;if(fail)throw Error('offline');if(controlled)return new Promise(r=>{resolveCheck=r;});return {status:200,text:response};},download:async()=>{}}};
  const context={document:{readyState:'loading',documentElement:{dataset:{courtlinePlatform:type,courtlineVersion:'1.0.3'}},getElementById:id=>elems[id]},window:win,module:{exports:{}},URL,Promise};
  vm.runInNewContext(fs.readFileSync(file,'utf8'),context);
  return {elems,events,storage,get calls(){return calls;},finish:v=>resolveCheck({status:200,text:v}),start:()=>events.load(),click:()=>elems.checkForUpdates.events.click(),context};
}
async function tick(){for(let i=0;i<5;i++)await Promise.resolve();}
(async()=>{
  const a=setup();a.start();await tick();
  assert.equal(a.calls,1,'one call at launch');
  assert.equal(a.elems.courtlineUpdateDialog.hidden,true,'startup never opens dialog');
  assert.equal(a.elems.courtlineUpdateBadge.hidden,false,'newer version makes badge visible');
  assert.match(a.elems.checkForUpdates.attrs['aria-label'],/v1\.0\.4 available/);
  a.start();await tick();assert.equal(a.calls,1,'one load event listener');
  const reloaded=setup({storage:a.storage});reloaded.start();await tick();assert.equal(reloaded.calls,0,'same app session reload does not refetch');
  assert.equal(reloaded.elems.courtlineUpdateBadge.hidden,false,'known available update badge survives WebView reload');
  a.click();await tick();assert.equal(a.elems.courtlineUpdateDialog.hidden,false,'manual check opens dialog');
  assert.equal(a.elems.courtlineUpdateDownload.hidden,false,'manual check presents install option');
  assert.equal(a.calls,2,'manual check is fresh');
  const b=setup({response:current});b.start();await tick();
  assert.equal(b.elems.courtlineUpdateBadge.hidden,true,'no badge when already up-to-date');
  assert.equal(b.elems.courtlineUpdateDialog.hidden,true,'no startup popup');
  const c=setup({controlled:true});c.start();assert.equal(c.calls,1);
  c.click();assert.equal(c.calls,1,'manual click during startup check reuses the pending request');
  assert.equal(c.elems.courtlineUpdateDialog.hidden,false,'manual can reveal pending progress');
  c.finish(update);await tick();assert.equal(c.elems.courtlineUpdateBadge.hidden,false);
  assert.equal(c.elems.courtlineUpdateDownload.hidden,false);
  const d=setup({fail:true});d.start();await tick();assert.equal(d.elems.courtlineUpdateDialog.hidden,true,'offline startup stays quiet');
  assert.equal(d.elems.courtlineUpdateBadge.hidden,true);
  const e=setup({response:update});e.start();await tick();assert.equal(e.calls,1,'new launch has new session and checks');
  console.log('PASS '+type+' quiet one-time update notifications and manual control');
})().catch(e=>{console.error(e);process.exitCode=1;});
