'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const css = fs.readFileSync('Web/courtline-themes.css','utf8');
const html = fs.readFileSync('Web/index.html','utf8');
const manifest = fs.readFileSync('Package.swift','utf8');
for (const t of ['blue','orange','purple','white']) {
  const block=css.split(`:root[data-courtline-theme="${t}"]{`).at(-1).split('}')[0];
  assert(block.includes('--mgr-card-start:') && block.includes('--mgr-bottom:') && block.includes('--mgr-field:'), t+' management palette');
}
for(const selector of ['.court-card','.court-card-bottom','.court-card-top','.stats-helper-inline','.status-strip','.automation-settings h3','.court-visibility-toggle','.vmix-host-field input','.automation-controls button:not(:disabled)']){
  assert(css.includes(selector), selector+' themed in Settings');
}
assert(css.includes('body:not(.display-mode)'), 'restrict Settings palette to management view');
assert(css.includes('not([data-courtline-theme="teal"])'), 'leave original Teal unaffected');
assert(html.includes('iPAD v1.0.3') && manifest.includes('displayVersion: "1.0.3"'), 'version parity');
assert(manifest.includes('bundleVersion: "103"'),'bundle version incremented');
console.log('PASS five-theme settings parity, accessibility, live-view isolation, and version');
