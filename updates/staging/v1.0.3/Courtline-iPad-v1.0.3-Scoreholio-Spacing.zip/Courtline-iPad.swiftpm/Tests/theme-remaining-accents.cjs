'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const css=fs.readFileSync('Web/courtline-themes.css','utf8');
const html=fs.readFileSync('Web/index.html','utf8');
const pkg=fs.readFileSync('Package.swift','utf8');
const notTeal=':root[data-courtline-theme]:not([data-courtline-theme="teal"])';
for(const s of ['.stats-score-divider','#liveIndicator:not(.is-off)','.settings-state-icon[data-lock-state="unlocked"]','.telestrator-settings-trigger:not(.has-control-request)','.state-pill.is-assigned','.automation-controls button:not(:disabled)','.activity-log-trigger','[data-widget-preview]']){
 assert(css.includes(s),`missing theme fix for ${s}`);
}
assert(css.includes(notTeal),'original Teal must be unchanged');
assert(css.includes('not(.has-control-request)'), 'pending control request remains conspicuous');
assert(css.includes('button:disabled'), 'disabled monitor actions stay distinct');
assert(html.includes('iPAD v1.0.3')&&pkg.includes('displayVersion: "1.0.3"')&&pkg.includes('bundleVersion: "103"'));
console.log('PASS header, score, court controls, telestrator entry, accessibility/semantics, version');
