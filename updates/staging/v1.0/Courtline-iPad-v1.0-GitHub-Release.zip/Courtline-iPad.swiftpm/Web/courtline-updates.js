// CourtLine public GitHub Releases updater. Only published, non-prerelease assets are offered.
(() => {
  'use strict';
  const PLATFORM = document.documentElement.dataset.courtlinePlatform;
  const CURRENT = document.documentElement.dataset.courtlineVersion;
  const ASSETS = PLATFORM === 'android'
    ? /^Courtline-Tablet-v(\d+\.\d+(?:\.\d+)?)(?:-[A-Za-z0-9-]+)?\.apk$/i
    : /^Courtline-iPad-v(\d+\.\d+(?:\.\d+)?)(?:-[A-Za-z0-9-]+)?\.zip$/i;
  const API = 'https://api.github.com/repos/dswartzlander/Courtline/releases?per_page=50';
  const PREFIX = 'https://github.com/dswartzlander/Courtline/releases/download/';
  const button = document.getElementById('checkForUpdates');
  const panel = document.getElementById('courtlineUpdateDialog');
  const status = document.getElementById('courtlineUpdateStatus');
  const description = document.getElementById('courtlineUpdateDetails');
  const install = document.getElementById('courtlineUpdateDownload');
  const close = document.getElementById('courtlineUpdateClose');
  if (!button || !panel || !status || !install || !window.CourtlineNative) return;
  let available = null, busy = false;
  function value(v) {
    if (typeof v !== 'string' || !/^\d+\.\d+(?:\.\d+)?$/.test(v)) return null;
    const parts=v.split('.').map(Number);
    if (parts.some(n => !Number.isSafeInteger(n) || n < 0)) return null;
    return [parts[0],parts[1],parts[2] ?? 0];
  }
  function compare(a,b) {
    const x=value(a),y=value(b);
    if (!x || !y) return null;
    for (let i=0;i<3;i++) if(x[i]!==y[i]) return x[i]>y[i]?1:-1;
    return 0;
  }
  function validUrl(url, name) {
    try {
      const u=new URL(url);
      return u.protocol==='https:' && !u.username && !u.password && !u.search && !u.hash &&
        u.href.startsWith(PREFIX) && u.pathname.endsWith('/'+encodeURIComponent(name));
    } catch (_) { return false; }
  }
  function newest(releases) {
    let best=null;
    for (const release of releases) {
      if (!release || release.draft || release.prerelease || !Array.isArray(release.assets)) continue;
      for (const asset of release.assets) {
        if (!asset || typeof asset.name!=='string' || typeof asset.browser_download_url!=='string') continue;
        const match=ASSETS.exec(asset.name);
        if (!match || !validUrl(asset.browser_download_url, asset.name) || !(asset.size>0)) continue;
        if (!best || compare(match[1],best.version)>0) best={version:match[1],name:asset.name,url:asset.browser_download_url,notes:release.body || ''};
      }
    }
    return best;
  }
  const show=(message,details='')=>{status.textContent=message;description.textContent=details;};
  async function check() {
    if (busy) return;
    busy=true; available=null; install.hidden=true;panel.hidden=false;
    button.disabled=true;show('Checking published GitHub releases…',`Installed: v${CURRENT}`);
    try {
      const response=await window.CourtlineUpdatesTransport.check(API);
      if (!response || response.status!==200) throw Error('GitHub returned HTTP '+(response?.status || 'unknown'));
      const entries=JSON.parse(response.text);
      if (!Array.isArray(entries)) throw Error('Invalid GitHub release list');
      const latest=newest(entries);
      if (!latest) show('No published CourtLine update packages found.','A release containing this platform’s APK or Swift Playgrounds ZIP must be published first.');
      else if (compare(latest.version,CURRENT)===null) show('Could not compare version numbers.','Please check your app version and release filenames.');
      else if (compare(latest.version,CURRENT)<=0) show('You’re up to date.',`Installed v${CURRENT} · Latest published v${latest.version}`);
      else {
        available=latest;
        show(`CourtLine v${latest.version} is available!`,PLATFORM==='android'
          ? `Installed v${CURRENT}. Download the signed APK, then approve installation when Android prompts you.`
          : `Installed v${CURRENT}. Download the ZIP, import it into Swift Playgrounds, and run the new project. Existing app data may need to be transferred.`);
        install.textContent=PLATFORM==='android'?'Download & Install APK':'Get iPad Project ZIP';install.hidden=false;
      }
    } catch(e) { show('Could not check for updates.',e?.message || 'Check your internet connection and try again.'); }
    finally { busy=false;button.disabled=false; }
  }
  button.addEventListener('click',check);
  close.addEventListener('click',()=>{panel.hidden=true;});
  panel.addEventListener('click',e=>{if(e.target===panel)panel.hidden=true;});
  install.addEventListener('click',async()=>{
    if(!available || busy || !validUrl(available.url,available.name))return;
    busy=true;install.disabled=true;
    try{
      show(PLATFORM==='android'?'Starting secure APK download…':'Opening the iPad project download…',available.name);
      await window.CourtlineUpdatesTransport.download(available.url,available.name);
      if(PLATFORM==='android') show('Download started.','Android will offer to install the APK after it finishes downloading. Please approve the system installer.');
      else show('Project download opened.','Use Safari’s Downloads/Files to import the ZIP into Swift Playgrounds.');
    }catch(e){show('Could not start the update.',e?.message || 'Try again.');}
    finally{busy=false;install.disabled=false;}
  });
  // Exposed for Node tests only; UI still uses native platform operations.
  if(typeof module!=='undefined'&&module.exports)module.exports={compare,newest,validUrl};
})();
