// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes

let package = Package(
    name: "Courtline iPad",
    platforms: [.iOS("18.0")],
    products: [
        .iOSApplication(
            name: "Courtline iPad",
            targets: ["AppModule"],
            bundleIdentifier: "com.cerberus.courtline.ipadtest",
            displayVersion: "1.0.1",
            bundleVersion: "101",
            appIcon: .placeholder(icon: .star),
            accentColor: .presetColor(.green),
            supportedDeviceFamilies: [.pad],
            supportedInterfaceOrientations: [.landscapeLeft, .landscapeRight, .portrait, .portraitUpsideDown],
            capabilities: [.localNetwork(purposeString: "Courtline connects to your vMix computer on your local Wi-Fi network.")],
            additionalInfoPlistContentFilePath: "AppInfo.plist"
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: ".",
            exclude: ["README.md", "AppInfo.plist", "Tests", "Web"]
        )
    ],
    swiftLanguageVersions: [.v5]
)
