'use strict';
const assert=require('node:assert/strict');const fs=require('node:fs');
const html=fs.readFileSync('Web/index.html','utf8');
const css=fs.readFileSync('Web/courtline-themes.css','utf8');
const js=fs.readFileSync('Web/courtline-themes.js','utf8');
assert.equal((html.match(/data-theme-option="red"/g)||[]).length,1);
assert(html.includes('Crimson Red')&&html.includes('Royal Purple'));
assert(js.includes("'purple','red','white'") && js.includes("red:'#ff6979'"));
for(const key of ['--shade-panel-a','--shade-tile-a','--shade-record-a','--shade-current-a','--shade-feature-a','--mgr-card-start','--mgr-ctl']){
 const red=css.split(':root[data-courtline-theme="red"]{').at(-1).split('}')[0];
 assert(red.includes(key+':'),key+' for Red');
}
assert(css.includes('.theme-swatch-red'));
assert(html.includes('iPAD v1.0.1'));
console.log('PASS sixth Crimson Red theme, management/stats shades, persistence support, original Purple preserved');
