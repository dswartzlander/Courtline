import SwiftUI
import WebKit
import UIKit

@main
struct CourtlineApp: App {
    var body: some Scene {
        WindowGroup {
            CourtlineView()
                .preferredColorScheme(.dark)
        }
    }
}

struct CourtlineView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> CourtlineViewController {
        CourtlineViewController()
    }
    func updateUIViewController(_ controller: CourtlineViewController, context: Context) {}
    static func dismantleUIViewController(_ controller: CourtlineViewController, coordinator: ()) {
        controller.shutdown()
    }
}
