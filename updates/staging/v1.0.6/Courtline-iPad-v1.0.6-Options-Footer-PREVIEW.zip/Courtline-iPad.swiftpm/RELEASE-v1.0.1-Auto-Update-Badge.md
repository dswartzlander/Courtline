# CourtLine iPad v1.0.1 — Startup Update Badge

At startup, perform a one-time non-blocking check of public stable CourtLine GitHub releases. A red exclamation badge appears on the Updates button only when a newer version exists. Never open a popup automatically. Normal manual Checks & Downloads are unchanged. Within one WebView session the badge survives browser reloads without repeating the network request. Offline startup stays silent; manual checks remain available. Swift Playgrounds import is still manual; displayVersion 1.0.1 and bundleVersion 101.
