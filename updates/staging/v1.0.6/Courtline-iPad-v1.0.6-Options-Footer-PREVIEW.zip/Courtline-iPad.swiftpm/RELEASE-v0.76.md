# CourtLine iPad v0.76 — Uniform Stats & Role Labels

- Main-device badge reads **CONTROL VIEW**, Companion badge reads **COMPANION VIEW**.
- Main and Companion Stats share matching court/tournament heading typography, single-row left-team / boxed-score / right-team layout, and consistent player panel sizing.
- The navigation tabs remain immediately actionable on the first tap when the five-second Stats toolbar auto-hide is active.
- Courts tab remains on Main only. Companion remains Stats and Telestrator.
- Stats, live court data, and vMix controls are preserved.
- The project is a Swift Playgrounds .swiftpm package, not a signed .ipa.
