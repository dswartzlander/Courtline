# CourtLine iPad v1.0.2 — Scoreholio branding

Added user-supplied Scoreholio logo to the CourtLine header, immediately to the right of the platform/version label with a `Powered by` caption above it. The current CourtLine logo and all controls remain in place. The original image colors remain unchanged across themes. Update badge and GitHub updater remain functional. Import using Swift Playgrounds.
