# CourtLine iPad v0.85 — Remaining Theme Accents

Brings the five existing theme palettes to the remaining iPad Main/Live UI details: Stats score separator and Preview B link; Settings unlocked icon; Main/Companion role badge; Telestrator Settings header button; Courts assignment chips, monitoring buttons, activity log and status labels. Original Teal unchanged; warnings and disabled states remain distinct. No change to scoring, networking, vMix, court assignments, tabs, or layouts. Regenerate embedded resources before installing in Swift Playgrounds.
