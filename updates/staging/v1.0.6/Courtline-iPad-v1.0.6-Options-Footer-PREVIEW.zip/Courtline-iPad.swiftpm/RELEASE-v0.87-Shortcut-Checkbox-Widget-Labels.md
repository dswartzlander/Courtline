# CourtLine iPad v0.87 — Main Settings checkbox and widget-label theme parity

- Automation and legacy Telestrator shortcut **Enabled** checkboxes now use the selected theme color rather than the native blue/teal accent.
- Device Widget & Event metadata status and **Open Scoreboard** link are themed explicitly.
- Original Teal remains unchanged; scoring, court selection and vMix behavior remain unchanged.
- The project embeds the editable Web files in CourtlineResources.swift for Swift Playgrounds.
