'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');

const root=process.argv[2]||'Web';
assert(root,'Provide Web/assets path');
const telestrator=fs.readFileSync(path.join(root,'telestrator.js'),'utf8');
const desktop=fs.readFileSync(path.join(root,'desktop.js'),'utf8');
const companion=fs.readFileSync(path.join(root,'companion.js'),'utf8');
assert.match(desktop,/getElementById\('telestratorCourt'\+i\)\.addEventListener\('click',[\s\S]*?window\.courtlineSelectLocalStatsCourt\?\.\(i\)/,'Telestrator button should trigger local Stats selection');
assert.doesNotMatch(companion,/courtlineSelectLocalStatsCourt/,'Shared Helper changes must not change the local Stats court');

const elements=new Map(),listeners=new Map(),calls=[];
function el(id){
  if(!elements.has(id)){
    const attrs={};const handlers={};
    elements.set(id,{
      id, hidden:false, dataset:{}, tabIndex:0, textContent:'', title:'', open:false,
      classList:{contains:()=>false},
      addEventListener(type,cb){(handlers[type]??=[]).push(cb);},
      fire(type,event={}){(handlers[type]||[]).forEach(cb=>cb({currentTarget:this,preventDefault(){},...event}));},
      setAttribute(name,value){attrs[name]=value;},
      getAttribute(name){return attrs[name]??null;},
      getBoundingClientRect(){return {x:0,y:0,width:0,height:0};},
      focus(){},showModal(){this.open=true;},close(){this.open=false;},
    });
  }
  return elements.get(id);
}
const body=el('body');
body.dataset={};
body.classList={contains:name=>name==='display-mode'};
const document={body, getElementById:el,querySelector:()=>null,addEventListener:(name,cb)=>{listeners.set(name,cb);}};
const window={
  addEventListener:()=>{},
  CourtlineNative:{telestrator:(info)=>calls.push(info)},
  refreshStatsCourtStatus:()=>{},
  dispatchEvent:()=>{},
  innerWidth:1366,
};
const observer=class{observe(){}};
vm.runInNewContext(telestrator,{
  document,window,ResizeObserver:observer,MutationObserver:observer,
  requestAnimationFrame:()=>{},Event:class{},console
});
assert(listeners.has('DOMContentLoaded'));
for(let i=1;i<=4;i++)el('statsCourt'+i).dataset.statsTournament='Tournament '+i;
listeners.get('DOMContentLoaded')();
const statsButton=i=>el('statsCourtTab'+(i+1));
const assertSelected=i=>{
  assert.equal(el('statsCourtTitle').textContent,`Court ${String(i+1).padStart(2,'0')} Stats`);
  assert.equal(el('statsTournamentTitle').textContent,'Tournament '+(i+1));
  for(let j=0;j<4;j++){
    assert.equal(statsButton(j).getAttribute('aria-selected'),String(j===i));
    assert.equal(el('statsCourt'+(j+1)).hidden,j!==i);
  }
};
assert.equal(typeof window.courtlineSelectLocalStatsCourt,'function');
for(let i=0;i<4;i++){
  window.courtlineSelectLocalStatsCourt(i);
  assertSelected(i);
}
// Stats tab remains a purely local choice; it must not cause a Telestrator/native switch.
let remoteCount=calls.length;
statsButton(1).fire('click');assertSelected(1);
assert.equal(calls.length,remoteCount,'Stats button must not change the Telestrator');
statsButton(3).fire('keydown',{key:'End'});assertSelected(3);
assert.equal(calls.length,remoteCount,'Stats keyboard navigation must not change the Telestrator');
// A new Telestrator choice should update the local Stats court immediately.
window.courtlineSelectLocalStatsCourt(2);assertSelected(2);
window.courtlineSelectLocalStatsCourt(-1);assertSelected(2);
window.courtlineSelectLocalStatsCourt(8);assertSelected(2);
assert.equal(calls.length,remoteCount,'local Stats update must not make native calls');
console.log('PASS: local one-way Telestrator → Stats court selection; Stats-only navigation; no Helper propagation');
