const vm=require('vm'),fs=require('fs'),assert=require('assert/strict');
(async()=>{
 const w={addEventListener(){}};const context={window:w,URL};vm.createContext(context);vm.runInContext(fs.readFileSync('Web/stats-data.js','utf8'),context);
 const data={scoreholioStats:{helperURL:'http://192.168.1.240:8100/api/stats?key=test',auto:false,seconds:10}},events=[];let release;
 const host={desktopSaveUI:value=>{assert.equal(value,data);events.push('queue-current-fields');},desktopFlushUI:async()=>events.push('flush'),localStorage:{setItem:(key,text)=>{assert.equal(JSON.parse(text).scoreholioStats.helperURL,data.scoreholioStats.helperURL);events.push('local');}}};
 const api={persist_ui:value=>new Promise(resolve=>{assert.equal(value,data);events.push('native');release=resolve;})};
 let done=false;const saving=w.ScoreholioStatsData.persist(data,api,host).then(()=>done=true);await new Promise(resolve=>setImmediate(resolve));assert.equal(done,false);assert.deepEqual(events,['queue-current-fields','flush','native']);release(true);await saving;assert.deepEqual(events,['queue-current-fields','flush','native','local']);
 const failedHost={...host,localStorage:{setItem(){throw Error('Should not save after native failure');}}};await assert.rejects(w.ScoreholioStatsData.persist(data,{persist_ui:async()=>{throw Error('Disk failure');}},failedHost),/Disk failure/);
 console.log('PASS: current helper fields queued before flush; native acknowledgment required; disk-save failures reported');
})().catch(e=>{console.error(e);process.exitCode=1;});
