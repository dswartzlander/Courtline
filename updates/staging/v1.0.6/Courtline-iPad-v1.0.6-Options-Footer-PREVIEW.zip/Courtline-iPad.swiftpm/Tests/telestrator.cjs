const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
const handlers={},observers=[],frames=[];let live=true,flushes=0,modal=false;
const node=()=>({events:{},attrs:{},addEventListener(type,fn){this.events[type]=fn;},setAttribute(name,value){this.attrs[name]=value;},focus(){this.focused=true;}});
const dialog={open:false,events:{},addEventListener(type,fn){this.events[type]=fn;},showModal(){this.open=true;modal=true;},close(){this.open=false;modal=false;this.events.close?.();}};
const nodes={telestratorSettingsDialog:dialog,openTelestratorSettings:node(),closeTelestratorSettings:node(),statsCourtTitle:{textContent:'Court 01 Stats'},telestratorViewport:{getBoundingClientRect:()=>({x:12,y:160,width:1000,height:1100})},assignmentAlert:{hidden:true},telestratorStatus:{},reloadTelestrator:node(),courtsTab:node(),telestratorTab:node(),statsTab:node(),courtAlertCount:{}};
for(let i=1;i<=4;i++){nodes['statsCourtTab'+i]=node();nodes['statsCourt'+i]={hidden:i!==1,dataset:{statsTournament:'Court '+i+' Tournament'}};}
const context={document:{body:{dataset:{},classList:{contains:name=>name==='display-mode'?live:false}},getElementById:id=>nodes[id],querySelector:()=>modal?{}:null,addEventListener:(type,fn)=>handlers[type]=fn},window:{innerWidth:1024,innerHeight:1366,dispatchEvent:()=>{},CourtlineNative:{telestrator:f=>frames.push(f)},desktopFlushUI:async()=>flushes++,addEventListener:(type,fn)=>handlers[type]=fn},ResizeObserver:class{constructor(fn){observers.push(fn)}observe(){}},MutationObserver:class{constructor(fn){observers.push(fn)}observe(){}},Event:class{constructor(type){this.type=type}},requestAnimationFrame:fn=>fn()};
vm.runInNewContext(fs.readFileSync('Web/telestrator.js','utf8'),context);
handlers.DOMContentLoaded();assert.equal(frames.at(-1).visible,false);assert.equal(context.document.body.dataset.liveTab,'courts');
nodes.telestratorTab.events.click();assert.equal(frames.at(-1).visible,true);assert.equal(nodes.telestratorTab.attrs['aria-selected'],'true');assert.equal(nodes.courtsTab.tabIndex,-1);
// Native WKWebView must hide behind the modal; closing restores it without reload.
nodes.openTelestratorSettings.events.click();assert.equal(dialog.open,true);assert.equal(frames.at(-1).visible,false);
nodes.closeTelestratorSettings.events.click();assert.equal(dialog.open,false);assert.equal(frames.at(-1).visible,true);assert.equal(frames.at(-1).reload,false);
// Reload Browser closes the settings dialog so native visible/reload work together.
nodes.openTelestratorSettings.events.click();assert.equal(frames.at(-1).visible,false);
await nodes.reloadTelestrator.events.click();assert.equal(dialog.open,false);assert.equal(frames.at(-1).visible,true);assert.equal(frames.at(-1).reload,true);

context.window.innerWidth=1366;context.window.innerHeight=1024;handlers.resize();assert.equal(frames.at(-1).visible,true);assert.equal(frames.at(-1).reload,false);
nodes.courtsTab.events.click();assert.equal(frames.at(-1).visible,false);assert.equal(nodes.courtsTab.attrs['aria-selected'],'true');
nodes.telestratorTab.events.click();assert.equal(frames.at(-1).visible,true);assert.equal(frames.at(-1).reload,false);
live=false;handlers['courtline-view-change']();assert.equal(frames.at(-1).visible,false);
live=true;handlers['courtline-view-change']();assert.equal(frames.at(-1).visible,true);assert.equal(context.document.body.dataset.liveTab,'telestrator');
nodes.assignmentAlert.hidden=false;observers[2]();assert.equal(frames.at(-1).visible,false);
nodes.assignmentAlert.hidden=true;observers[2]();assert.equal(frames.at(-1).visible,true);
modal=true;handlers['courtline-modal-change']();assert.equal(frames.at(-1).visible,false);
modal=false;handlers['courtline-modal-change']();assert.equal(frames.at(-1).visible,true);
await nodes.reloadTelestrator.events.click();assert.equal(flushes,2);assert.equal(frames.at(-1).reload,true);
handlers.resize();assert.equal(frames.at(-1).reload,false);
nodes.telestratorTab.events.keydown({key:'Home',preventDefault(){}});assert.equal(frames.at(-1).visible,false);assert.equal(nodes.courtsTab.focused,true);
nodes.courtsTab.events.keydown({key:'ArrowRight',preventDefault(){}});assert.equal(frames.at(-1).visible,false);assert.equal(nodes.statsTab.focused,true);
nodes.statsTab.events.keydown({key:'ArrowRight',preventDefault(){}});assert.equal(context.document.body.dataset.liveTab,'telestrator');assert.equal(frames.at(-1).visible,true);assert.equal(nodes.telestratorTab.attrs['aria-selected'],'true');
nodes.telestratorTab.events.keydown({key:'ArrowRight',preventDefault(){}});assert.equal(context.document.body.dataset.liveTab,'courts');
nodes.courtsTab.events.keydown({key:'End',preventDefault(){}});assert.equal(context.document.body.dataset.liveTab,'telestrator');
live=false;handlers['courtline-view-change']();live=true;handlers['courtline-view-change']();assert.equal(context.document.body.dataset.liveTab,'telestrator');assert.equal(frames.at(-1).visible,true);
nodes.statsCourtTab3.events.click();assert.equal(nodes.statsCourtTitle.textContent,'Court 03 Stats');assert.equal(nodes.statsCourt3.hidden,false);assert.equal(nodes.statsCourt1.hidden,true);assert.equal(nodes.statsCourtTab3.attrs['aria-selected'],'true');
nodes.statsCourtTab3.events.keydown({key:'ArrowRight',preventDefault(){}});assert.equal(nodes.statsCourt4.hidden,false);assert.equal(nodes.statsCourt3.hidden,true);
nodes.statsCourtTab4.events.keydown({key:'ArrowRight',preventDefault(){}});assert.equal(nodes.statsCourt1.hidden,false);
context.window.updateCourtAlertCount(2);assert.equal(nodes.courtAlertCount.textContent,'(2 alerts)');
context.window.updateCourtAlertCount(1);assert.equal(nodes.courtAlertCount.textContent,'(1 alert)');
context.window.updateCourtAlertCount(0);assert.equal(nodes.courtAlertCount.textContent,'');
context.window.telestratorStatus('Connection failed');assert.equal(nodes.telestratorStatus.textContent,'Connection failed');
console.log('PASS: Courts, Stats, Telestrator main navigation; tab switching without reload; both orientations; Settings return; alerts/modals; keyboard tabs; alert count; explicit Reload; native visibility and status');
})().catch(e=>{console.error(e);process.exit(1)});
