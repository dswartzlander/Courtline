'use strict';
const path=require('node:path'),fs=require('node:fs'),assert=require('node:assert/strict'),vm=require('node:vm');
const root=path.resolve(__dirname,'..');const web=process.argv[2]||'Web';
const callbacks={},nodes={},frames=[];let modal=false,visible=true;
function el(){return {events:{},attrs:{},addEventListener(k,fn){this.events[k]=fn;},setAttribute(k,v){this.attrs[k]=v},focus(){},click(){},};}
const dialog=Object.assign(el(),{open:false,showModal(){this.open=true;modal=true;},close(){this.open=false;modal=false;this.events.close?.();}});
for(const k of ['telestratorSettingsButton','openTelestratorSettings','closeTelestratorSettings','reloadTelestrator','courtsTab','telestratorTab','statsTab','courtAlertCount'])nodes[k]=el();
nodes.telestratorSettingsDialog=dialog;
nodes.telestratorViewport={getBoundingClientRect(){return {x:1,y:1,width:600,height:400};}};
nodes.telestratorStatus={};nodes.assignmentAlert={hidden:true};nodes.statsCourtTitle={};
for(let i=1;i<=4;i++){nodes['statsCourtTab'+i]=el();nodes['statsCourt'+i]={hidden:false};}
const context={document:{body:{dataset:{},classList:{contains:key=>key==='theme-menu-open'?false:visible}},getElementById:k=>nodes[k],querySelector:()=>modal?{}:null,addEventListener:(k,fn)=>callbacks[k]=fn},window:{innerWidth:1000,CourtlineNative:{telestrator:f=>frames.push(f)},desktopFlushUI:async()=>true,dispatchEvent:()=>{},addEventListener:(k,fn)=>callbacks[k]=fn},ResizeObserver:class{constructor(f){}observe(){}},MutationObserver:class{constructor(f){}observe(){}},Event:class{constructor(type){this.type=type}},requestAnimationFrame:f=>f()};
vm.runInNewContext(fs.readFileSync(path.join(root,web,'telestrator.js'),'utf8'),context);
callbacks.DOMContentLoaded();nodes.telestratorTab.events.click();
context.window.courtlineReloadTelestrator();assert.equal(frames.at(-1).reload,true,'visible change reloads');
callbacks.resize();assert.equal(frames.at(-1).reload,false,'later layout changes do not reload');
// When modal covers native browser, remember request until modal closes.
if(nodes.openTelestratorSettings.events.click)nodes.openTelestratorSettings.events.click();
else if(nodes.telestratorSettingsButton.events.click)nodes.telestratorSettingsButton.events.click();
assert.equal(dialog.open,true,'settings opens');
context.window.courtlineReloadTelestrator();assert.equal(frames.at(-1).reload,false,'hidden view must not reload');
dialog.close();assert.equal(frames.at(-1).reload,true,'reloading occurs on return to visible browser');
callbacks.resize();assert.equal(frames.at(-1).reload,false,'once only');
nodes.courtsTab.events.click();context.window.courtlineReloadTelestrator();assert.equal(frames.at(-1).reload,false,'off-tab reload is queued');
nodes.telestratorTab.events.click();assert.equal(frames.at(-1).reload,true,'tab return processes queued reload');
callbacks.resize();assert.equal(frames.at(-1).reload,false,'no repeat');
console.log('PASS '+web+': queued confirmed court reloads wait for visible browser and execute exactly once');
