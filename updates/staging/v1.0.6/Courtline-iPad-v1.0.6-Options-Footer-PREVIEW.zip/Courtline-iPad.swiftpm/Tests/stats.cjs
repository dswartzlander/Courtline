const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const source=fs.readFileSync('Web/app.js','utf8');
const start=source.indexOf('  function drawStats('),end=source.indexOf('  function drawCard(',start);
const nodes={};for(let t=0;t<2;t++){nodes[`[data-stats-team="${t}"]`]={textContent:'',hidden:true};for(let p=0;p<2;p++)nodes[`[data-stats-player="${t}-${p}"]`]={textContent:''};}
const tournamentNode={textContent:''};const panel={querySelector:s=>nodes[s],dataset:{},hidden:false};const context={window:{},tournamentDisplayName:s=>String(s||'').trim(),document:{getElementById:id=>id==='statsTournamentTitle'?tournamentNode:panel}};vm.createContext(context);vm.runInContext(source.slice(start,end),context);
context.drawStats(0,{name:'Summer Doubles',matchup:[{teamName:'Team A',players:['Alice','Bob']},{players:['Carol','Dan']}]});
assert.equal(tournamentNode.textContent,'Summer Doubles');assert.equal(nodes['[data-stats-team="0"]'].textContent,'Team A');assert.equal(nodes['[data-stats-team="0"]'].hidden,false);assert.equal(nodes['[data-stats-team="1"]'].hidden,true);assert.equal(nodes['[data-stats-player="1-1"]'].textContent,'Dan');
context.drawStats(0,{matchup:[]});assert.equal(nodes['[data-stats-team="0"]'].hidden,true);assert.equal(nodes['[data-stats-player="0-0"]'].textContent,'Waiting for player');
context.drawStats(0,{matchup:[{players:['Solo']}]});assert.equal(nodes['[data-stats-player="0-0"]'].textContent,'Solo');assert.equal(nodes['[data-stats-player="0-1"]'].textContent,'Waiting for player');
console.log('PASS: team names optional, four player positions, cleared assignments, singles placeholders');
