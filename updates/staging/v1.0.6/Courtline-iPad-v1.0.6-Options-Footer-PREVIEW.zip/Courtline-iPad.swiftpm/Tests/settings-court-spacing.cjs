'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.join(__dirname,'..');
const css=fs.readFileSync(path.join(root,'Web/desktop.css'),'utf8');
// Regression: the Settings-specific override MUST come after the grid display
// used by Live mode, otherwise Settings renders an empty bordered strip.
const specific='body:not(.display-mode) .court-card-bottom > .automation-live';
const matches=[...css.matchAll(/body:not\(\.display-mode\) \.court-card-bottom > \.automation-live\s*\{([^}]*)\}/g)];
assert(matches.length>=1,'missing settings-only visibility rule');
const last=matches.at(-1);
assert.match(last[1],/(?:^|;)\s*display\s*:\s*none\s*(?:;|$)/,'Settings must hide entire activity section');
const liveRule=css.indexOf('body.display-mode .court-card-bottom > .automation-live{display:grid');
assert(liveRule!==-1,'Live view activity grid must remain visible');
assert(last.index>liveRule,'Settings must win stylesheet order');
const desktop=fs.readFileSync(path.join(root,'Web/desktop.js'),'utf8');
assert(desktop.includes("const live=element('section','automation-live')"),'Live activity section remains in DOM');
assert(desktop.includes("live.append(open)"),'Live activity trigger remains available');
console.log('OK: Settings blank divider hidden; Live activity still present');
