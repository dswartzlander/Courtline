const assert=require('assert/strict'),fs=require('fs'),vm=require('vm');const context={module:{exports:{}}};vm.runInNewContext(fs.readFileSync('Web/match-stats.js','utf8'),context);const D=context.module.exports;
const sides=[{id:'a',timesPlayed:'2',placement:'3',bestWins:'1',players:['Alice','Bob']},{id:'b',timesPlayed:'1',placement:'4',bestWins:'0',players:['Carol','Dan']}];
assert.equal(D.ids('account','event',sides,false)[0],'account-event-a-2-b-1');assert.equal(D.ids('account','event',sides,true)[0],'account-event-a-3-1-b-4-0');
const fields=o=>Object.fromEntries(Object.entries(o).map(([k,v])=>[k,typeof v==='number'?{integerValue:String(v)}:{stringValue:v}]));
const rows=[fields({team1:'a',team1playername:'Alice',team1score:12,team1in:4,team1on:0,team1off:0,team2:'b',team2playername:'Carol',team2score:8,team2in:2,team2on:2,team2off:0}),fields({team1:'a',team1playername:'Bob',team1score:6,team1in:1,team1on:3,team1off:0}),fields({team1:'a',team1playername:'Alice',team1score:4,team1in:1,team1on:1,team1off:2})];
let v=D.summarize(rows,sides);assert.equal(v[0][0].PPR,'8.00');assert.equal(v[0][0]['4IN'],'1');assert.equal(v[0][0].IN,'5');assert.equal(v[0][0].OFF,'2');assert.equal(v[0][1].PPR,'6.00');assert.equal(v[1][1],null);
v=D.summarize([fields({team1:'a',team1playername:'Alice',team1score:0})],sides);assert.equal(v[0][0].PPR,'0.00');assert.equal(v[0][0].IN,'—');assert.equal(D.summarize(rows,[{...sides[0],players:['Alice','Alice']}])[0][0],null);
console.log('PASS current match identities, per-player rounds, averages, four baggers, zero, missing and duplicate names');
