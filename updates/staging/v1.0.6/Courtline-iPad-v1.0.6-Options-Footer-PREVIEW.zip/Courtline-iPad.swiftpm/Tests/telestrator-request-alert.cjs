'use strict';
const fs=require('node:fs');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const path=require('node:path');

class Element {
  constructor(){this.children=[];this.listeners={};this.attrs={};this.hidden=false;this.textContent='';this.classNames=new Set();this.classList={
    add:(s)=>this.classNames.add(s),
    toggle:(s,on)=>{if(on===undefined) on=!this.classNames.has(s);if(on)this.classNames.add(s);else this.classNames.delete(s);return on;},
    contains:(s)=>this.classNames.has(s)
  };}
  append(...children){this.children.push(...children);}
  insertBefore(el){this.children.push(el);}
  querySelector(){return null;}
  setAttribute(k,v){this.attrs[k]=v;}
  addEventListener(k,fn){this.listeners[k]=fn;}
}
async function main(){
  const {createCompanionSession}=await import(path.resolve(__dirname,'companion-session.fixture.mjs'));
  const session=createCompanionSession();
  const source=fs.readFileSync(path.resolve(__dirname,'../Web/companion.js'),'utf8');
  const html=fs.readFileSync(path.resolve(__dirname,'../Web/index.html'),'utf8');
  const css=fs.readFileSync(path.resolve(__dirname,'../Web/desktop.css'),'utf8');
  assert.match(html,/id="openTelestratorSettings"[^>]*>[\s\S]*?id="telestratorRequestBadge"/);
  assert.match(css,/#openTelestratorSettings\.has-control-request\{display:inline-flex/);
  assert.match(css,/telestrator-control-request-badge\[hidden\]\{display:none!important\}/);
  function device(name,role){
    const nodes=new Map([['openTelestratorSettings',new Element()],['telestratorRequestBadge',new Element()],['telestratorSettingsContents',new Element()],['telestratorCommandStatus',new Element()]]);
    for(let i=0;i<4;i++)nodes.set('telestratorCourt'+i,new Element());
    const store=new Map(),timers=[];
    const api={companion:async (_url,action,params)=>{
      if(action==='session')return {role};
      if(action==='telestrator')return session.control(params,role);
      if(action==='getLive')return {snapshot:null,stale:false};
      if(action==='publishLive')return {accepted:true};
      throw Error('Bad action '+action);
    }};
    const document={hidden:false,body:{classList:{add(){},toggle(){}}},getElementById:(id)=>nodes.get(id),createElement:()=>new Element()};
    const window={pywebview:{api},CourtlineDeviceName:name,desktopCollectUI:()=>({scoreholioStats:{helperURL:'http://helper'}})};
    vm.runInNewContext(source,{window,document,localStorage:{getItem:(k)=>store.get(k)||null,setItem:(k,v)=>store.set(k,String(v))},crypto:{randomUUID:()=>name.replace(/\W/g,'').padEnd(14,'Z')},setInterval:(fn)=>timers.push(fn),confirm:()=>true});
    const bar=()=>nodes.get('telestratorSettingsContents').children[0];
    return {name,window,nodes,async ready(){await window.CourtlineCompanion.identify('http://helper');window.CourtlineCompanion.begin();await new Promise(setImmediate);},async poll(){await timers[0]();},button:()=>bar().children[4],grant:()=>bar().children[5],deny:()=>bar().children[6],notice:()=>bar().children[9],badge:()=>nodes.get('telestratorRequestBadge'),trigger:()=>nodes.get('openTelestratorSettings')};
  }
  const mainDevice=device('Main iPad','main'),alice=device('Alice Android','viewer'),bob=device('Bob iPad','viewer');
  await Promise.all([mainDevice.ready(),alice.ready(),bob.ready()]);
  // No pending requests: no warning, and no false positives for viewers.
  assert.equal(mainDevice.badge().hidden,true);
  assert.equal(mainDevice.trigger().classList.contains('has-control-request'),false);
  // Alice controls, Bob requests. The Main must know even though it isn't the controller.
  await alice.button().listeners.click();
  await bob.poll();
  await bob.button().listeners.click();
  await mainDevice.poll(); await alice.poll();
  for(const owner of [mainDevice,alice]){
    assert.equal(owner.badge().hidden,false);
    assert.equal(owner.badge().textContent,'1 REQUEST');
    assert.equal(owner.trigger().classList.contains('has-control-request'),true);
    assert.match(owner.trigger().attrs['aria-label'],/1 pending control request/);
    assert.match(owner.notice().textContent,/Bob iPad is requesting telestrator control/);
    assert.equal(owner.grant().hidden,false);
    assert.equal(owner.deny().hidden,false);
  }
  assert.equal(bob.badge().hidden,true,'requester must not be prompted to grant their own request');
  // Main can grant even when the holder is another companion, as the Helper allows.
  await mainDevice.grant().listeners.click();await alice.poll();await bob.poll();
  for(const d of [mainDevice,alice,bob]){
    assert.equal(d.badge().hidden,true,'grant must clear notification on every device');
    assert.equal(d.trigger().classList.contains('has-control-request'),false);
    assert.equal(d.grant().hidden,true);
  }
  // A subsequent request can be explicitly declined; this must also clear it.
  await alice.button().listeners.click(); await bob.poll(); await alice.poll();await mainDevice.poll();
  assert.equal(bob.badge().hidden,false);
  await bob.deny().listeners.click(); await mainDevice.poll(); await alice.poll();
  assert.equal(bob.badge().hidden,true);
  assert.equal(mainDevice.badge().hidden,true);
  // Multiple requests produce an accurate count.
  await mainDevice.button().listeners.click(); // Main requests access while Bob holds it.
  await alice.button().listeners.click(); // Alice requests access while Bob holds it.
  await bob.poll();
  assert.equal(bob.badge().textContent,'2 REQUESTS');
  assert.match(bob.notice().textContent,/2 devices are waiting/);
  // Once the holder releases, queue stays pending until dealt with; deny clears one.
  await bob.deny().listeners.click();await bob.poll();
  assert.equal(bob.badge().textContent,'1 REQUEST');
  await bob.grant().listeners.click();await bob.poll();
  assert.equal(bob.badge().hidden,true);
  console.log('PASS: requester badges on Main/controller outside settings; count; accessible message; approve/decline; no viewer false alert; clear after resolution');
}
main().catch(error=>{console.error(error);process.exitCode=1;});
