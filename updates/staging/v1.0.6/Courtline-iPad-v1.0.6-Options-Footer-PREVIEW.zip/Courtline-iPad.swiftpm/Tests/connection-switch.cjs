const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');

const swift=fs.readFileSync('CourtlineViewController.swift','utf8');
const engine=fs.readFileSync('Web/engine.js','utf8');
const html=fs.readFileSync('Web/index.html','utf8');
assert.match(swift,/case "switchCompanion":\s*switchCompanion\(args\)/);
assert.match(swift,/"\/api\/session"/);
assert.match(swift,/guard response\.statusCode == 200,[\s\S]*?\["main", "viewer"\]\.contains\(role\)/);
assert.match(swift,/stats\["helperURL"\] = statsURL\.absoluteString/);
assert.match(swift,/content\.removeAllUserScripts\(\)/);
assert.match(swift,/self\.bridgeBootstrap\(text\)/);
assert.match(engine,/switch_companion:code=>call\('switchCompanion',code\)/);
assert.match(html,/<button class="live-pill connection-switch-button" id="liveIndicator"/);
assert.match(html,/<script src="\.\/connection-switch\.js" defer><\/script>/);

function makeContext(role='viewer'){
  const listeners=new Map(),writes=new Map(),nodes=new Map();
  function node(){const handlers=new Map();return {disabled:false,textContent:'',classList:{toggle(){}},
    addEventListener:(name,fn)=>handlers.set(name,fn),fire:(name,...args)=>handlers.get(name)?.(...args),focus(){},
    setAttribute(){},get handlers(){return handlers;}};}
  const trigger=node(),current=node(),feedback=node(),cancel=node(),scan=node(),dialog={...node(),open:false,
    showModal(){this.open=true;},close(){this.open=false;},
    querySelector(selector){return nodes.get(selector);}};
  nodes.set('#connectionSwitchCurrent',current);nodes.set('#connectionSwitchFeedback',feedback);
  nodes.set('[data-cancel]',cancel);nodes.set('[data-scan]',scan);
  let scanResult=null,confirmed=null,reloads=0,checks=0,flushes=0;
  const context={document:{getElementById:id=>id==='liveIndicator'?trigger:null,createElement:()=>dialog,body:{append(){}}},
    window:{CourtlineCompanion:{url:'http://pc/api/stats?key=old',role},addEventListener:(type,fn)=>listeners.set(type,fn),
      desktopFlushUI:async()=>{flushes++;},pywebview:{api:{scan_stats_helper:async()=>scanResult,switch_companion:async code=>{checks++;assert.equal(code,'http://pc/api/stats?key=new');if(confirmed instanceof Error)throw confirmed;return confirmed;}}}},
    localStorage:{setItem:(key,value)=>writes.set(key,value)},location:{reload(){reloads++;}},console};
  vm.runInNewContext(fs.readFileSync('Web/connection-switch.js','utf8'),context);
  return {trigger,current,feedback,cancel,scan,dialog,writes,listeners,
    setScan:value=>{scanResult=value;},setConfirmed:value=>{confirmed=value;},
    counts:()=>({reloads,checks,flushes})};
}

(async()=>{
  const viewer=makeContext('viewer');
  assert.equal(viewer.trigger.disabled,true);
  viewer.listeners.get('courtline-ready')();assert.equal(viewer.trigger.disabled,false);
  viewer.trigger.fire('click');assert.equal(viewer.dialog.open,true);
  assert.match(viewer.current.textContent,/Companion Viewer/);
  viewer.cancel.fire('click');assert.equal(viewer.dialog.open,false);
  assert.equal(viewer.counts().checks,0);assert.equal(viewer.writes.size,0);

  viewer.trigger.fire('click');await viewer.scan.fire('click');
  assert.match(viewer.feedback.textContent,/Scan canceled/);assert.equal(viewer.counts().checks,0);
  assert.equal(viewer.dialog.open,true);assert.equal(viewer.writes.size,0);

  viewer.setScan('http://pc/api/stats?key=new');viewer.setConfirmed(new Error('Invalid pairing'));
  await viewer.scan.fire('click');
  assert.match(viewer.feedback.textContent,/Invalid pairing/);assert.equal(viewer.counts().reloads,0);
  assert.equal(viewer.writes.size,0);assert.equal(viewer.dialog.open,true);

  viewer.setConfirmed({url:'http://pc/api/stats?key=new',role:'main'});
  await viewer.scan.fire('click');
  assert.equal(viewer.counts().reloads,1);assert.equal(viewer.dialog.open,false);
  assert.deepEqual(JSON.parse(viewer.writes.get('courtline-companion-role-v1')),
    {role:'main',url:'http://pc/api/stats?key=new'});

  const main=makeContext('main');main.listeners.get('courtline-ready')();main.trigger.fire('click');
  assert.match(main.current.textContent,/Main Device/);
  main.setScan('http://pc/api/stats?key=new');main.setConfirmed({url:'http://pc/api/stats?key=new',role:'viewer'});
  await main.scan.fire('click');assert.equal(main.counts().reloads,1);
  assert.equal(JSON.parse(main.writes.get('courtline-companion-role-v1')).role,'viewer');
  console.log('PASS: Main/Companion badge, Cancel, canceled scan, rejected QR unchanged, both verified role directions, native session/authenticated persistence and refreshed reload bootstrap');
})().catch(e=>{console.error(e);process.exitCode=1;});
