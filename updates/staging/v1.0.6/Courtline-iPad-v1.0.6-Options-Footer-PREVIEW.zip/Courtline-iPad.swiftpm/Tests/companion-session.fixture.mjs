// In-memory, single-writer coordination for the iPad live mirror and vMix Telestrator.
// Match state is never editable by a viewer. vMix itself owns the shared drawing canvas.
import {randomUUID} from 'node:crypto';
export function createCompanionSession({clock=()=>Date.now(), leaseMs=15000}={}) {
  let live=null, liveUpdatedAt=0, livePublisher='';
  let holder=null, waiting=[];
  // One globally selected court. The Main executes the actual vMix shortcut and
  // acknowledges it before every viewer is told that the court has changed.
  let selectedCourt=null,selectionRevision=0,pendingCourt=null,selectionError='';
  const clientId=value=>typeof value==='string'&&/^[a-zA-Z0-9_-]{8,100}$/.test(value)?value:null;
  const displayName=value=>String(value||'CourtLine device').trim().slice(0,60)||'CourtLine device';
  function expire() {
    const now=clock();
    if(holder&&holder.expiresAt<=now)holder=null;
    waiting=waiting.filter(row=>row.requestedAt+120000>now);
  }
  function selection() {return {court:selectedCourt,revision:selectionRevision,pending:pendingCourt&&{...pendingCourt},error:selectionError};}
  function status() {expire();return {holder:holder&&{...holder},waiting:waiting.map(row=>({...row})),leaseMs,selection:selection()};}
  function publish(value) {
    const id=clientId(value?.deviceId);
    if(!id)throw Error('Invalid primary CourtLine device ID.');
    if(!Array.isArray(value.courts)||value.courts.length!==4||value.courts.some(row=>!row||typeof row!=='object'||Array.isArray(row)))throw Error('Exactly four court snapshots are required.');
    if(!Array.isArray(value.visibleCourts)||value.visibleCourts.length!==4||value.visibleCourts.some(flag=>typeof flag!=='boolean'))throw Error('Invalid court visibility.');
    const vmixAddress=String(value.vmixAddress||'').trim();
    const url=new URL(vmixAddress);
    if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.search||url.hash||!['','/'].includes(url.pathname)||['localhost','127.0.0.1','[::1]'].includes(url.hostname.toLowerCase()))throw Error('Invalid vMix LAN address.');
    const serialized=JSON.stringify({courts:value.courts,visibleCourts:value.visibleCourts,vmixAddress:url.origin});
    if(serialized.length>120000)throw Error('Court snapshot exceeds size limit.');
    live=JSON.parse(serialized);liveUpdatedAt=clock();livePublisher=id;
    return {accepted:true,updatedAt:liveUpdatedAt};
  }
  function currentLive() {return {snapshot:live,updatedAt:liveUpdatedAt,publisher:livePublisher,stale:!live||clock()-liveUpdatedAt>15000};}
  function control(value,role) {
    expire();
    const id=clientId(value?.deviceId);
    if(!id)throw Error('Invalid companion device ID.');
    const name=displayName(value.name),action=String(value.action||'status'),now=clock();
    const isHolder=holder?.deviceId===id;
    switch(action) {
      case 'status':break;
      case 'acquire':
        if(!holder||isHolder){holder={deviceId:id,name,expiresAt:now+leaseMs};waiting=waiting.filter(row=>row.deviceId!==id);}
        break;
      case 'request':
        if(!holder||isHolder){holder={deviceId:id,name,expiresAt:now+leaseMs};waiting=waiting.filter(row=>row.deviceId!==id);}
        else if(!waiting.some(row=>row.deviceId===id))waiting.push({deviceId:id,name,requestedAt:now});
        break;
      case 'heartbeat':
        if(isHolder)holder={deviceId:id,name,expiresAt:now+leaseMs};
        break;
      case 'release':
        if(isHolder||role==='main')holder=null;
        waiting=waiting.filter(row=>row.deviceId!==id);
        break;
      case 'approve': {
        if(!isHolder&&role!=='main')throw Error('Only the current controller or main device may grant access.');
        const target=clientId(value.target),next=waiting.find(row=>row.deviceId===target);
        if(!next)throw Error('The requested device is no longer waiting.');
        holder={deviceId:next.deviceId,name:next.name,expiresAt:now+leaseMs};
        waiting=waiting.filter(row=>row.deviceId!==target);break;
      }
      case 'deny':
        if(!isHolder&&role!=='main')throw Error('Only the current controller or main device may decline requests.');
        waiting=waiting.filter(row=>row.deviceId!==value.target);break;
      case 'force':
        if(role!=='main')throw Error('Only the main CourtLine device can override control.');
        holder={deviceId:id,name,expiresAt:now+leaseMs};waiting=waiting.filter(row=>row.deviceId!==id);break;
      case 'selectCourt': {
        if(role!=='main'&&!isHolder)throw Error('Only the Main device or current telestrator controller can select a court.');
        const court=value.court;
        if(!Number.isInteger(court)||court<0||court>3)throw Error('Court selection must be Court 1–4.');
        selectionRevision++;
        pendingCourt={court,revision:selectionRevision,requestId:randomUUID(),requestedBy:name};selectionError='';
        break;
      }
      case 'courtApplied': {
        if(role!=='main')throw Error('Only the Main device can confirm a court change.');
        if(!pendingCourt||value.revision!==pendingCourt.revision||value.requestId!==pendingCourt.requestId)throw Error('Stale or unknown court selection confirmation.');
        if(value.success===true)selectedCourt=pendingCourt.court;
        else selectionError=String(value.error||'Main device could not switch courts.').trim().slice(0,200);
        pendingCourt=null;
        break;
      }
      default:throw Error('Invalid telestrator action.');
    }
    return {...status(),canDraw:holder?.deviceId===id,requested:waiting.some(row=>row.deviceId===id)};
  }
  return {publish,currentLive,control,status};
}
