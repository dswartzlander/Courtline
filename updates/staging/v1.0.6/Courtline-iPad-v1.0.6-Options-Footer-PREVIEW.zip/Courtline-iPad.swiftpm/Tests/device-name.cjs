'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const file=path.join(__dirname, '../'+(fs.existsSync(path.join(__dirname,'../Web/companion.js'))?'Web':'assets')+'/companion.js');
const code=fs.readFileSync(file,'utf8');
let controller=null;
const mockHelper={async companion(_url,action,data){
  if(action==='session')return {role:'viewer'};
  if(action==='telestrator'){
    if(data.action==='acquire') controller={deviceId:data.deviceId,name:data.name};
    if(data.action==='heartbeat'&&controller?.deviceId===data.deviceId)controller.name=data.name;
    if(data.action==='release'&&controller?.deviceId===data.deviceId)controller=null;
    return {holder:controller&&{...controller},waiting:[],selection:{court:null},requested:false};
  }
  if(action==='getLive')return {stale:false};
  throw Error(action);
}};
class Node{
 constructor(){this.children=[];this.listeners={};this.hidden=false;this.classList={toggle(){},add(){}};}
 append(...children){this.children.push(...children)}
 insertBefore(child){this.children.push(child)}
 querySelector(){return this.children[0]||null}
 addEventListener(k,h){this.listeners[k]=h}
 setAttribute(){}
}
function makeDevice(label,storage){
 const nodes=new Map([['telestratorSettingsContents',new Node()],['telestratorCommandStatus',new Node()]]);
 const localStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,String(v))};
 const document={hidden:false,body:{classList:{toggle(){},add(){}}},getElementById:k=>nodes.get(k),createElement:()=>new Node()};
 const window={pywebview:{api:mockHelper},CourtlineDeviceName:label};
 const ticks=[];
 vm.runInNewContext(code,{window,document,localStorage,crypto:{randomUUID:()=>label.replace(/\W/g,'')+'-1234567890'},setInterval:fn=>ticks.push(fn)});
 return {window,document,nodes,ticks,storage,async ready(){await window.CourtlineCompanion.identify('http://helper');window.CourtlineCompanion.begin();await new Promise(setImmediate);}};
}
(async()=>{
 const stored1=new Map(),stored2=new Map();
 const a=makeDevice('CourtLine Android',stored1),b=makeDevice('CourtLine iPad',stored2);
 await a.ready();await b.ready();
 const bar=a.nodes.get('telestratorSettingsContents').children[0];
 const group=bar.children[0];
 assert.equal(group.children[0].textContent,'Device Name');
 const input=group.children[1],save=group.children[2];
 input.value='  Coach   Mike - Galaxy Tab  ';
 await save.listeners.click();
 assert.equal(a.window.CourtlineCompanion.deviceName,'Coach Mike - Galaxy Tab');
 const takeControl=bar.children[4];
 await takeControl.listeners.click();
 assert.equal(controller.name,'Coach Mike - Galaxy Tab');
 await b.ticks[0]();
 const bBar=b.nodes.get('telestratorSettingsContents').children[0];
 assert.equal(bBar.children[1].textContent,'Telestrator controlled by Coach Mike - Galaxy Tab');
 input.value='Mikey - Assistant';
 await save.listeners.click();
 assert.equal(controller.name,'Mikey - Assistant');
 await b.ticks[0]();
 assert.equal(bBar.children[1].textContent,'Telestrator controlled by Mikey - Assistant');
 const reloaded=makeDevice('CourtLine Android',stored1);
 assert.equal(reloaded.window.CourtlineCompanion.deviceName,'Mikey - Assistant');
 console.log('PASS: explicit device name saves, persists across reload, changes the active controller and appears to viewers');
})().catch(err=>{console.error(err);process.exitCode=1;});
