const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
const context={window:{addEventListener(){}},URL};vm.createContext(context);vm.runInContext(fs.readFileSync('Web/stats-data.js','utf8'),context);
const D=context.window.ScoreholioStatsData;
const sample=fs.readFileSync('Tests/fixtures/scoremagic.csv','utf8');
const rows=D.parse(sample);assert.equal(rows.length,9);assert.equal(D.match(rows,'ghost  2.')['PPR'],'8.07');assert.equal(D.match(rows,' DANIEL ALDAY ')['PPR'],'8.38');assert(!('Email' in rows[0]));
assert.equal(D.match([...rows,rows[0]],rows[0]['Display Name']),null);assert.equal(D.match(rows,'Unknown'),null);
assert.throws(()=>D.parse('Display Name,PPR\nA,2'));assert.throws(()=>D.parse(sample+'\n"unclosed'));
const quoted=sample.replace('Daniel Alday,','"Daniel, ""The Player"" Alday",');assert.equal(D.parse(quoted)[0]['Display Name'],'Daniel, "The Player" Alday');
assert.equal(D.event('http://192.168.1.240:8099/api/stats?key=test').url,'http://192.168.1.240:8099/api/stats?key=test');assert.throws(()=>D.event('http://localhost:8099/api/stats?key=test'));
console.log('PASS: actual 9-player CSV, quoting, whitespace matching, duplicate/missing players, email exclusion, malformed CSV, event URL validation');

vm.runInContext(fs.readFileSync('Web/settings-backup.js','utf8'),context);
const engineSource=fs.readFileSync('Web/engine.js','utf8');
assert(engineSource.includes("'statsHelper'"));

const clean=Object.fromEntries(['Display Name','Game Name',...D.metrics].map(k=>[k,rows[0][k]]));
const snapshot=D.snapshot({format:'courtline-stats',version:1,event:{account:'a',game:'g'},exportedAt:new Date().toISOString(),records:[clean]});assert.equal(snapshot.records[0].PPR,'8.38');assert.equal(snapshot.game,'g');assert.throws(()=>D.snapshot({format:'courtline-stats',records:[]}));

assert.throws(()=>D.event('javascript:alert(1)'));assert.throws(()=>D.event('http://192.168.1.240:8100/api/stats'));assert.throws(()=>D.event('http://user:pass@192.168.1.240:8100/api/stats?key=test'));assert.equal(D.event('http://192.168.1.240:8100/api/stats?key=abc123').url,'http://192.168.1.240:8100/api/stats?key=abc123');
const enriched=D.snapshot({format:'courtline-stats',version:1,event:{account:'a',game:'g'},exportedAt:new Date().toISOString(),records:[{...clean,SPR:'65.93','Qualifying Record':'6–5–0','Qualifying Record Scope':'Player','Bracket Record':'2–1','Bracket Record Scope':'Team','Overall PPR':'7.2',Email:'private@example.test'}]});
assert.equal(enriched.records[0].SPR,'65.93');assert.equal(enriched.records[0]['Qualifying Record'],'6–5–0');assert.equal(enriched.records[0]['Bracket Record Scope'],'Team');assert(!('Email' in enriched.records[0]));assert.equal(snapshot.records[0].SPR,'');assert.throws(()=>D.snapshot({format:'courtline-stats',version:1,event:{account:'a',game:'g'},exportedAt:new Date().toISOString(),records:[{...clean,SPR:65}]}));
console.log('PASS: roster/standings fields, scope, old-helper compatibility and privacy');
const four=[{'PPR':'8.31','DPR':'0.38','OPP PPR':'7.94','4IN':'5','4IN %':'31%','IN':'43','IN %':'67%','ON':'4','ON %':'6%','OFF':'17','OFF %':'27%'},{'PPR':'7.88','DPR':'-1','OPP PPR':'8.88','4IN':'3','4IN %':'12%','IN':'63','IN %':'61%','ON':'16','ON %':'15%','OFF':'25','OFF %':'24%'},{'PPR':'8.35','DPR':'0.22','OPP PPR':'8.13','4IN':'5','4IN %':'22%','IN':'50','IN %':'66%','ON':'15','ON %':'10%','OFF':'18','OFF %':'20%'},{'PPR':'7.88','DPR':'0.06','OPP PPR':'7.82','4IN':'5','4IN %':'29%','IN':'42','IN %':'62%','ON':'8','ON %':'12%','OFF':'18','OFF %':'26%'}];
const leaders=D.bestValues(four);assert(leaders.isBest(four[2],'PPR'));assert(!leaders.isBest(four[0],'PPR'));assert(leaders.isBest(four[0],'DPR'));assert(!leaders.isBest(four[1],'DPR'));assert(leaders.isBest(four[3],'OPP PPR'));for(const i of [0,2,3])assert(leaders.isBest(four[i],'4IN'));assert(leaders.isBest(four[0],'4IN %'));assert(leaders.isBest(four[1],'IN'));assert(leaders.isBest(four[0],'IN %'));assert(leaders.isBest(four[1],'ON'));assert(leaders.isBest(four[1],'ON %'));assert(leaders.isBest(four[0],'OFF'));assert(leaders.isBest(four[2],'OFF %'));
const missing=D.bestValues([null,{'DPR':'','OFF':'—','PPR':'bad'},{'DPR':'0','OFF':'0','PPR':'0'}]);assert(missing.isBest({'DPR':'0'},'DPR'));assert(!missing.isBest({'DPR':''},'DPR'));assert(!missing.isBest({'PPR':'bad'},'PPR'));assert(!D.bestValues([]).isBest(four[0],'PPR'));assert(D.bestValues([four[0],four[1]]).isBest(four[0],'PPR'));
console.log('PASS: court-only leaders, all metric directions, ties, negative DPR, percentages, zero and missing values');
const eventSnapshot=(game,ppr)=>({format:'courtline-stats',version:1,event:{account:'a',game},exportedAt:new Date().toISOString(),records:[{...clean,PPR:ppr}]});
const multi=D.snapshot({...eventSnapshot('one','8'),events:[eventSnapshot('one','8'),eventSnapshot('two','9')],helperStatus:{lastError:'Event 3 failed'}});assert.equal(multi.events.length,2);assert.equal(D.forCourt(multi,'a','two').records[0].PPR,'9');assert.equal(D.forCourt(multi,'a','one').records[0].PPR,'8');assert.equal(D.forCourt(multi,'wrong','two'),null);assert.equal(D.forCourt(multi,'a','missing'),null);assert.equal(D.forCourt(snapshot,'a','g').records[0].PPR,'8.38');assert.equal(multi.helperError,'Event 3 failed');assert.throws(()=>D.snapshot({...eventSnapshot('one','8'),events:[]}));
console.log('PASS: four-event snapshot matching isolates identical player names by event, single-event compatibility');
const assignment=D.assignment(2,{kind:'assigned',sourceType:'managed',name:'Event A',widgetUrl:'https://app.scoreholio.com/v2/cornhole/overlay?account=a&game=g&court=2'});assert.equal(assignment.slot,2);assert.equal(assignment.account,'a');assert.equal(assignment.game,'g');assert.equal(D.assignment(0,{kind:'idle',sourceType:'managed'}),null);assert.equal(D.assignment(0,{kind:'error'}),null);assert.equal(D.assignment(0,{kind:'assigned',sourceType:'scoreboard',widgetUrl:'https://app.scoreholio.com/?account=a&game=g'}),null);
console.log('PASS: only confirmed Remote Mode assignments are sent to helper');
const statusCache={events:[{account:'a',game:'one',at:'2026-10-28T22:00:00Z',records:[{},{}],helperError:''},{account:'a',game:'two',at:'2026-10-28T22:01:00Z',records:Array(38).fill({}),helperError:''}]};
assert(D.exportStatus(statusCache,'a','two').includes('38 players'));assert(D.exportStatus(statusCache,'a','two').includes(new Date('2026-10-28T22:01:00Z').toLocaleString()));assert(D.exportStatus(statusCache,'a','one').includes('2 players'));assert(D.exportStatus(statusCache,'a','missing').includes('No successful export'));assert(!D.exportStatus(statusCache,'a','missing').includes('38 players'));
console.log('PASS: selected-court export date/time and player count, unmatched-event status');
