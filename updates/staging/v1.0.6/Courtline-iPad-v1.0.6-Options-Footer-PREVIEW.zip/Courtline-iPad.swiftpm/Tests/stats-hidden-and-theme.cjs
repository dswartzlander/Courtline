'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const dir=path.join(__dirname,'../Web');const read=f=>fs.readFileSync(path.join(dir,f),'utf8');
test('Only one selected court in Stats',()=>{
 assert(read('desktop.css').includes('body.display-mode[data-live-tab="stats"] .stats-court-page[hidden]{display:none!important}'));
});
test('Permanent court and refresh controls leave first tap to target control',()=>{
 const code=read('companion-stats-ui.js');
 assert(!code.includes('stopImmediatePropagation'));assert(!code.includes('setTimeout('));
 assert(code.includes("classList.remove('stats-controls-hidden')"));
});
test('Theme picker still hides native telestrator',()=>{
 assert(read('courtline-themes.js').includes("classList.add('theme-menu-open')"));
 assert(read('telestrator.js').includes("!document.body.classList.contains('theme-menu-open')"));
});
test('Blue Orange and Purple show varied gradient shade instead of one solid shade',()=>{
 const css=read('courtline-themes.css');
 for(const t of ['blue','orange','purple'])assert(css.includes('data-courtline-theme="'+t+'"'));
 assert(css.includes('--shade-tile-a'));assert(css.includes('--shade-feature-a'));
});
