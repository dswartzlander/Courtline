const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
const dir='Web';
const source=fs.readFileSync(dir+'/telestrator.js','utf8');
function run(viewer){
 const handlers={},windowHandlers={},frames=[],nodes={};
 const element=()=>({events:{},attributes:{},hidden:false,addEventListener(name,fn){this.events[name]=fn;},setAttribute(name,value){this.attributes[name]=value;},focus(){this.focused=true;},getBoundingClientRect(){return {x:0,y:0,width:800,height:600};}});
 const dialog={open:false,addEventListener(){},close(){this.open=false},showModal(){this.open=true}};
 ['courtsTab','statsTab','telestratorTab','courtAlertCount','telestratorViewport','telestratorStatus','assignmentAlert','openTelestratorSettings','closeTelestratorSettings','reloadTelestrator'].forEach(id=>nodes[id]=element());
 nodes.telestratorSettingsDialog=dialog;
 nodes.assignmentAlert.hidden=true;
 nodes.statsCourtTitle={textContent:''};nodes.statsTournamentTitle={textContent:''};
 for(let i=1;i<=4;i++){
  nodes['statsCourtTab'+i]=element();nodes['statsCourt'+i]={hidden:i!==1,dataset:{statsTournament:'Tournament '+i}};
 }
 const body={dataset:{},classList:{contains:name=>name==='display-mode'||(name==='companion-viewer'&&viewer)}};
 const doc={body,getElementById:id=>nodes[id],querySelector:()=>null,addEventListener(name,fn){handlers[name]=fn;}};
 const win={innerWidth:1200,dispatchEvent(){},CourtlineNative:{telestrator:frame=>frames.push(frame)},addEventListener(name,fn){(windowHandlers[name]??=[]).push(fn);}};
 const context={document:doc,window:win,ResizeObserver:class{observe(){}},MutationObserver:class{observe(){}},requestAnimationFrame:fn=>fn(),Event:class{constructor(name){this.type=name}}};
 vm.runInNewContext(source,context);
 handlers.DOMContentLoaded();
 // The role is determined after the native-to-Helper handshake.
 assert.equal(body.dataset.liveTab,'courts');
 windowHandlers['courtline-ready'].forEach(fn=>fn());
 assert.equal(body.dataset.liveTab,viewer?'stats':'courts');
 assert.equal(nodes.courtsTab.hidden,viewer);
 assert.equal(nodes.courtsTab.attributes['aria-selected'],viewer?'false':'true');
 if(viewer){
  nodes.statsTab.events.keydown({key:'ArrowRight',preventDefault(){}});
  assert.equal(body.dataset.liveTab,'telestrator');
  assert.equal(nodes.telestratorTab.focused,true);
  nodes.telestratorTab.events.keydown({key:'ArrowRight',preventDefault(){}});
  assert.equal(body.dataset.liveTab,'stats');
  nodes.statsTab.events.keydown({key:'Home',preventDefault(){}});
  assert.equal(body.dataset.liveTab,'stats');
  nodes.courtsTab.events.click(); // Even a programmatic click cannot expose Courts.
  assert.equal(body.dataset.liveTab,'stats');
  nodes.statsCourtTab3.events.click();
  assert.equal(nodes.statsCourtTitle.textContent,'Court 03 Stats');
  assert.equal(nodes.statsTournamentTitle.textContent,'Tournament 3');
  assert.equal(nodes.statsCourt3.hidden,false);
 }else{
  nodes.courtsTab.events.keydown({key:'ArrowRight',preventDefault(){}});
  assert.equal(body.dataset.liveTab,'stats');
  nodes.statsTab.events.keydown({key:'ArrowRight',preventDefault(){}});
  assert.equal(body.dataset.liveTab,'telestrator');
  nodes.telestratorTab.events.keydown({key:'ArrowRight',preventDefault(){}});
  assert.equal(body.dataset.liveTab,'courts');
 }
}
run(false);run(true);
const html=fs.readFileSync(dir+'/index.html','utf8');
const css=fs.readFileSync(dir+'/desktop.css','utf8');
assert(html.indexOf('id="courtsTab"')<html.indexOf('id="statsTab"'));
assert(html.indexOf('id="statsTab"')<html.indexOf('id="telestratorTab"'));
assert.equal((html.match(/class="stats-score-values"/g)||[]).length,4);
assert(css.includes('grid-template-columns:minmax(2.5ch,1fr) 1ch minmax(2.5ch,1fr)'));
assert(css.includes('body.companion-viewer #courtsTab{display:none!important}'));
console.log('PASS: Main & Companion tab order, Companion Stats default, keyboard focus, court tournament switching, score geometry');
