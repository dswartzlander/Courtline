const fs=require('fs'),vm=require('vm'),assert=require('assert');const nodes=[];
class N{
 constructor(tag){this.tagName=tag.toUpperCase();this.children=[];this.dataset={};this.events={};this.attrs={};this.value='';nodes.push(this);}
 get firstChild(){return this;}
 append(...items){this.children.push(...items);}replaceChildren(...items){this.children=items;}
 setAttribute(k,v){this.attrs[k]=v;}addEventListener(k,v){this.events[k]=v;}
 showModal(){this.open=true;}close(){this.open=false;this.events.close?.();}remove(){}
}
(async()=>{
const window={addEventListener(){},dispatchEvent(){}},body=new N('body');
const ctx={window,document:{body,createElement:tag=>new N(tag)},URLSearchParams,Event:class{},console};vm.createContext(ctx);
vm.runInContext(fs.readFileSync('Web/vmix-shortcuts.js','utf8'),ctx);window.pywebview={api:{shortcut_catalog:async()=>window.VmixShortcutCatalog.categories}};
vm.runInContext(fs.readFileSync('Web/desktop.js','utf8'),ctx);
const target={value:''};await ctx.chooseShortcut(target);assert(body.children[0].open);assert(!nodes.some(n=>n.tagName==='SELECT'));
const cats=nodes.find(n=>n.className==='shortcut-category-list'),functions=nodes.find(n=>n.className==='shortcut-function-list');
await cats.children.find(n=>n.textContent==='Input').events.click();assert(functions.children.some(n=>n.textContent==='LayerOn'));
await functions.children.find(n=>n.textContent==='LayerOff').events.click();assert.equal(functions.children.find(n=>n.textContent==='LayerOff').attrs['aria-pressed'],'true');
nodes.find(n=>n.placeholder==='Input name, number, or key').value='Composite';
nodes.find(n=>n.tagName==='LABEL'&&n.textContent==='Layer number (starting at 1)').children[0].value='2';
await nodes.find(n=>n.tagName==='BUTTON'&&n.textContent==='Use shortcut').events.click();assert.equal(new URLSearchParams(target.value).get('Function'),'LayerOff');assert.equal(new URLSearchParams(target.value).get('Value'),'2');assert(!body.children[0].open);
await ctx.chooseShortcut({value:''});const search=nodes.filter(n=>n.type==='search').at(-1);search.value='no-such-function';search.events.input();assert(nodes.filter(n=>n.tagName==='BUTTON'&&n.textContent==='Use shortcut').at(-1).disabled);
console.log('PASS: no native select popups, inline category filtering/function selection, LayerOff parameters, empty search');
})().catch(e=>{console.error(e);process.exitCode=1});
