const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
class Node {
  constructor(tag){this.tag=tag;this.children=[];this.events={};this.dataset={};this.textContent='';this.scrollHeight=1000;this.clientHeight=300;this.scrollTop=0;}
  append(...nodes){this.children.push(...nodes);}
  addEventListener(name,fn){this.events[name]=fn;}
  setAttribute(name,value){this[name]=value;}
  focus(){this.focused=true;}
}
(async()=>{
const body=new Node('body'),signals=[];
const ctx={console,Event:class{constructor(type){this.type=type;}},document:{body,createElement:tag=>new Node(tag)},window:{addEventListener(){},dispatchEvent:e=>signals.push(e.type)}};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('Web/desktop.js','utf8'),ctx);
vm.runInContext("latestState=[{logs:[{simple:'Round complete',advanced:'Round complete: details'}]}]",ctx);
const live=new Node('section'),card=new Node('article'),panel=ctx.buildActivityLog(live,0,card),dialog=card.children[0];
assert.equal(body.children.length,0);assert.equal(dialog.hidden,true);assert.equal(dialog.role,'region');
assert.equal(live.children[0].textContent,'View Activity Log');
await live.children[0].events.click();
assert.equal(dialog.hidden,false);assert.equal(panel.pre.textContent,'Round complete');assert.equal(signals.length,0);assert.equal(live.children[0]['aria-expanded'],'true');
panel.pre.scrollTop=140;
ctx.renderActivityLog(panel,{logs:[{simple:'New activity'}]});assert.equal(panel.pre.scrollTop,140);
panel.pre.scrollTop=700;
ctx.renderActivityLog(panel,{logs:[{simple:'Latest activity'}]});assert.equal(panel.pre.scrollTop,1000);
panel.advanced.checked=true;panel.advanced.events.change();assert.equal(panel.pre.textContent,'Round complete: details');
const otherLive=new Node('section'),otherCard=new Node('article');
ctx.buildActivityLog(otherLive,1,otherCard);await otherLive.children[0].events.click();
assert.equal(otherCard.children[0].hidden,false);assert.equal(dialog.hidden,false);
await dialog.children[0].children[1].events.click();
assert.equal(dialog.hidden,true);assert.equal(live.children[0].focused,true);assert.equal(live.children[0]['aria-expanded'],'false');
assert.equal(otherCard.children[0].hidden,false);assert.equal(signals.length,0);
await live.children[0].events.click();
dialog.events.keydown({key:'Escape',preventDefault(){},stopPropagation(){}});assert.equal(dialog.hidden,true);
ctx.renderActivityLog(panel,{logs:[]});assert.equal(panel.pre.textContent,'No activity yet.');
console.log('PASS: court-local log isolation, independent courts, immediate population, advanced details, scroll retention/follow, empty log, close/Escape/focus, no native browser hide signal');
})().catch(e=>{console.error(e);process.exit(1)});
