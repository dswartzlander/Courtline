'use strict';
const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict'),path=require('node:path');
const root=path.resolve(__dirname,'..');
(async()=>{
  const fixture=await import(path.resolve(root,'Tests/companion-session.fixture.mjs'));
  const shared=fixture.createCompanionSession();
  const code=fs.readFileSync(path.resolve(root,'Web/companion.js'),'utf8');
  let switches=[],instances=[];
  class E{constructor(){this.children=[];this.attributes={};this.classList={add(){},toggle(){}};this.textContent='';}append(...a){this.children.push(...a);}insertBefore(a){this.children.push(a);}querySelector(){return null;}setAttribute(k,v){this.attributes[k]=v;}addEventListener(){}}
  function device(role,id){
    let reloads=0;const elements=new Map();for(const k of ['telestratorPanel','telestratorSettingsContents','telestratorSettingsControls','telestratorCommandStatus',...Array.from({length:4},(_,i)=>'telestratorCourt'+i)])elements.set(k,new E());
    const store=new Map();const callbacks=[];
    const api={companion:async (_url,action,payload)=>{
      if(action==='session')return {role};
      if(action==='getLive')return {snapshot:null,stale:false};
      if(action==='publishLive')return {accepted:true};
      if(action==='telestrator')return shared.control(payload,role);
      throw Error('Unknown '+action);
    },telestrator_switch:async court=>{switches.push(court);return 'OK';}};
    const document={hidden:false,body:{classList:{add(){},toggle(){}}},getElementById:k=>elements.get(k),createElement:()=>new E()};
    const window={pywebview:{api},CourtlineDeviceName:role,courtlineReloadTelestrator:()=>reloads++,desktopValidateVmixAddress(){},desktopFlushUI:async()=>{},courtlineGoLive:()=>{}};
    vm.runInNewContext(code,{window,document,localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)},crypto:{randomUUID:()=>id},confirm:()=>true,setInterval:fn=>callbacks.push(fn)});
    const result={window,api,callbacks,get reloads(){return reloads},async ready(){await window.CourtlineCompanion.identify('http://helper/api/stats?key=x');window.CourtlineCompanion.begin();await new Promise(setImmediate);await callbacks[0]();},async poll(){await callbacks[0]();await new Promise(setImmediate);}};
    instances.push(result);return result;
  }
  const main=device('main','aaaaaaa1-aaaa-aaaa-aaaa-aaaaaaaaaaaa'),holder=device('viewer','bbbbbbb1-bbbb-bbbb-bbbb-bbbbbbbbbbbb'),observer=device('viewer','ccccccc1-cccc-cccc-cccc-cccccccccccc');
  await Promise.all(instances.map(i=>i.ready()));
  await main.window.CourtlineCompanion.selectCourt(0);
  assert.deepEqual(switches,[0]);
  assert.equal(main.reloads,1,'main refreshes after vMix confirmation');
  await Promise.all([holder.poll(),observer.poll()]);
  assert.equal(holder.reloads,1);assert.equal(observer.reloads,1);
  await Promise.all(instances.map(i=>i.poll()));
  assert.deepEqual(instances.map(i=>i.reloads),[1,1,1],'heartbeats must not repeatedly reload');
  await holder.api.companion('','telestrator',{action:'acquire',deviceId:holder.window.CourtlineCompanion.deviceId,name:'Coach'});
  await holder.poll();
  await holder.window.CourtlineCompanion.selectCourt(2);
  assert.equal(holder.reloads,1,'pending court selection does not refresh');
  assert.equal(observer.reloads,1);
  await main.poll(); // authoritative Main executes vMix and confirms
  assert.deepEqual(switches,[0,2]);
  assert.equal(main.reloads,2);
  await holder.poll();await observer.poll();
  assert.equal(holder.reloads,2);assert.equal(observer.reloads,2);
  // Confirmation for failed switch must not reload any browser.
  main.api.telestrator_switch=async()=>{throw Error('vMix down');};
  await holder.window.CourtlineCompanion.selectCourt(3);
  await main.poll();await holder.poll();await observer.poll();
  assert.deepEqual(instances.map(i=>i.reloads),[2,2,2],'vMix failure must not refresh');
  console.log('PASS '+root+': confirmed court reloads on Main/controller/viewer once; pending/failed/repeated polls do not reload');
})().catch(e=>{console.error(e);process.exitCode=1;});
