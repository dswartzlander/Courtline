const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const window={},sent=[];
const ctx={window,URL,URLSearchParams,crypto:crypto.webcrypto,Date,JSON,performance:{now:()=>0},setInterval(){},setTimeout:()=>1,clearTimeout(){},document:{addEventListener(){}},CourtlineNative:{load:()=>'{}',save:()=>true,open(){},request:(id,url)=>{sent.push(url);queueMicrotask(()=>window.platformReply(id,{status:200,text:'<vmix/>'},null));}}};
vm.createContext(ctx);vm.runInContext(fs.readFileSync('Web/vmix-shortcuts.js','utf8'),ctx);vm.runInContext(fs.readFileSync('Web/engine.js','utf8'),ctx);
(async()=>{
 const catalog=await window.pywebview.api.shortcut_catalog();assert(Object.values(catalog).flat().length>700);assert(catalog.Input.includes('LayerOn'));assert(catalog.Input.includes('LayerOff'));assert(catalog.Replay.length>50);
 for(const name of ['LayerOn','LayerOff']){
  const command=window.buildVmixShortcut(name,{parameters:{Input:'Telestrator Composite',Value:'2'}});
  await window.pywebview.api.send_command(0,command,'http://192.168.1.240:8088');
  const query=new URL(sent.at(-1)).searchParams;assert.equal(query.get('Function'),name);assert.equal(query.get('Input'),'Telestrator Composite');assert.equal(query.get('Value'),'2');
 }
 for(const value of ['','0','-1','1.5'])assert.throws(()=>window.buildVmixShortcut('LayerOn',{parameters:{Input:'10',Value:value}}));
 assert.throws(()=>window.buildVmixShortcut('LayerOff',{parameters:{Value:'1'}}));
 assert.throws(()=>window.buildVmixShortcut('LayerOn',{parameters:{Input:'10',Value:'1'},extra:'Function=Cut'}));
 assert.throws(()=>window.buildVmixShortcut('Cut',{parameters:{Input:'10'},extra:'input=11'}));
 const cut=new URLSearchParams(window.buildVmixShortcut('Cut',{parameters:{Input:'Camera & Score',Mix:'1'},extra:'Duration=500'}));
 assert.equal(cut.get('Input'),'Camera & Score');assert.equal(cut.get('Mix'),'1');assert.equal(cut.get('Duration'),'500');
 console.log('PASS: expanded categorized catalog, LayerOn/LayerOff API commands, input encoding/layer index validation, duplicate prevention, existing Input/Mix/extra parameters');
})().catch(e=>{console.error(e);process.exitCode=1;});
