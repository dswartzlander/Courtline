const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const ctx={window:{},URL};vm.runInNewContext(fs.readFileSync('Web/vmix-address.js','utf8'),ctx);
const {split,combine}=ctx.window.VmixAddress;
for(const [original,host,port] of [
 ['http://192.168.1.240:8088','192.168.1.240','8088'],
 ['https://vmix.example:8443','vmix.example','8443'],
 ['http://vmix.example','vmix.example','80'],
 ['https://vmix.example','vmix.example','443'],
 ['http://[fd00::1]:8088','[fd00::1]','8088']
]){
 const parts=split(original);assert.equal(parts.host,host);assert.equal(parts.port,port);
 assert.equal(combine(parts.host,parts.port,parts.protocol),new URL(original).origin);
}
assert.equal(combine(' 192.168.1.240 ','8088'),'http://192.168.1.240:8088');
assert.equal(combine('https://vmix.example','8443'),'https://vmix.example:8443');
assert.equal(combine('192.168.1.240','8090'),'http://192.168.1.240:8090');
for(const port of ['','0','65536','-1','8.5','abc','1e3'])assert.throws(()=>combine('192.168.1.240',port));
for(const host of ['','ftp://vmix.example','http://user:pass@vmix.example','192.168.1.240/api/','vmix.example?x=1','vmix.example#x','http://vmix.example:8088'])assert.throws(()=>combine(host,'8088'));
console.log('PASS: saved-address migration, custom/default ports, HTTPS, IPv6, changed port, and invalid input rejection');
