'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const css=fs.readFileSync('Web/courtline-themes.css','utf8');
const code=fs.readFileSync('Web/desktop.js','utf8');
for(const theme of ['blue','orange','purple','white']){
 assert(css.includes(`:root[data-courtline-theme="${theme}"] body:not(.display-mode) .court-card .automation-controls button.monitor-state-selected:disabled`),`${theme}: selected Stop disabled should use theme accent`);
}
for(const theme of ['blue','orange','purple']){
 assert(css.includes(`:root[data-courtline-theme="${theme}"] body:not(.display-mode) .court-card .automation-controls button:disabled`),`${theme}: disabled button needs theme tint`);
}
assert(css.includes('box-shadow:inset 0 0 0 2px var(--accent)'), 'active-theme outline for selected stopped state');
assert(code.includes("b.classList.toggle('monitor-state-selected',selected)"), 'preserve monitor state indication');
assert(code.includes('buttons.stop.disabled='), 'preserve Stop disabled interlock');
assert(!css.includes(':root[data-courtline-theme="teal"] body:not(.display-mode) .court-card .automation-controls button:disabled'), 'leave Original Teal untouched');
console.log('PASS themed disabled Pause and selected Stop without changing monitor state behavior');
