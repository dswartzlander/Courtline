import Foundation
import UIKit
import WebKit
import UniformTypeIdentifiers

private final class WeakBridge: NSObject, WKScriptMessageHandler {
    weak var owner: CourtlineViewController?
    init(_ owner: CourtlineViewController) { self.owner = owner }
    func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
        owner?.receive(message)
    }
}

private final class NoRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

final class CourtlineViewController: UIViewController, WKNavigationDelegate, WKUIDelegate, UIDocumentPickerDelegate {
    private var settingsImportReply: String?
    private var ui: WKWebView!
    private var telestrator: WKWebView!
    private var telestratorURL: URL?
    private var companionVmixURL: URL?
    private var viewerMode = UserDefaults.standard.bool(forKey: "courtline.ipad.viewerMode.v1")
    private var telestratorLeaseEpoch = 0
    private var courts: [WKWebView] = []
    private var urls = Array(repeating: "", count: 4)
    private var loaded = Array(repeating: false, count: 4)
    private var epochs = Array(repeating: 0, count: 4)
    private var webRoot: URL!
    private var foreground = true
    private var needsReminder = false
    private var closed = false
    private var uiGeneration = 0
    private let settingsKey = "courtline.ipadtest.config.v1"
    private let noRedirects = NoRedirects()
    private lazy var session: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 12
        config.timeoutIntervalForResource = 20
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.httpCookieStorage = nil
        config.urlCache = nil
        config.waitsForConnectivity = false
        return URLSession(configuration: config, delegate: noRedirects, delegateQueue: nil)
    }()

    private func bridgeBootstrap(_ saved: String) -> String {
        return """
        (() => {
          let settings = \(json(saved));
          const send = (method, args) => window.webkit.messageHandlers.courtline.postMessage({method, args});
          window.CourtlineNative = {
            load: () => settings,
            save: value => { JSON.parse(value); send('save', [value]); settings = value; return true; },
            open: (slot, url) => send('open', [slot, url]),
            telestrator: frame => send('telestrator', [frame]),
            scanStatsHelper: id => send('scanStatsHelper', [id]),
            switchCompanion: (id, code) => send('switchCompanion', [id, code]),
            statsHelper: (id, url, refresh) => send('statsHelper', [id, url, refresh]),
            statsAssignments: (id, url, assignments) => send('statsAssignments', [id, url, assignments]),
            settingsLock: (id, url, value) => send('settingsLock', [id, url, value]),
            companion: (id, url, action, payload) => send('companion', [id, url, action, payload]),
            exportSettings: (id, text) => send('exportSettings', [id, text]),
            importSettings: id => send('importSettings', [id]),
            persistSettings: (id, text) => send('persistSettings', [text, id]),
            snapshot: (id, slot) => send('snapshot', [id, slot]),
            request: (id, url, method, body, type) => send('request', [id, url, method, body, type]),
            checkUpdates: id => send('checkUpdates', [id]),
            downloadUpdate: (id, url, name) => send('downloadUpdate', [id, url, name])
          };
          if (!crypto.randomUUID) crypto.randomUUID = () => {
            const bytes = crypto.getRandomValues(new Uint8Array(16));
            bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
            const h = Array.from(bytes, b => b.toString(16).padStart(2,'0')).join('');
            return h.slice(0,8)+'-'+h.slice(8,12)+'-'+h.slice(12,16)+'-'+h.slice(16,20)+'-'+h.slice(20);
          };
        })();
        """
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        let root: URL
        do {
            root = try CourtlineResources.install()
        } catch {
            let label = UILabel(frame: view.bounds)
            label.text = "Courtline could not prepare its interface: " + error.localizedDescription
            label.textColor = .white
            label.numberOfLines = 0
            label.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            view.addSubview(label)
            return
        }
        webRoot = root.standardizedFileURL
        for _ in 0..<4 {
            let config = WKWebViewConfiguration()
            config.websiteDataStore = .default()
            let court = WKWebView(frame: CGRect(x: -1600, y: 0, width: 1280, height: 720), configuration: config)
            court.navigationDelegate = self
            court.isUserInteractionEnabled = false
            view.addSubview(court)
            courts.append(court)
        }
        let config = WKWebViewConfiguration()
        let content = WKUserContentController()
        content.add(WeakBridge(self), name: "courtline")
        let bootstrap = bridgeBootstrap(UserDefaults.standard.string(forKey: settingsKey) ?? "{}")
        content.addUserScript(WKUserScript(source: bootstrap, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        config.userContentController = content
        ui = WKWebView(frame: .zero, configuration: config)
        ui.navigationDelegate = self
        ui.uiDelegate = self
        ui.isOpaque = false
        ui.backgroundColor = .black
        ui.scrollView.backgroundColor = .black
        ui.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(ui)
        NSLayoutConstraint.activate([
            ui.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            ui.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            ui.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            ui.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        let browserConfig = WKWebViewConfiguration()
        browserConfig.allowsInlineMediaPlayback = true
        browserConfig.mediaTypesRequiringUserActionForPlayback = []
        telestrator = WKWebView(frame: .zero, configuration: browserConfig)
        telestrator.navigationDelegate = self
        telestrator.uiDelegate = self
        telestrator.isHidden = true
        telestrator.isOpaque = false
        telestrator.backgroundColor = .black
        telestrator.scrollView.bounces = false
        telestrator.accessibilityLabel = "vMix telestrator"
        let savedConfig = UserDefaults.standard.string(forKey: settingsKey) ?? "{}"
        let settings = (try? JSONSerialization.jsonObject(with: Data(savedConfig.utf8))) as? [String: Any]
        let savedUI = settings?["ui"] as? [String: Any]
        let helper = savedUI?["scoreholioStats"] as? [String: Any]
        telestrator.isUserInteractionEnabled = !viewerMode && (helper?["helperURL"] as? String ?? "").isEmpty
        view.addSubview(telestrator)
        ui.loadFileURL(root.appendingPathComponent("index.html"), allowingReadAccessTo: root)
        NotificationCenter.default.addObserver(self, selector: #selector(leaving), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(returning), name: UIApplication.didBecomeActiveNotification, object: nil)
        UIApplication.shared.isIdleTimerDisabled = true
    }

    @objc private func leaving() {
        guard !closed, ui != nil else { return }
        foreground = false
        needsReminder = true
        // Stop native reads immediately, even if WebKit suspends before JS runs.
        for i in courts.indices { loaded[i] = false; epochs[i] += 1; courts[i].stopLoading() }
        ui.evaluateJavaScript("window.platformSuspend&&window.platformSuspend();window.dispatchEvent(new Event('courtline-monitoring-stopped'))", completionHandler: nil)
        UIApplication.shared.isIdleTimerDisabled = false
    }

    @objc private func returning() {
        guard !closed, ui != nil else { return }
        foreground = true
        UIApplication.shared.isIdleTimerDisabled = true
        guard needsReminder else { return }
        needsReminder = false
        // Repeat the stop on return to cover JS suspended before the previous call.
        ui.evaluateJavaScript("window.platformSuspend&&window.platformSuspend();window.dispatchEvent(new Event('courtline-monitoring-stopped'))", completionHandler: nil)
        let alert = UIAlertController(title: "Restart monitoring", message: "Leaving Courtline stops match-alert monitoring. Press Start on each court you want to monitor. Scores can still update while monitoring is stopped. Missed events are not replayed.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        if presentedViewController == nil { present(alert, animated: true) }
    }

    func shutdown() {
        guard !closed else { return }
        leaving()
        closed = true
        session.invalidateAndCancel()
        statsHelperSession.invalidateAndCancel()
        NotificationCenter.default.removeObserver(self)
        ui?.configuration.userContentController.removeScriptMessageHandler(forName: "courtline")
        for court in courts { court.stopLoading(); court.navigationDelegate = nil }
        telestrator?.stopLoading()
        telestrator?.navigationDelegate = nil
        telestrator?.uiDelegate = nil
        ui?.stopLoading()
        UIApplication.shared.isIdleTimerDisabled = false
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        guard let id = settingsImportReply else { return }
        settingsImportReply = nil
        reply(id, value: NSNull())
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let id = settingsImportReply else { return }
        settingsImportReply = nil
        guard let url = urls.first else { reply(id, error: "No file selected."); return }
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            guard let size = attributes[.size] as? NSNumber, size.intValue <= 900_000 else {
                reply(id, error: "Settings file is too large."); return
            }
            let data = try Data(contentsOf: url)
            guard data.count <= 900_000, let text = String(data: data, encoding: .utf8) else {
                reply(id, error: "Settings file must be UTF-8 JSON."); return
            }
            controller.dismiss(animated: true) { [weak self] in self?.reply(id, value: text) }
        } catch { reply(id, error: error.localizedDescription) }
    }

    private func json(_ value: Any) -> String {
        guard let bytes = try? JSONSerialization.data(withJSONObject: value, options: [.fragmentsAllowed]),
              let string = String(data: bytes, encoding: .utf8) else { return "null" }
        return string
    }

    private func reply(_ id: String, value: Any? = nil, error: String? = nil) {
        guard !closed, ui != nil else { return }
        let code = "window.platformReply&&window.platformReply(\(json(id)),\(json(value ?? NSNull())),\(json(error as Any? ?? NSNull())))"
        ui.evaluateJavaScript(code, completionHandler: nil)
    }

    private func allowedOverlay(_ url: URL) -> Bool {
        url.scheme == "https" && url.host == "app.scoreholio.com" && url.user == nil && url.password == nil
    }

    private func trustedUI(_ url: URL?) -> Bool {
        guard let url = url, let root = webRoot, url.isFileURL else { return false }
        return url.standardizedFileURL.path.hasPrefix(root.path + "/")
    }

    func receive(_ message: WKScriptMessage) {
        guard !closed, message.webView === ui, message.frameInfo.isMainFrame,
              trustedUI(message.frameInfo.request.url),
              let body = message.body as? [String: Any],
              let method = body["method"] as? String,
              let args = body["args"] as? [Any] else { return }
        switch method {
        case "scanStatsHelper":
            guard let id = args.first as? String else { return }
            guard foreground, presentedViewController == nil else { reply(id, error: "Close the current dialog first."); return }
            let scanner = HelperQRScanner()
            scanner.result = { [weak self] text, error in
                if let error = error { self?.reply(id, error: error) }
                else { self?.reply(id, value: text as Any? ?? NSNull()) }
            }
            let navigation = UINavigationController(rootViewController: scanner)
            navigation.isModalInPresentation = true
            present(navigation, animated: true)
        case "switchCompanion":
            switchCompanion(args)
        case "statsHelper":
            statsHelperRequest(args)
        case "settingsLock":
            statsHelperRequest(args, settingsLock: true)
        case "statsAssignments":
            statsHelperRequest(args, assignments: true)
        case "companion":
            companionRequest(args)
        case "exportSettings":
            guard args.count == 2, let id = args[0] as? String, let text = args[1] as? String else { return }
            guard foreground, presentedViewController == nil, text.utf8.count <= 900_000,
                  let data = text.data(using: .utf8),
                  (try? JSONSerialization.jsonObject(with: data)) is [String: Any] else {
                reply(id, error: "Cannot export settings right now."); return
            }
            do {
                let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let file = directory.appendingPathComponent("Courtline-Settings.json")
                try data.write(to: file, options: .atomic)
                let sheet = UIActivityViewController(activityItems: [file], applicationActivities: nil)
                sheet.popoverPresentationController?.sourceView = view
                sheet.popoverPresentationController?.sourceRect = CGRect(x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
                sheet.completionWithItemsHandler = { [weak self] _, completed, _, error in
                    defer { try? FileManager.default.removeItem(at: directory) }
                    if let error = error { self?.reply(id, error: error.localizedDescription) }
                    else { self?.reply(id, value: ["completed": completed]) }
                }
                present(sheet, animated: true)
            } catch { reply(id, error: error.localizedDescription) }
        case "importSettings":
            guard let id = args.first as? String else { return }
            guard foreground, presentedViewController == nil, settingsImportReply == nil else {
                reply(id, error: "Close the current dialog before importing settings."); return
            }
            settingsImportReply = id
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.json], asCopy: true)
            picker.delegate = self
            picker.allowsMultipleSelection = false
            present(picker, animated: true)
        case "save", "persistSettings":
            if viewerMode {
                if args.count > 1, let id = args[1] as? String { reply(id, error: "Companion mode cannot change CourtLine settings.") }
                return
            }
            guard let text = args.first as? String, text.utf8.count < 1_000_000,
                  let data = text.data(using: .utf8),
                  (try? JSONSerialization.jsonObject(with: data)) is [String: Any] else {
                if args.count > 1, let id = args[1] as? String { reply(id, error: "Invalid or oversized settings.") }
                return
            }
            UserDefaults.standard.set(text, forKey: settingsKey)
            // Keep future reloads seeded from the latest saved/imported configuration.
            let content = ui.configuration.userContentController
            content.removeAllUserScripts()
            content.addUserScript(WKUserScript(source: bridgeBootstrap(text), injectionTime: .atDocumentStart, forMainFrameOnly: true))
            if args.count > 1, let id = args[1] as? String { reply(id, value: true) }
            if !telestrator.isHidden { loadTelestrator() }
        case "open":
            guard args.count == 2, let i = args[0] as? Int, courts.indices.contains(i),
                  let text = args[1] as? String else { return }
            guard text.isEmpty || (URL(string: text).map(allowedOverlay) == true) else { return }
            urls[i] = text; loaded[i] = false; epochs[i] += 1
            courts[i].stopLoading()
            if text.isEmpty { courts[i].loadHTMLString("", baseURL: nil) }
            else if foreground, let url = URL(string: text) { courts[i].load(URLRequest(url: url)) }
        case "snapshot":
            guard args.count == 2, let id = args[0] as? String,
                  let i = args[1] as? Int, courts.indices.contains(i) else { return }
            guard foreground, loaded[i] else { reply(id, error: "Waiting for Scoreholio overlay"); return }
            let expected = urls[i], epoch = epochs[i]
            courts[i].evaluateJavaScript("document.body ? document.body.innerText : ''") { [weak self] value, error in
                guard let self = self else { return }
                guard self.foreground, self.urls[i] == expected, self.epochs[i] == epoch else {
                    self.reply(id, error: "Court assignment or monitoring state changed"); return
                }
                if let error = error { self.reply(id, error: error.localizedDescription) }
                else { self.reply(id, value: ["url": expected, "text": value as? String ?? ""]) }
            }
        case "telestrator":
            guard let frame = args.first as? [String: Any],
                  let visible = frame["visible"] as? Bool else { return }
            telestrator.isHidden = !visible
            guard visible else { return }
            guard let x = frame["x"] as? Double, let y = frame["y"] as? Double,
                  let width = frame["width"] as? Double, let height = frame["height"] as? Double,
                  let viewportWidth = frame["viewportWidth"] as? Double,
                  [x, y, width, height, viewportWidth].allSatisfy({ $0.isFinite }),
                  width > 0, height > 0, viewportWidth > 0 else { telestrator.isHidden = true; return }
            let scale = ui.bounds.width / CGFloat(viewportWidth)
            let rect = CGRect(x: CGFloat(x) * scale, y: CGFloat(y) * scale,
                              width: CGFloat(width) * scale, height: CGFloat(height) * scale)
            telestrator.frame = ui.convert(rect.intersection(ui.bounds), to: view)
            loadTelestrator(reload: frame["reload"] as? Bool == true)
        case "request": request(args)
        case "checkUpdates": checkCourtLineUpdates(args)
        case "downloadUpdate": openCourtLineUpdate(args)
        default: break
        }
    }

    private lazy var statsHelperSession: URLSession = {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 600
        config.timeoutIntervalForResource = 620
        config.httpCookieStorage = nil
        config.urlCache = nil
        return URLSession(configuration: config, delegate: noRedirects, delegateQueue: nil)
    }()

    // This is the only settings change permitted while in Viewer mode: it
    // verifies a new Helper QR key online before saving the new pairing/role.
    // Invalid or canceled scans leave the previous pairing and role unchanged.
    private func switchCompanion(_ args: [Any]) {
        guard args.count == 2, let id = args[0] as? String,
              let code = args[1] as? String, code.utf8.count <= 20000,
              foreground else { return }
        guard var parts = URLComponents(string: code),
              ["http", "https"].contains(parts.scheme?.lowercased() ?? ""),
              let host = parts.host, !host.isEmpty,
              !["localhost", "127.0.0.1", "::1", "[::1]"].contains(host.lowercased()),
              parts.user == nil, parts.password == nil, parts.fragment == nil,
              parts.path == "/api/stats",
              parts.queryItems?.filter({ $0.name == "key" && $0.value?.count == 48 }).count == 1,
              let statsURL = parts.url else {
            reply(id, error: "Scan a Main or Companion QR code from the Windows Helper."); return
        }
        parts.path = "/api/session"
        guard let sessionURL = parts.url else { reply(id, error: "Invalid Helper address."); return }
        var request = URLRequest(url: sessionURL, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 12)
        request.httpMethod = "GET"
        let generation = uiGeneration
        statsHelperSession.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self = self, generation == self.uiGeneration, self.foreground else { return }
                if let error = error { self.reply(id, error: "Helper connection: " + error.localizedDescription); return }
                guard let response = response as? HTTPURLResponse, let data = data, data.count <= 500000,
                      let value = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else {
                    self.reply(id, error: "The Helper returned an invalid pairing response."); return
                }
                guard response.statusCode == 200,
                      let role = value["role"] as? String, ["main", "viewer"].contains(role) else {
                    self.reply(id, error: value["error"] as? String ?? "The Helper rejected this QR code."); return
                }
                let saved = UserDefaults.standard.string(forKey: self.settingsKey) ?? "{}"
                var configuration = (try? JSONSerialization.jsonObject(with: Data(saved.utf8))) as? [String: Any] ?? [:]
                var uiSettings = configuration["ui"] as? [String: Any] ?? [:]
                var stats = uiSettings["scoreholioStats"] as? [String: Any] ?? [:]
                stats["helperURL"] = statsURL.absoluteString
                if stats["auto"] == nil { stats["auto"] = true }
                if stats["seconds"] == nil { stats["seconds"] = 10 }
                uiSettings["scoreholioStats"] = stats
                configuration["ui"] = uiSettings
                guard let bytes = try? JSONSerialization.data(withJSONObject: configuration),
                      bytes.count < 1_000_000, let text = String(data: bytes, encoding: .utf8) else {
                    self.reply(id, error: "Could not save the new Helper pairing."); return
                }
                UserDefaults.standard.set(text, forKey: self.settingsKey)
                // WKUserScript is created when the controller starts. Refresh
                // its saved snapshot before the UI reloads into the new role.
                let content = self.ui.configuration.userContentController
                content.removeAllUserScripts()
                content.addUserScript(WKUserScript(source: self.bridgeBootstrap(text), injectionTime: .atDocumentStart, forMainFrameOnly: true))
                self.viewerMode = role == "viewer"
                UserDefaults.standard.set(self.viewerMode, forKey: "courtline.ipad.viewerMode.v1")
                self.companionVmixURL = nil
                self.telestrator.isUserInteractionEnabled = false
                self.telestratorLeaseEpoch += 1
                self.reply(id, value: ["url": statsURL.absoluteString, "role": role])
            }
        }.resume()
    }

    private func companionRequest(_ args: [Any]) {
        guard args.count == 4, let id = args[0] as? String,
              let source = args[1] as? String, let action = args[2] as? String,
              let payload = args[3] as? [String: Any], foreground else { return }
        let saved = UserDefaults.standard.string(forKey: settingsKey) ?? "{}"
        let dictionary = (try? JSONSerialization.jsonObject(with: Data(saved.utf8))) as? [String: Any]
        let config = dictionary?["ui"] as? [String: Any]
        let stats = config?["scoreholioStats"] as? [String: Any]
        guard stats?["helperURL"] as? String == source,
              var parts = URLComponents(string: source), ["http", "https"].contains(parts.scheme ?? ""),
              let host = parts.host, !host.isEmpty,
              !["localhost", "127.0.0.1", "::1", "[::1]"].contains(host.lowercased()),
              parts.user == nil, parts.password == nil, parts.fragment == nil,
              parts.path == "/api/stats", parts.queryItems?.contains(where: { $0.name == "key" && $0.value?.count == 48 }) == true else {
            reply(id, error: "Connect to the Windows Helper first."); return
        }
        let routes: [String: (String, String)] = [
            "session": ("GET", "/api/session"),
            "getLive": ("GET", "/api/live"),
            "publishLive": ("POST", "/api/live"),
            "telestrator": ("POST", "/api/telestrator")
        ]
        guard let route = routes[action] else { reply(id, error: "Invalid companion operation."); return }
        if viewerMode && action == "publishLive" { reply(id, error: "Read-only companions cannot publish match data."); return }
        parts.path = route.1
        guard let url = parts.url else { reply(id, error: "Invalid helper endpoint."); return }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 12)
        request.httpMethod = route.0
        if route.0 == "POST" {
            guard let data = try? JSONSerialization.data(withJSONObject: payload), data.count < 140000 else {
                reply(id, error: "Companion data is too large."); return
            }
            request.httpBody = data
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        let generation = uiGeneration
        statsHelperSession.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self = self, generation == self.uiGeneration, self.foreground else { return }
                if let error = error { self.reply(id, error: "Helper connection: " + error.localizedDescription); return }
                guard let data = data, data.count <= 500000, let response = response as? HTTPURLResponse,
                      let value = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else {
                    self.reply(id, error: "Invalid companion response."); return
                }
                guard response.statusCode == 200 else { self.reply(id, error: value["error"] as? String ?? "Companion request denied."); return }
                if action == "session", let role = value["role"] as? String, ["main", "viewer"].contains(role) {
                    self.viewerMode = role == "viewer"
                    UserDefaults.standard.set(self.viewerMode, forKey: "courtline.ipad.viewerMode.v1")
                    self.telestrator.isUserInteractionEnabled = false
                    self.telestratorLeaseEpoch += 1
                }
                if action == "getLive", self.viewerMode,
                   let snapshot = value["snapshot"] as? [String: Any],
                   let address = snapshot["vmixAddress"] as? String,
                   let remote = URL(string: address), ["http", "https"].contains(remote.scheme ?? ""),
                   remote.host != nil, remote.user == nil, remote.password == nil {
                    if self.companionVmixURL != remote { self.companionVmixURL = remote; if !self.telestrator.isHidden { self.loadTelestrator() } }
                }
                if action == "telestrator" {
                    // Do not trust a JavaScript drawing permission. Enable touch only
                    // from the authenticated Helper's current unexpired lease.
                    let canDraw = value["canDraw"] as? Bool == true
                    self.telestrator.isUserInteractionEnabled = canDraw
                    self.telestratorLeaseEpoch += 1
                    let epoch = self.telestratorLeaseEpoch
                    let expiry = (value["holder"] as? [String: Any])?["expiresAt"] as? Double ?? 0
                    let delay = max(0, min(15, expiry / 1000 - Date().timeIntervalSince1970))
                    DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                        guard let self = self, self.telestratorLeaseEpoch == epoch else { return }
                        self.telestrator.isUserInteractionEnabled = false
                    }
                }
                self.reply(id, value: value)
            }
        }.resume()
    }

    private func statsHelperRequest(_ args: [Any], assignments: Bool = false, settingsLock: Bool = false) {
        guard args.count == 3, let id = args[0] as? String, let text = args[1] as? String else { return }
        let refresh: Bool
        if assignments || settingsLock { refresh = false }
        else { guard let flag = args[2] as? Bool else { return }; refresh = flag }
        guard foreground else { reply(id, error: "Courtline must be open to refresh stats."); return }
        let saved = UserDefaults.standard.string(forKey: settingsKey) ?? "{}"
        let dictionary = (try? JSONSerialization.jsonObject(with: Data(saved.utf8))) as? [String: Any]
        let uiConfig = dictionary?["ui"] as? [String: Any]
        let stats = uiConfig?["scoreholioStats"] as? [String: Any]
        guard let configured = stats?["helperURL"] as? String, URL(string: configured) == URL(string: text),
              var parts = URLComponents(string: text), ["http", "https"].contains(parts.scheme ?? ""),
              let host = parts.host, !host.isEmpty, !["localhost", "127.0.0.1", "::1", "[::1]"].contains(host.lowercased()),
              parts.user == nil, parts.password == nil, parts.fragment == nil, parts.path == "/api/stats",
              let key = parts.queryItems?.first(where: { $0.name == "key" })?.value, !key.isEmpty else {
            reply(id, error: "Save the helper address copied from the vMix PC dashboard first."); return
        }
        parts.path = settingsLock ? "/api/settings-lock" : assignments ? "/api/assignments" : (refresh ? "/api/refresh" : "/api/stats")
        guard let url = parts.url else { reply(id, error: "Invalid helper address."); return }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 600)
        request.httpMethod = (refresh || assignments || settingsLock) ? "POST" : "GET"
        if settingsLock {
            guard let value = args[2] as? [String: String], ["policy", "verify", "watch"].contains(value["action"] ?? ""),
                  let body = try? JSONSerialization.data(withJSONObject: value), body.count < 200 else {
                reply(id, error: "Invalid Settings PIN request."); return
            }
            request.httpBody = body
            request.timeoutInterval = 25
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        if assignments {
            guard let rows = args[2] as? [[String: Any]], rows.count <= 4,
                  let body = try? JSONSerialization.data(withJSONObject: ["assignments": rows]), body.count < 20000 else {
                reply(id, error: "Invalid court assignments."); return
            }
            request.httpBody = body
            request.timeoutInterval = 15
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let generation = uiGeneration
        statsHelperSession.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self = self, generation == self.uiGeneration else { return }
                guard self.foreground else { self.reply(id, error: "Stats request stopped after leaving the app."); return }
                if let error = error { self.reply(id, error: "Cannot reach stats helper: " + error.localizedDescription); return }
                guard let data = data, data.count <= 4_000_000, let response = response as? HTTPURLResponse,
                      let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else {
                    self.reply(id, error: "The helper returned an invalid stats response."); return
                }
                guard response.statusCode == 200 else {
                    self.reply(id, error: object["error"] as? String ?? "Stats helper request failed."); return
                }
                self.reply(id, value: object)
            }
        }.resume()
    }

    // Public GitHub Releases API only. Not routed through the vMix/Helper request bridge.
    private func checkCourtLineUpdates(_ args: [Any]) {
        guard let id = args.first as? String else { return }
        guard foreground, let url = URL(string: "https://api.github.com/repos/dswartzlander/Courtline/releases?per_page=50") else {
            reply(id, error: "CourtLine must be open to check for updates."); return
        }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        request.setValue("CourtLine-Updater", forHTTPHeaderField: "User-Agent")
        let generation = uiGeneration
        session.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self = self, self.uiGeneration == generation else { return }
                if let error = error { self.reply(id, error: error.localizedDescription); return }
                guard let response = response as? HTTPURLResponse, let data = data, data.count <= 1_000_000 else {
                    self.reply(id, error: "GitHub update response was too large or invalid."); return
                }
                self.reply(id, value: ["status": response.statusCode, "text": String(decoding: data, as: UTF8.self)])
            }
        }.resume()
    }

    private func openCourtLineUpdate(_ args: [Any]) {
        guard args.count == 3, let id = args[0] as? String,
              let address = args[1] as? String, let name = args[2] as? String,
              name.range(of: #"^Courtline-iPad-v[0-9]+\.[0-9]+(?:\.[0-9]+)?(?:-[A-Za-z0-9-]+)?\.zip$"#, options: .regularExpression) != nil,
              let url = URL(string: address), url.scheme == "https", url.host == "github.com",
              url.user == nil, url.password == nil, url.query == nil, url.fragment == nil,
              url.path.hasPrefix("/dswartzlander/Courtline/releases/download/"),
              url.lastPathComponent == name else {
            if let id = args.first as? String { reply(id, error: "Not an official CourtLine iPad ZIP release.") }
            return
        }
        UIApplication.shared.open(url, options: [:]) { [weak self] opened in
            self?.reply(id, value: opened, error: opened ? nil : "Could not open Safari to download this project.")
        }
    }

    private func request(_ args: [Any]) {
        guard args.count == 5, let id = args[0] as? String, let address = args[1] as? String,
              let method = args[2] as? String, let body = args[3] as? String,
              let type = args[4] as? String else { return }
        guard foreground else { reply(id, error: "Courtline is not in the foreground; request canceled."); return }
        guard let url = URL(string: address), let host = url.host, url.user == nil, url.password == nil,
              ["https", "http"].contains(url.scheme ?? ""), ["GET", "POST"].contains(method) else {
            reply(id, error: "Invalid request"); return
        }
        let score = url.scheme == "https" && (
            (host == "firestore.googleapis.com" && url.path.hasPrefix("/v1/projects/scoreholio/databases/(default)/documents/")) ||
            (host == "us-central1-scoreholio.cloudfunctions.net" && url.path == "/misc/app-get-remote-mode"))
        // Match the dashboard's configured vMix host, never an arbitrary bridge target.
        let saved = UserDefaults.standard.string(forKey: settingsKey) ?? "{}"
        let dictionary = (try? JSONSerialization.jsonObject(with: Data(saved.utf8))) as? [String: Any]
        let uiConfig = dictionary?["ui"] as? [String: Any]
        let configuredAddress = (uiConfig?["vmixHost"] as? String ?? "http://192.168.1.100:8088")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let vmixBase = URL(string: configuredAddress)
        // URL.path may remove a trailing slash. Check the URL's actual encoded
        // path, accepting both API forms, without relaxing the host restriction.
        let apiPath = URLComponents(url: url, resolvingAgainstBaseURL: false)?.percentEncodedPath ?? ""
        let isAPI = method == "GET" && ["/api", "/api/"].contains(apiPath)
        let sameHost = url.scheme?.lowercased() == vmixBase?.scheme?.lowercased() &&
            host.lowercased() == vmixBase?.host?.lowercased() &&
            effectivePort(url) == (vmixBase.map { effectivePort($0) } ?? -1)
        let vmix = isAPI && sameHost
        if viewerMode && vmix { reply(id, error: "Read-only companions cannot send vMix commands."); return }
        guard score || vmix else {
            reply(id, error: isAPI ? "vMix address differs from saved Settings. Re-enter the PC address and test again." : "Unsupported API request path: " + apiPath)
            return
        }
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 12)
        request.httpMethod = method
        request.setValue(score ? "application/json" : "application/xml", forHTTPHeaderField: "Accept")
        if method == "POST" {
            request.httpBody = Data(body.utf8)
            request.setValue(type.isEmpty ? "application/json" : type, forHTTPHeaderField: "Content-Type")
        }
        let generation = uiGeneration
        session.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self = self, self.uiGeneration == generation else { return }
                if let error = error {
                    self.reply(id, error: error.localizedDescription + " — check Local Network permission and the vMix PC address.")
                    return
                }
                guard let response = response as? HTTPURLResponse, let data = data, data.count <= 8_000_000 else {
                    self.reply(id, error: "Missing or oversized response"); return
                }
                self.reply(id, value: ["status": response.statusCode, "text": String(decoding: data, as: UTF8.self)])
            }
        }.resume()
    }

    // The remote browser has no Courtline bridge. Its address is derived only
    // from the same saved vMix setting used by the API connection.
    private func configuredTelestratorURL() -> URL? {
        let saved = UserDefaults.standard.string(forKey: settingsKey) ?? "{}"
        let dictionary = (try? JSONSerialization.jsonObject(with: Data(saved.utf8))) as? [String: Any]
        let config = dictionary?["ui"] as? [String: Any]
        let address: String = (viewerMode ? companionVmixURL?.absoluteString : (config?["vmixHost"] as? String)) ?? "http://192.168.1.100:8088"
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard var parts = URLComponents(string: address),
              ["http", "https"].contains(parts.scheme?.lowercased() ?? ""),
              let host = parts.host, !host.isEmpty,
              parts.user == nil, parts.password == nil, parts.query == nil, parts.fragment == nil else { return nil }
        parts.path = "/telestrator/"
        return parts.url
    }

    private func telestratorStatus(_ text: String) {
        ui.evaluateJavaScript("window.telestratorStatus&&window.telestratorStatus(\(json(text)))", completionHandler: nil)
    }

    private func loadTelestrator(reload: Bool = false) {
        guard let url = configuredTelestratorURL() else {
            telestratorURL = nil
            telestrator.stopLoading()
            telestrator.loadHTMLString("", baseURL: nil)
            telestratorStatus("Enter a valid vMix address in Settings.")
            return
        }
        guard reload || telestratorURL != url else { return }
        telestratorURL = url
        telestratorStatus("Loading " + url.absoluteString)
        telestrator.load(URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20))
    }

    private func allowedTelestrator(_ url: URL) -> Bool {
        guard let base = telestratorURL else { return url.absoluteString == "about:blank" }
        return url.scheme?.lowercased() == base.scheme?.lowercased() &&
            url.host?.lowercased() == base.host?.lowercased() &&
            effectivePort(url) == effectivePort(base) && url.user == nil && url.password == nil
    }

    private func effectivePort(_ url: URL) -> Int {
        url.port ?? (url.scheme?.lowercased() == "https" ? 443 : 80)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if webView === ui { decisionHandler(trustedUI(url) ? .allow : .cancel) }
        else if webView === telestrator {
            let allowed = allowedTelestrator(url)
            if !allowed, navigationAction.targetFrame?.isMainFrame != false {
                telestratorStatus("Blocked navigation outside saved vMix address: " + url.absoluteString)
            }
            decisionHandler(allowed ? .allow : .cancel)
        }
        else { decisionHandler(allowedOverlay(url) || url.absoluteString == "about:blank" ? .allow : .cancel) }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse,
                 decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        if webView === telestrator, navigationResponse.isForMainFrame,
           let response = navigationResponse.response as? HTTPURLResponse,
           response.statusCode >= 400 {
            telestratorStatus("HTTP " + String(response.statusCode) + " · " + (response.url?.absoluteString ?? "") + " · Check the address, then Reload.")
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if webView === telestrator, webView.url?.host != nil { telestratorStatus("Page loaded · " + (webView.url?.absoluteString ?? "")) }
        if let i = courts.firstIndex(where: { $0 === webView }) {
            loaded[i] = foreground && webView.url?.absoluteString == urls[i]
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        if webView === ui { uiGeneration += 1 }
        else if let i = courts.firstIndex(where: { $0 === webView }) { loaded[i] = false }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        if webView === telestrator, (error as NSError).code != NSURLErrorCancelled {
            let failure = error as NSError
            telestratorStatus((telestratorURL?.absoluteString ?? "Telestrator") + " · " + failure.domain + " " + String(failure.code) + ": " + error.localizedDescription + " · Check Courtline Local Network permission, then Reload.")
        }
        if let i = courts.firstIndex(where: { $0 === webView }) { loaded[i] = false }
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        self.webView(webView, didFail: navigation, withError: error)
    }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        if webView === ui {
            leaving()
            uiGeneration += 1
            let alert = UIAlertController(title: "Restart the test app", message: "iPadOS stopped Courtline's web view. Stop the app in Swift Playground, then press Run again. Monitoring is stopped.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            if presentedViewController == nil { present(alert, animated: true) }
        } else if webView === telestrator {
            telestratorStatus("Telestrator browser stopped. Tap Reload to reconnect.")
        } else if let i = courts.firstIndex(where: { $0 === webView }) { loaded[i] = false }
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        guard (webView === ui || webView === telestrator), foreground, presentedViewController == nil else { completionHandler(); return }
        let alert = UIAlertController(title: "Courtline", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        guard (webView === ui || webView === telestrator), foreground, presentedViewController == nil else { completionHandler(false); return }
        let alert = UIAlertController(title: "Courtline", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        present(alert, animated: true)
    }
    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String,
                 defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) {
        guard (webView === ui || webView === telestrator), foreground, presentedViewController == nil else { completionHandler(nil); return }
        let alert = UIAlertController(title: "Courtline", message: prompt, preferredStyle: .alert)
        alert.addTextField { $0.text = defaultText }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(nil) })
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(alert.textFields?.first?.text) })
        present(alert, animated: true)
    }
}
