# CourtLine iPad v0.86 — Monitoring Button Theme Consistency

Fix the last teal selected-state outline on the **Stop** button under Blue, Orange, Purple, and White Light themes. Dark-theme disabled Pause and Stop buttons now use muted versions of their selected palette instead of fixed blue-gray fills. Preserve the stopped/disabled button state and button behavior. Original Teal unchanged. No changes to courts, stats, telestrator, networking, or vMix controls.

Regenerate embedded `CourtlineResources.swift` from `Web` before running in Swift Playgrounds.
