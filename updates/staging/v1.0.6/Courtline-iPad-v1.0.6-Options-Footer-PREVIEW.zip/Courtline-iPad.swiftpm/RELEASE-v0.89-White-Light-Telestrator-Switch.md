# CourtLine iPad v0.89 — White Light contrast and Telestrator court switching

- White Light: dark readable Automation / Telestrator Settings labels, neutral Auto-refresh toggle; Settings title has no panel background.
- Selecting a court in Telestrator consistently runs the same court-switch path for both paired and unpaired Main.
- With Output 2 configured, court selection first sets Output 2, then runs enabled Telestrator shortcut rows if their Dry run is off.
- With Output 2 empty, enabled live shortcuts work by themselves. Test LIVE continues to bypass Dry run, but normal court switching respects it.
- Court switching ignores legacy shortcut delays for a prompt shared-court change.
- No changes to automatic Round-complete or Match-complete monitoring triggers.
- Use iPad Swift Playgrounds. Test with vMix connected to the same LAN.
