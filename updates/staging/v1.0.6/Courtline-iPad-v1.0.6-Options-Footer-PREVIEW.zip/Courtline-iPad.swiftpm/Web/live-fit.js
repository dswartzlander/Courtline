'use strict';

// Keep the original card elements and their event handlers inside a fitted canvas.
function installLiveFit() {
  const cards = [...document.querySelectorAll('.court-card')];
  let frame;
  const schedule = () => {
    if (!frame) frame = requestAnimationFrame(fit);
  };
  function fit() {
    frame = null;
    const live = document.body.classList.contains('display-mode');
    for (const card of cards) {
      const canvas = card.querySelector('.court-fit-content');
      canvas.style.transform = '';
      canvas.style.minHeight = '';
      canvas.style.left = '';
      canvas.style.width = '';
      canvas.style.removeProperty('--live-type');
      if (!live || !card.clientHeight || !card.clientWidth) continue;
      const height = card.clientHeight;
      const width = card.clientWidth;
      const top=canvas.querySelector('.court-card-top');
      const bottom=canvas.querySelector('.court-card-bottom');
      const available=Math.max(80,height-(top?.offsetHeight||0)-(bottom?.offsetHeight||0));
      const type=Math.max(14,Math.min(52,width/18,available/5.5));
      canvas.style.setProperty('--live-type',type+'px');
      // Compensate the layout width before scaling so all section backgrounds
      // still span the card. Reflow text at each candidate size, without distortion.
      const fits = scale => {
        canvas.style.width = `${width / scale}px`;
        return canvas.scrollHeight * scale <= height && canvas.scrollWidth * scale <= width + 1;
      };
      let scale = 1;
      if (!fits(1)) {
        let low = Math.min(1, height / Math.max(1, canvas.scrollHeight), width / Math.max(1, canvas.scrollWidth)) * 0.99;
        while (!fits(low) && low > 0.0001) low /= 2;
        let high = 1;
        for (let i = 0; i < 14; i++) {
          const mid = (low + high) / 2;
          if (fits(mid)) low = mid;
          else high = mid;
        }
        scale = low;
      }
      canvas.style.width = `${width / scale}px`;
      canvas.style.transform = `scale(${scale})`;
      canvas.style.left = '0';
      canvas.style.minHeight = `${height / scale}px`;
    }
  }
  const resize = new ResizeObserver(schedule);
  for (const card of cards) {
    const canvas = document.createElement('div');
    canvas.className = 'court-fit-content';
    canvas.append(...[...card.childNodes].filter(node => !node.classList?.contains('automation-alarms') && !node.classList?.contains('activity-log-dialog')));
    card.append(canvas);
    resize.observe(card);
    new MutationObserver(records => {
      if (records.some(r => r.target !== canvas)) schedule();
    }).observe(canvas, {subtree:true, childList:true, characterData:true, attributes:true});
  }
  new MutationObserver(schedule).observe(document.body, {attributes:true, attributeFilter:['class']});
  document.addEventListener('toggle', schedule, true);
  window.addEventListener('resize', schedule);
  document.fonts?.ready.then(schedule);
  schedule();
}
document.addEventListener('DOMContentLoaded', installLiveFit);
