'use strict';
window.CourtlineBackup=(()=>{
  const object=value=>value&&typeof value==='object'&&!Array.isArray(value);
  const fail=message=>{throw new Error(message);};
  const string=(value,name)=>typeof value==='string'&&value.length<=20000?value:fail('Invalid '+name+'.');
  const bool=(value,name)=>typeof value==='boolean'?value:fail('Invalid '+name+'.');
  const number=(value,min,max,name)=>typeof value==='number'&&Number.isFinite(value)&&value>=min&&value<=max?value:fail('Invalid '+name+'.');
  const four=(value,name,read)=>Array.isArray(value)&&value.length===4?value.map(read):fail('Backup must contain four '+name+'.');
  function normalize(config){
    if(!object(config)||!object(config.ui))fail('Missing Courtline configuration.');
    const ui=config.ui;
    let host;try{host=new URL(ui.vmixHost);}catch(_){fail('Invalid saved vMix address.');}
    if(!['http:','https:'].includes(host.protocol)||host.username||host.password||host.search||host.hash||host.pathname!=='/'||['localhost','127.0.0.1','[::1]'].includes(host.hostname))fail('Invalid saved vMix address.');
    const urls=four(ui.urls,'court URLs',value=>{
      const text=string(value,'court URL');
      if(text){let url;try{url=new URL(text);}catch(_){fail('Invalid court URL.');}
        if(url.protocol!=='https:'||url.hostname!=='app.scoreholio.com'||url.username||url.password)fail('Court URLs must use Scoreholio HTTPS.');}
      return text;
    });
    const readProfile=p=>{
      if(!object(p)||!Array.isArray(p.rows)||p.rows.length>200)fail('Invalid automation rows.');
      const ids=new Set();
      return {dry_run:bool(p.dry_run,'Dry run'),poll_seconds:number(p.poll_seconds,.25,10,'poll interval'),alarm_delay:number(p.alarm_delay,0,60,'alarm delay'),rows:p.rows.map(r=>{
        if(!object(r))fail('Invalid shortcut row.');
        const id=string(r.id,'shortcut ID');if(!id||ids.has(id))fail('Missing or duplicate shortcut ID.');ids.add(id);
        if(!['Round complete','Match complete','Button press'].includes(r.trigger))fail('Unknown automation trigger.');
        const command=string(r.command,'shortcut command');
        if(command.trim()){
          const query=new URLSearchParams(/^Function=/i.test(command.trim())?command.trim():'Function='+command.trim());
          const functions=[...query].filter(([key])=>key.toLowerCase()==='function');
          if(functions.length!==1||!functions[0][1].trim())fail('Invalid shortcut function.');
        }
        return {id,enabled:bool(r.enabled,'shortcut enabled flag'),trigger:r.trigger,command,delay:number(r.delay,0,3600,'shortcut delay')};
      })};
    };
    const profiles=four(config.profiles,'automation profiles',readProfile);
    const telestrator_profiles=four(config.telestrator_profiles||Array.from({length:4},()=>({dry_run:true,poll_seconds:.5,alarm_delay:5,rows:[]})),'Telestrator profiles',readProfile);
    if(telestrator_profiles.some(p=>p.rows.some(r=>r.trigger!=='Button press')))fail('Invalid Telestrator button trigger.');
    const pairings=four(ui.pairings||[null,null,null,null],'court pairings',p=>{
      if(p===null)return null;
      if(!object(p))fail('Invalid court pairing.');
      return {account:string(p.account,'pairing account'),deviceId:string(p.deviceId,'pairing device')};
    });
    let scoreholioStats;
    if(ui.scoreholioStats){
      const value=ui.scoreholioStats;
      if(!object(value))fail('Invalid stats settings.');
      if(value.helperURL!==undefined){
        const helperURL=string(value.helperURL,'stats helper URL');
        if(helperURL){const u=new URL(helperURL);if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.hash||u.pathname!=='/api/stats'||!u.searchParams.get('key')||['localhost','127.0.0.1','[::1]'].includes(u.hostname))fail('Invalid stats helper URL.');}
        scoreholioStats={helperURL,auto:bool(value.auto,'stats auto refresh'),seconds:number(value.seconds,5,3600,'stats refresh interval')};
      } else { scoreholioStats={helperURL:'',auto:false,seconds:10}; }

    }
    return {browser:'',ui:{...(scoreholioStats?{scoreholioStats}:{}),urls,pairings,autoRefresh:bool(ui.autoRefresh,'auto refresh'),vmixHost:host.origin,vmixInputs:four(ui.vmixInputs,'vMix inputs',v=>string(v,'vMix input')),telestratorSources:four(ui.telestratorSources||['','','',''],'Telestrator camera sources',v=>string(v,'Telestrator camera source')),visibleCourts:four(ui.visibleCourts,'visibility flags',v=>bool(v,'court visibility'))},profiles,telestrator_profiles};
  }
  function make(config){return JSON.stringify({format:'courtline-settings',version:1,exportedAt:new Date().toISOString(),config:normalize(config)},null,2);}
  function parse(text){
    if(typeof text!=='string'||text.length>900000)fail('Settings file is too large.');
    let data;try{data=JSON.parse(text);}catch(_){fail('Settings file is not valid JSON.');}
    if(data?.format!=='courtline-settings'||data.version!==1)fail('Choose a supported Courtline settings export (version 1).');
    return normalize(data.config);
  }
  return {make,parse,normalize};
})();
