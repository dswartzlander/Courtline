'use strict';
window.CourtlineShortcutClipboard=(()=>{
  let copied=null;
  function copy(rows){
    if(!Array.isArray(rows)||!rows.length)throw Error('Add a shortcut before copying.');
    copied=rows.map(row=>({enabled:row.enabled!==false,trigger:row.trigger,command:String(row.command||''),delay:Number(row.delay)}));
    return copied.length;
  }
  function paste(fixedTrigger){
    if(!copied)throw Error('Copy a shortcut or shortcut list first.');
    return copied.map(row=>{
      if(!Number.isFinite(row.delay)||row.delay<0||row.delay>3600)throw Error('Copied shortcut delay must be between 0 and 3600 seconds.');
      return {...row,id:crypto.randomUUID(),trigger:fixedTrigger?'Button press':['Round complete','Match complete'].includes(row.trigger)?row.trigger:'Round complete'};
    });
  }
  return {copy,paste};
})();
