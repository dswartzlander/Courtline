'use strict';
const native = () => window.pywebview.api;
let desktopConfig, panels=[], latestState=[], assignmentSerial=Array.from({length:4},()=>Promise.resolve()), assignmentUrls=Array(4).fill(null);
let saveTimer, saveChain=Promise.resolve(), pendingUI;
window.desktopSaveUI = value => {
  pendingUI=value; clearTimeout(saveTimer);
  saveTimer=setTimeout(()=>flushUI(),250);
};
window.desktopFlushUI=()=>flushUI();
async function flushUI(){
  clearTimeout(saveTimer);
  if(pendingUI){const data=pendingUI;pendingUI=null; saveChain=saveChain.catch(()=>{}).then(()=>native().save_ui(data));}
  try{await saveChain;}catch(e){notice('Settings could not be saved: '+e.message);throw e;}
}
function notice(message){document.getElementById('desktopNotice').textContent=message;}
window.desktopAssignment=(i,url)=>{
  if(assignmentUrls[i]===url)return;
  assignmentUrls[i]=url;
  assignmentSerial[i]=assignmentSerial[i].catch(()=>{}).then(()=>native().set_assignment(i,url)).catch(e=>{assignmentUrls[i]=null;notice(e.message);});
};
window.desktopFetch=async(url,options={})=>{
  if(options.signal?.aborted)throw new DOMException('Aborted','AbortError');
  let body=options.body;
  let type=options.headers?.['Content-Type']||'';
  if(body instanceof URLSearchParams){body=body.toString();type='application/x-www-form-urlencoded';}
  const r=await native().fetch_scoreholio(String(url),options.method||'GET',body||null,type);
  if(options.signal?.aborted)throw new DOMException('Aborted','AbortError');
  return {ok:r.status>=200&&r.status<300,status:r.status,json:async()=>JSON.parse(r.text)};
};
function element(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n;}
function button(text,fn){const b=element('button','',text);b.type='button';b.addEventListener('click',async()=>{b.dataset.busy='true';b.disabled=true;try{await fn();}catch(e){notice(e.message);}finally{delete b.dataset.busy;b.disabled=false;b.syncState?.();}});return b;}
function input(type,value){const n=document.createElement('input');n.type=type;if(type==='checkbox')n.checked=value;else n.value=value;return n;}
function label(text,control){const l=element('label','',text);l.append(control);return l;}
function rowUI(i,row={},fixedTrigger=false){
  const box=element('div','shortcut-row');box.dataset.id=row.id||crypto.randomUUID();
  const enabled=input('checkbox',row.enabled!==false);enabled.dataset.field='enabled';const enabledLabel=label('Enabled',enabled);enabledLabel.className='shortcut-enabled';box.append(enabledLabel);
  const trigger=document.createElement('select');trigger.dataset.field='trigger';
  for(const t of (fixedTrigger?['Button press']:['Round complete','Match complete'])){const o=new Option(t,t);trigger.add(o);}trigger.value=fixedTrigger?'Button press':row.trigger||'Round complete';if(fixedTrigger){trigger.hidden=true;box.append(trigger);}else {const triggerLabel=label('Trigger',trigger);triggerLabel.className='shortcut-trigger';box.append(triggerLabel);}
  const command=input('text',row.command||'');command.dataset.field='command';command.placeholder='Function=Merge&Input=10&Mix=1';const commandLabel=label('vMix command',command);commandLabel.className='shortcut-command';box.append(commandLabel);
  const delay=input('number',row.delay??3);delay.min='0';delay.max='3600';delay.step='.1';delay.dataset.field='delay';const delayLabel=label('Delay (seconds)',delay);delayLabel.className='shortcut-delay';box.append(delayLabel);
  const actions=element('div','shortcut-actions');box.append(actions);
  actions.append(button('Select shortcut',()=>chooseShortcut(command)));
  actions.append(button('Test LIVE',async()=>{
    if(!command.value.trim())throw new Error('Enter a shortcut first.');
    if(!confirm('Send this command to vMix now? This bypasses Dry run and delays.'))return;
    window.desktopValidateVmixAddress?.();await flushUI();notice(await native().send_command(i,command.value,document.getElementById('vmixHost').value));
  }));
  actions.append(button('Copy shortcut',()=>{window.CourtlineShortcutClipboard.copy([collectRow(box)]);notice('Shortcut copied. Use Paste shortcuts in the destination court.');}));
  actions.append(button('Remove',()=>box.remove()));return box;
}
function collectRow(box){return {id:box.dataset.id,enabled:box.querySelector('[data-field=enabled]').checked,trigger:box.querySelector('[data-field=trigger]').value,command:box.querySelector('[data-field=command]').value,delay:Number(box.querySelector('[data-field=delay]').value)};}
function collectRows(rows){return [...rows.children].map(collectRow);}
function shortcutCopyControls(i,rows,fixedTrigger,feedback){
  const controls=element('div','shortcut-copy-controls');
  controls.append(button('Copy all shortcuts',()=>{
    const count=window.CourtlineShortcutClipboard.copy(collectRows(rows));feedback.textContent=count+' shortcuts copied. Paste them into the destination court.';notice(feedback.textContent);
  }),button('Paste shortcuts',()=>{
    const copied=window.CourtlineShortcutClipboard.paste(fixedTrigger);rows.append(...copied.map(row=>rowUI(i,row,fixedTrigger)));
    feedback.textContent=copied.length+' shortcuts pasted. Review commands, triggers and delays, then tap Apply.';feedback.dataset.state='draft';notice(feedback.textContent);
  }));return controls;
}
function collectProfile(i){const p=panels[i];return {dry_run:p.dry.checked,poll_seconds:Number(p.poll.value),alarm_delay:Number(p.delay.value),rows:collectRows(p.rows)};}
function collectTelestratorProfile(panel){return {dry_run:panel.dry.checked,poll_seconds:.5,alarm_delay:5,rows:collectRows(panel.rows)};}
function buildTelestratorSettings(card,i){
  const section=element('details','automation-settings telestrator-button-settings');
  const header=element('summary','automation-settings-header'),feedback=element('span','automation-save-feedback');feedback.setAttribute('role','status');
  const dry=input('checkbox',true),rows=element('div','shortcut-rows');
  const source=input('text',window.desktopGetTelestratorSource?.(i)||'');
  source.placeholder='vMix camera input name or number';source.maxLength=120;
  source.setAttribute('aria-label','Court '+(i+1)+' camera source for Telestrator Output 2');
  const sourceInline=label('Output 2',source);
  sourceInline.className='telestrator-source-inline';
  // A text field inside <summary> must not toggle the <details> while editing.
  sourceInline.addEventListener('click',event=>event.stopPropagation());
  sourceInline.addEventListener('keydown',event=>event.stopPropagation());
  header.append(element('h3','','TELESTRATOR BUTTON · COURT '+(i+1)),sourceInline,feedback);
  source.addEventListener('change',async()=>{
    try{window.desktopSetTelestratorSource(i,source.value);await flushUI();feedback.textContent='Output 2 source saved for Court '+(i+1)+'.';feedback.dataset.state='success';}
    catch(error){feedback.textContent=error.message;feedback.dataset.state='error';}
  });
  const panel={dry,rows,feedback};
  section.append(header,
    element('p','','The Output 2 field beside this heading selects the vMix camera/video input for this court—not its Scoreholio Browser input. It saves automatically when you leave the field. Selecting the court will set Output 2 to this input.'),
    shortcutCopyControls(i,rows,true,feedback),element('p','','Enabled Telestrator shortcuts below also run when you select this court, after setting Output 2 (if configured). Turn off Dry run and tap Apply to enable them. Court changes send shortcuts immediately, without a delay.'),label('Dry run for legacy Telestrator shortcuts',dry),rows,
    button('+ Add Telestrator shortcut',()=>rows.append(rowUI(i,{},true))),
    button('Apply Telestrator button settings',async()=>{
      feedback.textContent='Saving…';feedback.dataset.state='saving';
      try{window.desktopValidateVmixAddress?.();await flushUI();desktopConfig.telestrator_profiles[i]=await native().save_telestrator_profile(i,collectTelestratorProfile(panel));feedback.textContent='Telestrator button settings saved.';feedback.dataset.state='success';}
      catch(error){feedback.textContent=error.message;feedback.dataset.state='error';throw error;}
    }));
  const value=desktopConfig.telestrator_profiles[i];dry.checked=value.dry_run;rows.append(...value.rows.map(row=>rowUI(i,row,true)));
  card.querySelector('.court-card-bottom').append(section);return panel;
}
async function apply(i){
  const feedback=panels[i].saveFeedback;
  feedback.dataset.state='saving';feedback.textContent='Saving…';
  try{
    window.desktopValidateVmixAddress?.();
    await flushUI();
    desktopConfig.profiles[i]=await native().save_profile(i,collectProfile(i),document.getElementById('browserOverride').value);
    feedback.dataset.state='success';feedback.textContent='Automation settings saved.';
  }catch(error){
    feedback.dataset.state='error';feedback.textContent='Could not save: '+error.message;
    throw error;
  }
}
function fill(i,value){const p=panels[i];p.dry.checked=value.dry_run;p.poll.value=value.poll_seconds;p.delay.value=value.alarm_delay;p.rows.replaceChildren(...value.rows.filter(r=>r.trigger!=='Button press').map(r=>rowUI(i,r)));}
function buildDeviceSettings(card,i){
  const bottom=card.querySelector('.court-card-bottom'),vmix=bottom.querySelector('.vmix-card-controls');
  const group=element('details','automation-settings device-event-settings');
  const summary=element('summary','automation-settings-header');summary.append(element('h3','','DEVICE WIDGET & EVENT · COURT '+(i+1)));group.append(summary);
  group.append(...[...bottom.children].filter(node=>node!==vmix));
  const destination=element('div','vmix-card-controls device-vmix-settings');
  destination.append(vmix.querySelector('.vmix-card-heading'),vmix.querySelector('[data-vmix-input]'));group.append(destination);bottom.prepend(group);
}
function buildPanel(card,i){
  buildDeviceSettings(card,i);
  const live=element('section','automation-live');
  const status=element('div','automation-status','Automation stopped');
  const controls=element('div','automation-controls');
  const runControl=async action=>{await native().control(i,action);latestState=await native().state();syncMonitorButtons(monitorButtons,latestState[i]);};
  const monitorButtons={
    start:button('Start',async()=>{await apply(i);await assignmentSerial[i];await runControl('start');}),
    pause:button('Pause',()=>runControl(latestState[i]?.paused?'resume':'pause')),
    stop:button('Stop',()=>runControl('stop'))
  };
  Object.values(monitorButtons).forEach(b=>b.syncState=()=>syncMonitorButtons(monitorButtons,latestState[i]||{}));
  syncMonitorButtons(monitorButtons,{});
  controls.append(monitorButtons.start,monitorButtons.pause,monitorButtons.stop);
  const connectionGroup=element('div','automation-connection-group');
  connectionGroup.append(status,controls);
  card.querySelector('.vmix-card-actions').prepend(connectionGroup);
  const alarms=element('div','automation-alarms');alarms.dataset.courtOverlay=String(i);
  alarms.setAttribute('aria-label','Court '+(i+1)+' alerts');
  card.append(alarms);
  card.querySelector('.court-card-bottom').append(live);
  const settings=element('details','automation-settings');
  const settingsHeader=element('summary','automation-settings-header');
  const saveFeedback=element('span','automation-save-feedback');
  saveFeedback.setAttribute('role','status');saveFeedback.setAttribute('aria-live','polite');
  saveFeedback.setAttribute('aria-label','Court '+(i+1)+' automation save status');
  settingsHeader.append(element('h3','','AUTOMATION · COURT '+(i+1)),saveFeedback);settings.append(settingsHeader);
  const dry=input('checkbox',true),poll=input('number',.5),delay=input('number',5);poll.min='.25';poll.max='10';poll.step='.25';delay.min='0';delay.max='60';
  const options=element('div','automation-options');options.append(label('Dry run',dry),label('Poll seconds',poll),label('Match complete alert delay',delay));settings.append(options);
  const rows=element('div','shortcut-rows');settings.append(shortcutCopyControls(i,rows,false,saveFeedback),rows);
  settings.append(button('+ Add shortcut',()=>rows.append(rowUI(i))),button('Apply automation settings',()=>apply(i)));
  const {pre,advanced}=buildActivityLog(live,i,card);
  // Reuse the same live status node so send/copy handlers keep updating it.
  live.append(card.querySelector('[data-vmix-feedback]'));
  card.querySelector('.court-card-bottom').append(settings);const telestratorSettings=buildTelestratorSettings(card,i);panels.push({monitorButtons,telestratorSettings,status,alarms,dry,poll,delay,rows,pre,advanced,saveFeedback,alarmSignature:''});fill(i,desktopConfig.profiles[i]);
}
function renderActivityLog(panel,state,forceBottom=false){
  const pre=panel.pre;
  const text=(state?.logs||[]).map(x=>panel.advanced.checked?x.advanced:x.simple).filter(Boolean).join('\n')||'No activity yet.';
  const follow=forceBottom||pre.scrollHeight-pre.clientHeight-pre.scrollTop<32;
  const position=pre.scrollTop;
  if(pre.textContent!==text)pre.textContent=text;
  pre.scrollTop=follow?pre.scrollHeight:position;
}
function buildActivityLog(live,i,card){
  const dialog=element('section','activity-log-dialog');
  dialog.hidden=true;
  dialog.id='activityLog'+i;
  dialog.setAttribute('role','region');
  const heading=element('h2','','Court '+(i+1)+' · Activity Log');
  heading.id='activityLogTitle'+i;
  dialog.setAttribute('aria-labelledby',heading.id);
  const toolbar=element('div','activity-log-toolbar');
  const dismiss=()=>{
    dialog.hidden=true;
    open.setAttribute('aria-expanded','false');
    open.focus();
  };
  const close=button('Close',dismiss);
  toolbar.append(heading,close);
  const advanced=input('checkbox',false),pre=element('pre','activity-log-entries');
  pre.tabIndex=0;
  pre.setAttribute('aria-label','Court '+(i+1)+' activity entries');
  const panel={pre,advanced};
  advanced.addEventListener('change',()=>renderActivityLog(panel,latestState[i]));
  dialog.append(toolbar,label('Advanced details',advanced),pre);
  const open=button('View Activity Log',()=>{
    dialog.hidden=false;
    open.setAttribute('aria-expanded','true');
    renderActivityLog(panel,latestState[i],true);
    close.focus();
  });
  open.className='activity-log-trigger';
  open.setAttribute('aria-controls',dialog.id);
  open.setAttribute('aria-expanded','false');
  dialog.addEventListener('keydown',event=>{
    if(event.key==='Escape'){event.preventDefault();event.stopPropagation();dismiss();}
  });
  live.append(open);
  card.append(dialog);
  return panel;
}
async function chooseShortcut(target){
  const catalog=await native().shortcut_catalog(),dialog=element('dialog','shortcut-picker shortcut-picker-split');
  dialog.setAttribute('aria-label','Select vMix shortcut');
  const title=element('h2','','Select vMix shortcut'),search=input('search','');search.placeholder='Search function or category';search.setAttribute('aria-label','Search vMix functions');
  const layout=element('div','shortcut-split-layout');
  const categoryPane=element('section','shortcut-category-pane'),functionPane=element('section','shortcut-function-pane'),parameterPane=element('section','shortcut-parameter-pane');
  const categories=element('div','shortcut-category-list'),functions=element('div','shortcut-function-list');
  categories.setAttribute('role','group');categories.setAttribute('aria-label','Categories');functions.setAttribute('role','group');functions.setAttribute('aria-label','Functions');
  const count=element('p','shortcut-results'),hint=element('p','shortcut-parameter-hint'),selectionTitle=element('h3','','Function settings');
  const entries=Object.entries(catalog).flatMap(([category,functions])=>functions.map(name=>({category,name})));
  const controls={Input:input('text',''),Value:input('text',''),Mix:input('number',''),Duration:input('number','')};
  controls.Input.placeholder='Input name, number, or key';controls.Mix.min='0';controls.Duration.min='0';
  const labels=Object.fromEntries(Object.entries(controls).map(([key,control])=>[key,label(key,control)]));
  const extra=input('text','');extra.placeholder='Optional: Channel=1&SelectedName=Headline';
  const error=element('p','shortcut-picker-error');error.setAttribute('role','status');
  let selectedCategory='',selectedName='';
  const categoryButtons=[];
  function selected(){
    const parameters=window.VmixShortcutCatalog.parameters[selectedName]||[];
    Object.entries(labels).forEach(([key,node])=>{node.hidden=!parameters.includes(key);});
    const layer=['LayerOn','LayerOff','LayerOnOff'].includes(selectedName);
    controls.Value.type=layer?'number':'text';controls.Value.min=layer?'1':'';
    labels.Value.firstChild.textContent=layer?'Layer number (starting at 1)':'Value';
    selectionTitle.textContent=selectedName||'Choose a function';
    hint.textContent=!selectedName?'Select a category or search to find a function.':layer?'Input is the input containing the layer; Layer number selects the layer to show or hide.':'Parameters: '+(parameters.join(', ')||'none')+'. Additional parameters can be entered below.';
    error.textContent='';useButton.disabled=!selectedName;
    [...functions.children].forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.function===selectedName)));
  }
  function filter(){
    const matches=entries.filter(e=>(!selectedCategory||e.category===selectedCategory)&&(e.category+' '+e.name).toLowerCase().includes(search.value.trim().toLowerCase()));
    if(!matches.some(e=>e.name===selectedName))selectedName=matches[0]?.name||'';
    functions.replaceChildren(...matches.map(e=>{
      const item=button(e.name,()=>{selectedName=e.name;selected();});item.className='shortcut-function-option';item.dataset.function=e.name;item.title=e.category+' — '+e.name;return item;
    }));
    if(!matches.length)functions.append(element('p','shortcut-empty','No matching functions.'));
    count.textContent=matches.length+' of '+entries.length+' functions';functions.scrollTop=0;selected();
  }
  for(const name of ['',...Object.keys(catalog)]){
    const item=button(name||'All categories',()=>{selectedCategory=name;categoryButtons.forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.category===name)));filter();});
    item.className='shortcut-category-option';item.dataset.category=name;item.setAttribute('aria-pressed',String(name===''));categoryButtons.push(item);categories.append(item);
  }
  const useButton=button('Use shortcut',()=>{
    try{
      const parameters={};Object.entries(controls).forEach(([key,control])=>{if(!labels[key].hidden)parameters[key]=control.value;});
      target.value=window.buildVmixShortcut(selectedName,{parameters,extra:extra.value});dialog.close();
    }catch(e){error.textContent=e.message;}
  });
  useButton.syncState=()=>{useButton.disabled=!selectedName;};
  search.addEventListener('input',filter);
  categoryPane.append(element('h3','','Categories'),categories);functionPane.append(element('h3','','Functions'),count,functions);
  parameterPane.append(selectionTitle,hint,...Object.values(labels),label('Extra parameters',extra),error);
  layout.append(categoryPane,functionPane,parameterPane);
  const footer=element('div','shortcut-picker-footer');footer.append(useButton,button('Cancel',()=>dialog.close()));
  dialog.append(title,search,layout,footer);filter();
  dialog.addEventListener('close',()=>{dialog.remove();window.dispatchEvent(new Event('courtline-modal-change'));});
  document.body.append(dialog);dialog.showModal();window.dispatchEvent(new Event('courtline-modal-change'));
}
async function pollState(){
  try{
    latestState=await native().state();latestState.forEach((s,i)=>{const p=panels[i];
      syncMonitorButtons(p.monitorButtons,s);
      const telestratorButton=document.getElementById('telestratorCourt'+i);
      const companion=window.CourtlineCompanion,connected=!!companion?.url,viewer=companion?.role==='viewer';
      const automaticSource=window.desktopGetTelestratorSource?.(i)?.trim();
      telestratorButton.disabled=!!telestratorButton.dataset.busy||(viewer?(!companion.canSelectCourt):!!s.manual_busy||(!automaticSource&&!s.telestrator_count));
      telestratorButton.title=automaticSource?'Switch Output 2 to '+automaticSource+' for Court '+(i+1):connected?(viewer?'Request that the Main device show Court '+(i+1):'Switch the shared telestrator to Court '+(i+1)):
        s.telestrator_count?(s.telestrator_dry_run?'Dry run: ':'Live: ')+'run Court '+(i+1)+' Telestrator shortcuts':'Configure and apply Court '+(i+1)+' Telestrator button settings first.';
      const page=s.status.page,vmix=s.status.vmix;
      p.status.textContent=(s.paused?'PAUSED':s.running?'MONITORING':s.armed?(s.url?'MONITOR STOPPED — CHECK LOG':'WAITING FOR ASSIGNMENT'):'STOPPED')+' · '+(s.dry_run?'DRY RUN':'LIVE COMMANDS')+'\nScoreholio: '+(page?.state||'—')+' · vMix: '+(vmix?.state||'—')+(s.blocked?'\nACKNOWLEDGMENT REQUIRED':'');
      p.status.title=[page?.detail,vmix?.detail].filter(Boolean).join('\n');
      const signature=JSON.stringify(s.alarms);
      if(signature!==p.alarmSignature){p.alarmSignature=signature;p.alarms.replaceChildren(...s.alarms.map(a=>{const box=element('div','automation-alarm '+a.kind);box.setAttribute('role','alertdialog');box.append(element('strong','',a.title),element('p','',a.hint),button('Acknowledge',()=>native().acknowledge(i,a.id)));return box;}));}
      renderActivityLog(p,s);
    });
    window.updateCourtAlertCount?.(latestState.reduce((count,s)=>count+s.alarms.length,0));
  }catch(e){notice('Desktop status unavailable: '+e.message);}finally{setTimeout(pollState,500);}
}
window.addEventListener('pywebviewready',async()=>{
  try{
    desktopConfig=await native().get_config();
    const ui=desktopConfig.ui||{};ui.vmixHost ||= 'http://192.168.1.100:8088';
    localStorage.setItem('courtline-scoreholio-v2',JSON.stringify(ui));
    await window.CourtlineCompanion?.identify(ui.scoreholioStats?.helperURL||'');
    document.getElementById('browserOverride').value=desktopConfig.browser||'';
    window.dispatchEvent(new Event('courtline-ready'));
    // Settings uses independent columns, which changes DOM order to 1,3,2,4.
    // Always initialize native court profiles by the stable data-slot number.
    [...document.querySelectorAll('.court-card')].sort((a,b)=>Number(a.dataset.slot)-Number(b.dataset.slot)).forEach(buildPanel);
    panels.forEach((_,i)=>document.getElementById('telestratorCourt'+i).addEventListener('click',async event=>{
      const button=event.currentTarget,status=document.getElementById('telestratorCommandStatus');button.dataset.busy='true';button.disabled=true;
      // Only the court button pressed on THIS device updates its local Stats view.
      // A Stats court choice never calls the Telestrator switch, and shared updates do not call this.
      window.courtlineSelectLocalStatsCourt?.(i);
      try{
        const companion=window.CourtlineCompanion;
        if(companion?.url){
          const result=await companion.selectCourt(i);
          status.textContent=result.confirmed?'Shared telestrator now showing Court '+(i+1):'Court '+(i+1)+' requested — waiting for Main to switch vMix.';
        }else{
          window.desktopValidateVmixAddress?.();await flushUI();
          status.textContent='Court '+(i+1)+': '+await native().telestrator_switch(i);
          document.querySelectorAll('.telestrator-court-buttons button').forEach(candidate=>candidate.setAttribute('aria-pressed',String(candidate===button)));
          // Unpaired Main: vMix accepted the switch without a shared Helper revision.
          window.courtlineReloadTelestrator?.();
        }
      }
      catch(error){status.textContent='Court '+(i+1)+': '+error.message;}
      finally{delete button.dataset.busy;}
    }));
    const backupStatus=document.getElementById('settingsBackupStatus');
    document.getElementById('exportSettings').addEventListener('click',async()=>{
      try{
        backupStatus.textContent='Preparing settings…';
        window.desktopValidateVmixAddress?.();await flushUI();
        const config=await native().get_config();config.ui=window.desktopCollectUI();config.profiles=panels.map((_,i)=>collectProfile(i));config.telestrator_profiles=panels.map(p=>collectTelestratorProfile(p.telestratorSettings));
        const text=window.CourtlineBackup.make(config);
        const result=await native().export_settings(text);
        backupStatus.textContent=result?.completed?'Settings file shared or saved.':'Export dismissed.';
      }catch(error){backupStatus.textContent='Export failed: '+error.message;}
    });
    document.getElementById('importSettings').addEventListener('click',async()=>{
      try{
        backupStatus.textContent='Choose a Courtline settings file…';
        const text=await native().pick_settings();
        if(text===null){backupStatus.textContent='Import canceled.';return;}
        const restored=window.CourtlineBackup.parse(text);
        if(!confirm('Replace settings for all four courts with this backup? Monitoring and pending commands will stop.')){backupStatus.textContent='Import canceled.';return;}
        await flushUI();await native().restore_settings(restored);
        try{localStorage.setItem('courtline-scoreholio-v2',JSON.stringify(restored.ui));}catch(_){}
        location.reload();
      }catch(error){backupStatus.textContent='Import failed: '+error.message;}
    });
    document.querySelector('footer').lastElementChild.textContent=window.CourtlineCompanion?.role==='viewer'?'Courtline iPad v0.76 · Read-only companion':'Courtline iPad v0.76 · Main device';
    document.getElementById('importBridge').addEventListener('click',()=>document.getElementById('importBridgeFile').click());
    document.getElementById('importBridgeFile').addEventListener('change',async event=>{
      try{const file=event.target.files[0];if(!file)return;const old=JSON.parse(await file.text());const court=Number(prompt('Import into which Courtline court? Enter 1, 2, 3, or 4.'))-1;if(!Number.isInteger(court)||court<0||court>3)return;
        if(!Array.isArray(old.vmix_shortcuts))throw new Error('Select left_court.json, right_court.json, or a single-monitor settings.json containing shortcut rows.');
        const rows=old.vmix_shortcuts.map((command,j)=>({id:crypto.randomUUID(),command,enabled:old.vmix_shortcut_enabled?.[j]??true,delay:old.vmix_shortcut_delays?.[j]??3,trigger:old.vmix_action_triggers?.[j]||'Round complete'}));
        fill(court,{dry_run:true,poll_seconds:old.poll_seconds??.5,alarm_delay:old.match_complete_alarm_delay_seconds??5,rows});notice('Imported into Court '+(court+1)+' with Dry run ON. Review and Apply automation settings. Courtline supplies the widget URL.');
      }catch(e){notice('Import failed: '+e.message);}finally{event.target.value='';}
    });pollState();window.CourtlineCompanion?.begin();
  }catch(e){document.body.replaceChildren(element('p','','Courtline startup failed: '+e.message));}
});

window.addEventListener('courtline-monitoring-stopped',()=>{document.querySelectorAll('.automation-status').forEach(n=>n.textContent='STOPPED — RESTART MONITORING');});

function syncMonitorButtons(buttons,state){
  const active=!!(state.running||state.armed),paused=active&&!!state.paused;
  buttons.start.disabled=!!buttons.start.dataset.busy||active;
  buttons.pause.disabled=!!buttons.pause.dataset.busy||!state.running;
  buttons.stop.disabled=!!buttons.stop.dataset.busy||(!active&&!state.manual_busy);
  buttons.pause.textContent=paused?'Resume':'Pause';
  for(const [name,b] of Object.entries(buttons)){
    const selected=name==='start'?active&&!paused:name==='pause'?paused:!active;
    b.classList.toggle('monitor-state-selected',selected);
    b.setAttribute('aria-pressed',String(selected));
  }
}
function syncManualButton(button,state){
  button.disabled=!!button.dataset.busy||!!state.manual_busy||!state.manual_count;
  button.textContent=state.manual_busy?'Manual Commands Pending…':'Run Manual Commands';
  button.title=state.manual_count?'Run this court’s applied Button press shortcuts, honoring Dry run and delays.':'Add and apply an enabled Button press shortcut in this court’s automation settings.';
}
