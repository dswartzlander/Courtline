/* vNEXT: Stats court selection and manual Refresh are permanently visible.
   Intentionally no timer, capture-phase pointer handler, or tap suppression. */
'use strict';
window.addEventListener('DOMContentLoaded',()=>{
  const body=document.body;
  body.classList.remove('stats-controls-hidden');
  // Keep the toolbar visible even if the previous version left a stale class.
  const clearLegacyHidden=()=>{
    if(body.classList.contains('stats-controls-hidden')) body.classList.remove('stats-controls-hidden');
  };
  new MutationObserver(clearLegacyHidden).observe(body,{attributes:true,attributeFilter:['class']});
});
