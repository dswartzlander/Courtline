'use strict';
// The role badge is available from either Main or Companion Live view. A new
// pairing must be accepted by the PC Helper before native settings are changed.
(() => {
  const trigger=document.getElementById('liveIndicator');
  if(!trigger)return;
  const dialog=document.createElement('dialog');
  dialog.id='connectionSwitchDialog';dialog.className='connection-switch-dialog';
  dialog.setAttribute('aria-labelledby','connectionSwitchTitle');
  dialog.setAttribute('aria-describedby','connectionSwitchExplanation');
  dialog.innerHTML=`<div class="connection-switch-content">
    <div class="connection-switch-kicker">COURTLINE DEVICE ACCESS</div>
    <h2 id="connectionSwitchTitle">Switch Main / Companion</h2>
    <p class="connection-switch-current" id="connectionSwitchCurrent"></p>
    <p id="connectionSwitchExplanation">On your Windows Helper, choose the <strong>Main Device</strong> QR for full control or the <strong>Companion Viewer</strong> QR to view courts, telestrator and stats. Scan the matching code with this iPad.</p>
    <p class="connection-switch-warning">Changing away from Main stops this iPad from publishing court updates. Another Main must stay connected.</p>
    <p class="connection-switch-feedback" id="connectionSwitchFeedback" role="status" aria-live="polite">Your current access stays unchanged until the Helper verifies a new QR code.</p>
    <div class="connection-switch-actions">
      <button type="button" data-cancel>Cancel · Go Back</button>
      <button type="button" data-scan>Scan Helper QR Code</button>
    </div>
  </div>`;
  document.body.append(dialog);
  const current=dialog.querySelector('#connectionSwitchCurrent'),feedback=dialog.querySelector('#connectionSwitchFeedback');
  const cancel=dialog.querySelector('[data-cancel]'),scan=dialog.querySelector('[data-scan]');
  let busy=false,ready=false;
  const status=(message,error=false)=>{feedback.textContent=message;feedback.classList.toggle('is-error',error);};
  function dismiss(){if(busy)return;dialog.close();trigger.focus();}
  trigger.addEventListener('click',()=>{
    if(!ready||dialog.open)return;
    const companion=window.CourtlineCompanion;
    current.textContent='Current access: '+(companion?.url?(companion.role==='viewer'?'Companion Viewer':'Main Device'):'Not paired with a Helper');
    status('Your current access stays unchanged until the Helper verifies a new QR code.');
    dialog.showModal();cancel.focus();
  });
  cancel.addEventListener('click',dismiss);
  dialog.addEventListener('cancel',event=>{event.preventDefault();dismiss();});
  scan.addEventListener('click',async()=>{
    if(busy)return;
    busy=true;scan.disabled=true;cancel.disabled=true;
    status('Opening the camera. Scan a Main or Companion QR from Windows Helper…');
    try{
      await window.desktopFlushUI?.();
      const code=await window.pywebview.api.scan_stats_helper();
      if(code===null){status('Scan canceled. Your current access is unchanged.');return;}
      status('Checking the QR code with Windows Helper…');
      const pairing=await window.pywebview.api.switch_companion(code);
      if(!pairing||!['main','viewer'].includes(pairing.role)||typeof pairing.url!=='string')throw Error('The Helper did not confirm a device role.');
      // These values mirror a role verified by the native bridge, never a
      // user-selected role. The reload also clears live monitoring state.
      try{localStorage.setItem('courtline-companion-role-v1',JSON.stringify({role:pairing.role,url:pairing.url}));}catch(_){}
      dialog.close();location.reload();
    }catch(error){status('Could not switch access: '+(error?.message||error)+'. Your previous connection is unchanged.',true);}
    finally{busy=false;scan.disabled=false;cancel.disabled=false;}
  });
  window.addEventListener('courtline-ready',()=>{ready=true;trigger.disabled=false;});
  trigger.disabled=true;
})();
