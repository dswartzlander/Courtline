'use strict';
(()=>{
 const key='courtline-settings-lock-v1';let policy={enabled:false,revision:''},unlocked=false,ready=false,busy=false,continuation=null,dialog,pin,message;
 try{policy=JSON.parse(localStorage.getItem(key)||'null')||policy;}catch(_){}
 const isSettings=()=>!document.body.classList.contains('display-mode');
 const viewer=()=>window.CourtlineCompanion?.role==='viewer';
 function mask(){
  const locked=!viewer()&&policy.enabled===true&&!unlocked;document.body.classList.toggle('settings-locked',locked&&isSettings());
  const button=document.getElementById?.('viewSettings');if(!button)return;
  if(isSettings()){button.textContent='Back to Live';button.setAttribute('aria-label','Back to Live');return;}
  const state=locked?'locked':'unlocked',shackle=locked?'M8 10V6a4 4 0 0 1 8 0v4':'M8 10V6a4 4 0 0 1 7-2';
  button.innerHTML='<svg class="settings-state-icon" data-lock-state="'+state+'" viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="'+shackle+'"/><path d="M12 14v3"/></svg><span>Settings</span>';
  button.setAttribute('aria-label','Settings — '+state);button.title='Settings '+state+(locked?' — PIN required':'');
 }
 function show(next){continuation=next||continuation;if(!dialog||dialog.open)return;message.textContent='Enter the Settings PIN set on the vMix PC helper.';pin.value='';if(!dialog.open)dialog.showModal();pin.focus();}
 const lock={locked:()=>!viewer()&&policy.enabled===true&&!unlocked,prompt:show,relock:()=>{unlocked=false;mask();}};window.CourtlineSettingsLock=lock;mask();
 function helper(){try{return JSON.parse(localStorage.getItem('courtline-scoreholio-v2')||'{}').scoreholioStats?.helperURL||'';}catch(_){return '';}}
 function applyPolicy(next){if(typeof next.enabled!=='boolean')throw Error('Invalid helper PIN policy.');if(next.revision!==policy.revision)unlocked=false;policy={...next,known:true};localStorage.setItem(key,JSON.stringify(policy));mask();if(!policy.enabled){dialog.close();const next=continuation;continuation=null;next?.();}else if(lock.locked()&&isSettings())show();}
 async function check(){if(!ready||busy||document.hidden||viewer())return;const url=helper();if(!url)return;busy=true;try{const next=await window.pywebview.api.settings_lock(url,{action:'policy'});if(helper()!==url)return;applyPolicy(next);}catch(_){mask();if(lock.locked()&&isSettings())show();}finally{busy=false;}}
 async function watch(){
  if(!ready)return;const url=viewer()?'':helper();let delay=1000;
  try{if(url&&!document.hidden){const next=await window.pywebview.api.settings_lock(url,{action:'watch',revision:policy.revision||''});if(helper()===url)applyPolicy(next);}}
  catch(_){delay=3000;mask();if(lock.locked()&&isSettings())show();}
  setTimeout(watch,delay);
 }
 window.addEventListener('courtline-view-change',mask);
 window.addEventListener('courtline-ready',()=>{
  dialog=document.createElement('dialog');dialog.className='settings-pin-dialog';dialog.innerHTML='<form><h2>Unlock Settings</h2><p role="status"></p><div class="pin-entry-row"><label for="unlockSettingsPIN">PIN</label><input id="unlockSettingsPIN" type="password" inputmode="numeric" pattern="[0-9]{4,8}" minlength="4" maxlength="8" autocomplete="off" required><button type="submit">Unlock</button></div><div class="pin-secondary-row"><button type="button" data-cancel>Back to Live</button><button type="button" data-scan-helper>Scan Helper QR Code</button></div></form>';
  document.body.append(dialog);pin=dialog.querySelector('input');message=dialog.querySelector('p');
  function cancel(){continuation=null;dialog.close();window.courtlineGoLive?.();mask();}
  dialog.querySelector('[data-cancel]').addEventListener('click',cancel);dialog.addEventListener('cancel',e=>{e.preventDefault();cancel();});
  dialog.querySelector('[data-scan-helper]').addEventListener('click',async()=>{
   const scan=dialog.querySelector('[data-scan-helper]'),submit=dialog.querySelector('[type=submit]');scan.disabled=true;submit.disabled=true;pin.value='';
   message.textContent='Scan the QR code on your PC helper dashboard.';
   try{
    const text=await window.pywebview.api.scan_stats_helper();
    if(text===null){message.textContent='Scan canceled. Enter your PIN or scan again.';return;}
    const target=await window.saveScannedStatsHelper(text);
    if(target.role==='viewer'){dialog.close();location.reload();return;}
    unlocked=false;mask();
    applyPolicy(await window.pywebview.api.settings_lock(target.url,{action:'policy'}));
    if(policy.enabled){message.textContent='Helper connected. Enter the Settings PIN set on that PC.';pin.focus();}
   }catch(error){message.textContent='Could not connect helper: '+error.message;}
   finally{scan.disabled=false;submit.disabled=false;}
  });
  dialog.querySelector('form').addEventListener('submit',async e=>{e.preventDefault();const button=dialog.querySelector('[type=submit]');button.disabled=true;try{const result=await window.pywebview.api.settings_lock(helper(),{action:'verify',pin:pin.value});if(!result.unlocked)throw Error('Unable to unlock Settings.');policy={enabled:result.enabled,revision:result.revision,known:true};localStorage.setItem(key,JSON.stringify(policy));unlocked=true;pin.value='';dialog.close();mask();const next=continuation;continuation=null;next?.();}catch(error){pin.value='';message.textContent=error.message;pin.focus();}finally{button.disabled=false;}});
  ready=true;mask();if(lock.locked()&&isSettings())show();check();setTimeout(watch,1000);
 });
 document.addEventListener('visibilitychange',()=>{if(document.hidden){lock.relock();}else{mask();if(lock.locked()&&isSettings())show();check();}});
})();
