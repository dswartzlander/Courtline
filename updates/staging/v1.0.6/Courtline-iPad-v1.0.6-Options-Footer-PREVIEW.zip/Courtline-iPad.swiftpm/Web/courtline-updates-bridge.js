// Dedicated native update transport; independent of tournament/vMix commands.
(() => {
  const pending=new Map();let seq=0;
  const original=window.platformReply;
  window.platformReply=(id,value,error)=>{
    if(pending.has(id)){
      const p=pending.get(id);pending.delete(id);clearTimeout(p.timer);
      if(error)p.reject(new Error(error));else p.resolve(value);
    } else if (typeof original === 'function') original(id,value,error);
  };
  function invoke(method,...args){
    return new Promise((resolve,reject)=>{
      const id='update-'+(++seq),timer=setTimeout(()=>{pending.delete(id);reject(Error('Update request timed out.'));},25000);
      pending.set(id,{resolve,reject,timer});
      try{window.CourtlineNative[method](id,...args);}catch(e){clearTimeout(timer);pending.delete(id);reject(e);}
    });
  }
  window.CourtlineUpdatesTransport={check:()=>invoke('checkUpdates'),download:(url,name)=>invoke('downloadUpdate',url,name)};
})();
