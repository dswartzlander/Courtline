window.addEventListener('courtline-ready', () => {
  'use strict';

  const STORAGE_KEY = 'courtline-scoreholio-v2';
  const LEGACY_STORAGE_KEY = 'courtline-scoreholio-v1';
  const DEFAULT_ACCOUNT = 'f1Skycvh7zTTizphNP54FsAoCep2';
  const OLD_SAMPLE_URL = 'https://app.scoreholio.com/cornhole/scoreboard?account=f1Skycvh7zTTizphNP54FsAoCep2&game=IoT1EI5amQQBB5F6IHCC&court=1&forcemagic=1';
  // Permanent Widget URLs for the four TVs shown in the director's device list.
  const DEFAULT_DEVICE_IDS = ['b66c03bc193a618e', '72b369900c298394', 'ed634bd17e6947fc', '1a9533399c21de44'];
  const DEFAULT_URLS = DEFAULT_DEVICE_IDS.map(id => `https://app.scoreholio.com/overlay?account=${DEFAULT_ACCOUNT}&did=${id}`);
  const PROJECT = 'scoreholio';
  const FIRESTORE_BASE = `https://firestore.googleapis.com/v1/projects/${PROJECT}/databases/(default)/documents`;
  const REMOTE_MODE_API = 'https://us-central1-scoreholio.cloudfunctions.net/misc/app-get-remote-mode';
  const GAME_INFO_TTL_MS = 30000;
  const REFRESH_INTERVAL_MS = 2000;
  const gameInfoCache = new Map();
  const cards = [...document.querySelectorAll('.court-card')];
  // Settings only: two independent vertical court stacks. The original four
  // cards are moved, never cloned, so live data and event handlers survive.
  // Live view and narrow screens retain the original single grid order.
  const courtGrid = document.getElementById('courtGrid');
  const settingsCourtColumns = [0, 1].map(() => {
    const column = document.createElement('div');
    column.className = 'settings-court-column';
    return column;
  });
  const narrowSettings = window.matchMedia('(max-width: 680px)');
  function arrangeSettingsCourts(isLive) {
    const twoColumns = !isLive && !narrowSettings.matches;
    if (twoColumns) {
      courtGrid.prepend(...settingsCourtColumns);
      cards.forEach((card, i) => settingsCourtColumns[i % 2].append(card));
    } else {
      cards.forEach(card => courtGrid.append(card));
      settingsCourtColumns.forEach(column => column.remove());
    }
  }
  narrowSettings.addEventListener('change', () => arrangeSettingsCourts(document.body.classList.contains('display-mode')));
  const isViewer = window.CourtlineCompanion?.role === 'viewer';
  const refreshButton = document.getElementById('refreshButton');
  const vmixHostField = document.getElementById('vmixHost');
  const vmixAddressField = document.getElementById('vmixAddress');
  const vmixPortField = document.getElementById('vmixPort');
  const autoCheckbox = document.getElementById('autoRefresh');
  const settingsButton = document.getElementById('viewSettings');
  const liveIndicator = document.getElementById('liveIndicator');
  const liveLabel = document.getElementById('liveLabel');
  const nextRefresh = document.getElementById('nextRefresh');
  const lastSync = document.getElementById('lastSync');
  const connectionText = document.getElementById('connectionText');
  const connectionDetail = document.getElementById('connectionDetail');
  const assignmentAlert = document.getElementById('assignmentAlert');
  const assignmentDialog = assignmentAlert.querySelector('.assignment-dialog');
  const assignmentAlertTitle = document.getElementById('assignmentAlertTitle');
  const assignmentChanges = document.getElementById('assignmentChanges');
  const assignmentChangeCount = document.getElementById('assignmentChangeCount');
  const assignmentSeconds = document.getElementById('assignmentSeconds');
  const assignmentTimerBar = document.getElementById('assignmentTimerBar');
  const assignmentApply = document.getElementById('assignmentApply');
  const ALERT_DURATION_MS = 6000;

  let saved = {};
  let hasV2Settings = false;
  try {
    const current = localStorage.getItem(STORAGE_KEY);
    hasV2Settings = Boolean(current);
    saved = JSON.parse(current || localStorage.getItem(LEGACY_STORAGE_KEY) || '{}') || {};
  } catch (_) {}
  let urls = Array.isArray(saved.urls) ? saved.urls.slice(0, 4) : DEFAULT_URLS.slice();
  while (urls.length < 4) urls.push('');
  // The old version automatically seeded one example scoreboard URL.
  // On upgrade, replace only that untouched example with four permanent device links.
  if (!hasV2Settings && urls[0] === OLD_SAMPLE_URL && urls.slice(1).every(value => !value.trim())) {
    urls = DEFAULT_URLS.slice();
  }
  let pairings = Array.isArray(saved.pairings) ? saved.pairings.slice(0, 4) : [];
  while (pairings.length < 4) pairings.push(null);
  let autoRefresh = typeof saved.autoRefresh === 'boolean' ? saved.autoRefresh : true;
  const visibleCourts = Array.from({length:4}, (_, i) => saved.visibleCourts?.[i] !== false);
  let displayMode = false;
  let vmixHost = typeof saved.vmixHost === 'string' ? saved.vmixHost : '';
  const vmixInputs = Array.isArray(saved.vmixInputs) ? saved.vmixInputs.slice(0, 4) : [];
  while (vmixInputs.length < 4) vmixInputs.push('');
  // These are the camera/video feeds for the shared telestrator's Output 2,
  // not the Scoreholio Browser inputs in vmixInputs.
  const telestratorSources = Array.isArray(saved.telestratorSources) ? saved.telestratorSources.slice(0,4) : [];
  while (telestratorSources.length < 4) telestratorSources.push('');
  let nextPollAt = Date.now() + REFRESH_INTERVAL_MS;
  let activeRequest = null;
  let updateSequence = 0;
  let inputDebounce = null;
  let syncCompletedAt = null;
  let pollHadError = false;
  const results = Array(4).fill(null);
  const initialized = Array(4).fill(false);
  const pendingChanges = new Map();
  let alertDeadline = 0;
  let alertTimeout = null;
  let focusBeforeAlert = null;

  function save() {
    if(isViewer)return;
    const settings = {urls, pairings, autoRefresh, vmixHost, vmixInputs, telestratorSources, visibleCourts,scoreholioStats:window.collectStatsSettings?.()||saved.scoreholioStats};
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(settings)); } catch (_) {}
    window.desktopSaveUI(settings);
  }
  window.desktopCollectUI=()=>({urls,pairings,autoRefresh,vmixHost,vmixInputs,telestratorSources,visibleCourts,scoreholioStats:window.collectStatsSettings?.()||saved.scoreholioStats});
  window.desktopGetTelestratorSource=i=>telestratorSources[i]||'';
  window.desktopSetTelestratorSource=(i,value)=>{
    if(isViewer||!Number.isInteger(i)||i<0||i>3)throw Error('Only Main can edit Telestrator court sources.');
    const source=String(value||'').trim();if(source.length>120)throw Error('Use a vMix input name or number under 120 characters.');
    telestratorSources[i]=source;save();
  };

  function widgetBUrl(account, game, court) {
    if (!/^[a-zA-Z0-9_-]{8,100}$/.test(String(account || '')) ||
        !/^[a-zA-Z0-9_-]{8,100}$/.test(String(game || '')) ||
        !Number.isInteger(Number(court)) || Number(court) < 1 || Number(court) > 128) return '';
    const url = new URL('https://app.scoreholio.com/v2/cornhole/overlay');
    url.searchParams.set('type', 'widget-b');
    url.searchParams.set('account', account);
    url.searchParams.set('game', game);
    url.searchParams.set('court', String(court));
    return url.toString();
  }

  function vmixApiUrl(address) {
    let host;
    try { host = new URL(address.trim()); }
    catch (_) { throw new Error('Enter a valid vMix Web API address, including http:// or https://.'); }
    if (!['http:', 'https:'].includes(host.protocol) || host.username || host.password || host.search || host.hash) {
      throw new Error('Use a plain http:// or https:// vMix Web API address.');
    }
    return new URL('/api/', host);
  }

  function vmixCommandUrl(inputName, widgetUrl) {
    const api = vmixApiUrl(vmixHost);
    if (!inputName.trim()) throw new Error('Set this court’s vMix input in setup (Exit Display).');
    api.searchParams.set('Function', 'BrowserNavigate');
    api.searchParams.set('Input', inputName.trim());
    api.searchParams.set('Value', widgetUrl);
    return api.toString();
  }

  function parseScoreholioUrl(value) {
    if (!value.trim()) return null;
    let url;
    try { url = new URL(value.trim()); } catch (_) { throw new Error('Paste a valid Scoreholio URL.'); }
    if (url.protocol !== 'https:' || url.hostname !== 'app.scoreholio.com') {
      throw new Error('Use a link from app.scoreholio.com.');
    }
    const account = url.searchParams.get('account');
    if (!account || !/^[a-zA-Z0-9_-]{8,100}$/.test(account)) {
      throw new Error('This link needs a Scoreholio account ID.');
    }
    const deviceId = url.searchParams.get('did');
    if (url.pathname === '/overlay' && deviceId) {
      if (!/^[a-zA-Z0-9_-]{8,100}$/.test(deviceId)) throw new Error('Invalid device ID in Widget URL.');
      return {account, deviceId, type:'device', original:url.toString()};
    }
    if (url.pathname !== '/cornhole/scoreboard') {
      throw new Error('Use a Widget link (/overlay?account=…&did=…) or a cornhole scoreboard URL.');
    }
    const game = url.searchParams.get('game');
    const courtText = url.searchParams.get('court') || '1';
    if (!game || !/^[a-zA-Z0-9_-]{8,100}$/.test(game)) {
      throw new Error('This scoreboard link needs a game ID.');
    }
    if (!/^\d{1,3}$/.test(courtText) || Number(courtText) < 1 || Number(courtText) > 128) {
      throw new Error('Court must be between 1 and 128.');
    }
    return {account, game, court: Number(courtText), type:'scoreboard', original: url.toString()};
  }

  function getField(fields, name) {
    const value = fields?.[name];
    if (!value) return null;
    if (Object.prototype.hasOwnProperty.call(value, 'stringValue')) return value.stringValue;
    if (Object.prototype.hasOwnProperty.call(value, 'integerValue')) return Number(value.integerValue);
    if (Object.prototype.hasOwnProperty.call(value, 'booleanValue')) return Boolean(value.booleanValue);
    return null;
  }

  function tournamentDisplayName(value) {
    const name = String(value || '').trim();
    // Strip only a clearly separated leading date, keeping event numbers and divisions.
    const datePrefix = /^(?:(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\.?\s+\d{1,2}(?:st|nd|rd|th)?(?:,?\s+\d{4})?|\d{4}-\d{1,2}-\d{1,2}|\d{1,2}[\/-]\d{1,2}(?:[\/-]\d{2,4})?)\s+[-–—|:]\s*/i;
    return name.replace(datePrefix, '').trim() || name;
  }

  function readableScore(value) {
    if (value === null || value === undefined) return null;
    const score = String(value).trim();
    return /^-?\d+(?:\.\d+)?$/.test(score) ? score : null;
  }

  async function fetchJson(endpoint, signal) {
    const response = await window.desktopFetch(`${FIRESTORE_BASE}/${endpoint}`, {cache:'no-store', signal, headers:{Accept:'application/json'}});
    if (!response.ok) {
      if (response.status === 403 || response.status === 401) throw new Error('Scoreholio denied public access.');
      if (response.status === 404) throw new Error('Tournament not found.');
      throw new Error(`Scoreholio request failed (${response.status}).`);
    }
    return response.json();
  }

  async function fetchRemoteAssignments(account, signal) {
    const response = await window.desktopFetch(REMOTE_MODE_API, {
      method:'POST',
      body:new URLSearchParams({sport:'cornhole', accountid:account, version:'2', tournamentDays:'30'}),
      cache:'no-store',
      signal,
      headers:{Accept:'application/json'}
    });
    if (!response.ok) throw new Error(`Device feed unavailable (${response.status}).`);
    const data = await response.json();
    if (!Array.isArray(data?.hits)) throw new Error('Unexpected device data from Scoreholio.');
    return data.hits;
  }

  async function fetchGameInfo(account,game,signal) {
    const key = `${account}/${game}`;
    const cached = gameInfoCache.get(key);
    if (cached && cached.expires > Date.now()) return cached.promise;
    const promise = fetchJson(`accounts/${encodeURIComponent(account)}/games/${encodeURIComponent(game)}`,signal)
      .then(data=>({
        format:String(getField(data.fields,'format') || ''),
        teamcreate:String(getField(data.fields,'teamcreate') || ''),
        status:String(getField(data.fields,'status') || ''),
        sportVariant:String(getField(data.fields,'sportVariant') || '')
      }));
    gameInfoCache.set(key,{expires:Date.now()+GAME_INFO_TTL_MS,promise});
    try {return await promise;}
    catch (error) {gameInfoCache.delete(key);throw error;}
  }

  function fieldFilter(fieldPath,op,value) {
    return {fieldFilter:{field:{fieldPath},op,value}};
  }

  async function fetchCourtTeams(account,game,court,gameInfo,signal) {
    if (['Complete','Setup'].includes(gameInfo.status)) {
      return {matchup:[],matchState:gameInfo.status === 'Complete' ? 'Tournament complete' : 'No active match assigned',matchSignature:`none:${gameInfo.status}`};
    }
    const isBracket = ['Single Elimination','Double Elimination'].includes(gameInfo.format) || gameInfo.status === 'Bracket';
    const usesPlaced = ['Switcholio','Split Switch'].includes(gameInfo.teamcreate)
      || ['Set Schedule','Ladder','Backyard Battle','King of the Court'].includes(gameInfo.format)
      || Boolean(gameInfo.sportVariant);
    const collection = isBracket ? 'finals' : usesPlaced ? 'placed' : 'teams';
    const filters = isBracket
      ? [fieldFilter('court','EQUAL',{integerValue:String(court)}),fieldFilter('status','EQUAL',{stringValue:'TBD'})]
      : [
        fieldFilter('court','EQUAL',{integerValue:String(court)}),
        fieldFilter('stage','GREATER_THAN',{stringValue:'PlayingB'}),
        fieldFilter('stage','LESS_THAN',{stringValue:'PlayingD'})
      ];
    const structuredQuery = {
      from:[{collectionId:collection}],
      select:{fields:['teamName','playerName1','playerName2','playerName3','playerName4','currentScore','timesPlayed','stage','status','court','placement','bestWins'].map(fieldPath=>({fieldPath}))},
      where:{compositeFilter:{op:'AND',filters}},
      orderBy:isBracket
        ? [{field:{fieldPath:'stage'},direction:'ASCENDING'},{field:{fieldPath:'placement'},direction:'ASCENDING'}]
        : [{field:{fieldPath:'stage'},direction:'ASCENDING'},{field:{fieldPath:'priority'},direction:'ASCENDING'}],
      limit:2
    };
    const response = await window.desktopFetch(`${FIRESTORE_BASE}/accounts/${encodeURIComponent(account)}/games/${encodeURIComponent(game)}:runQuery`,{
      method:'POST',
      headers:{'Content-Type':'application/json',Accept:'application/json'},
      body:JSON.stringify({structuredQuery}),
      cache:'no-store',
      signal
    });
    if (!response.ok) throw new Error(`Matchup lookup failed (${response.status}).`);
    const payload = await response.json();
    if (!Array.isArray(payload)) throw new Error('Invalid Scoreholio matchup response.');
    const matchup = payload.filter(row=>row.document).slice(0,2).map(({document})=>{
      const fields = document.fields || {};
      const players = [1,2,3,4].map(n=>String(getField(fields,`playerName${n}`) || '').trim()).filter(Boolean);
      const name = players.join(' / ') || 'Player names unavailable';
      return {
        id:document.name.split('/').pop(),
        name,
        players,
        teamName:String(getField(fields,'teamName') || '').trim(),
        score:readableScore(getField(fields,'currentScore')),
        timesPlayed:String(getField(fields,'timesPlayed') ?? 0),
        placement:String(getField(fields,'placement') ?? 0),bestWins:String(getField(fields,'bestWins') ?? 0),
        stage:String(getField(fields,'stage') || '')
      };
    });
    // Query the scoreboard's per-round feed for this exact current matchup.
    if(matchup.length===2){
      try{
        const ids=window.CourtlineMatchStats.ids(account,game,matchup,isBracket);
        const response=await window.desktopFetch(`${FIRESTORE_BASE}/accounts/${encodeURIComponent(account)}/games/${encodeURIComponent(game)}:runQuery`,{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({structuredQuery:{from:[{collectionId:'scoremagic'}],where:fieldFilter('matchid','IN',{arrayValue:{values:ids.map(stringValue=>({stringValue}))}}),limit:1000}}),cache:'no-store',signal});
        if(!response.ok)throw Error('Match stats unavailable');
        const rows=await response.json();if(!Array.isArray(rows))throw Error('Invalid match stats');
        const values=window.CourtlineMatchStats.summarize(rows.filter(r=>r.document).map(r=>r.document.fields),matchup);
        matchup.forEach((side,i)=>side.matchStats=values[i]);
      }catch(error){if(signal?.aborted)throw error;matchup.forEach(side=>side.matchStats=[]);}
    }
    return {
      matchup,
      matchState:matchup.length ? matchup.length===2 ? 'Match assigned' : 'Waiting for opponent' : 'No active match assigned',
      matchSignature:matchup.length
        ? matchup.map(team=>`${team.id}:${team.name}:${team.timesPlayed}:${team.stage}`).join('|')
        : `none:${gameInfo.status}`
    };
  }

  async function fetchCurrentMatch(account,game,court,signal) {
    if (!game || !/^[a-zA-Z0-9_-]{8,100}$/.test(game) || !Number.isInteger(court) || court<1 || court>128) {
      return {matchup:[],matchState:'No active match assigned',matchSignature:'none:invalid'};
    }
    const gameInfo = await fetchGameInfo(account,game,signal);
    return fetchCourtTeams(account,game,court,gameInfo,signal);
  }

  function resultForEmpty() {return {kind:'idle', name:'Waiting for URL', kicker:'TOURNAMENT NAME', detail:'Paste the permanent Widget URL for a managed device.', meta:'NO LINK ENTERED'};}

  function sameAssignedScoreboard(row, target) {
    if (!row.loadurl || !target.game) return false;
    try {
      const link = parseScoreholioUrl(row.loadurl);
      return link?.type === 'scoreboard' && link.account === target.account && link.game === target.game && link.court === target.court;
    } catch (_) { return false; }
  }

  function managedDeviceFor(hits, target, index) {
    if (target.type === 'device') return hits.find(row => row.deviceid === target.deviceId) || null;
    const remembered = pairings[index];
    if (remembered?.account === target.account && remembered?.deviceId) {
      const row = hits.find(hit => hit.deviceid === remembered.deviceId);
      if (row) return row;
    }
    const matches = hits.filter(row => sameAssignedScoreboard(row, target));
    if (matches.length === 1) return matches[0];
    // Multiple devices may show the same scoreboard. Prefer the TV for this physical court.
    const exactTV = `TCL - 00${index+1} - TV`;
    const named = matches.filter(row => (row.devicename || '').replace(/\s+/g, ' ').trim().toLowerCase() === exactTV.toLowerCase());
    return named.length === 1 ? named[0] : null;
  }

  function scoreboardLinkFor(row) {
    if (!row.loadurl) return '';
    try {
      const link = parseScoreholioUrl(row.loadurl);
      return link?.type === 'scoreboard' ? link.original : '';
    } catch (_) { return ''; }
  }

  function scoreText(side) {return side?.score ?? '—';}

  function updateMatchScores(index, sides) {
    const card = cards[index];
    const left = scoreText(sides[0]);
    const right = scoreText(sides[1]);
    const firstScore = card.querySelector('[data-score1]');
    const secondScore = card.querySelector('[data-score2]');
    if (firstScore.textContent !== left) firstScore.textContent = left;
    if (secondScore.textContent !== right) secondScore.textContent = right;
    const describe = value => value === '—' ? 'not available' : value;
    card.querySelector('[data-score]').setAttribute('aria-label', `Score: ${describe(left)} to ${describe(right)}`);
  }

  function drawPlayers(element, side, emptyText) {
    const names = side ? side.players?.length ? side.players : ['Player names unavailable'] : [emptyText];
    element.replaceChildren(...names.map(name => {
      const line = document.createElement('span');
      line.className = 'matchup-player';
      line.textContent = name;
      return line;
    }));
    element.classList.toggle('is-long', names.some(name => name.length > 22));
  }

  function drawStats(index, result) {
    const panel=document.getElementById('statsCourt'+(index+1));
    if(!panel)return;
    const sides=Array.isArray(result.matchup)?result.matchup:[];
    // Store the tournament for every court; switching Stats courts restores its own title.
    const tournament=tournamentDisplayName(result.name)||'Tournament not assigned';
    panel.dataset.statsTournament=tournament;
    if(!panel.hidden){
      const name=document.getElementById('statsTournamentTitle');
      if(name){
        if(name.textContent!==tournament)name.textContent=tournament;
        name.title=tournament;
      }
    }
    for(let team=0;team<2;team++){
      const side=sides[team],heading=panel.querySelector('[data-stats-team="'+team+'"]');
      const teamName=side?.teamName||'';
      if(heading.textContent!==teamName)heading.textContent=teamName;
      heading.hidden=!teamName;
      for(let player=0;player<2;player++){
        const name=panel.querySelector('[data-stats-player="'+team+'-'+player+'"]');
        const text=side?.players?.[player]||'Waiting for player';
        if(name.textContent!==text)name.textContent=text;
      }
    }
    // Reuse the live Scoreholio totals already displayed on the Courts tab.
    // Scores are per-court, including on read-only Companion snapshots.
    const scoreBox=panel.querySelector('[data-stats-score]');
    if(scoreBox){
      const a=scoreText(sides[0]),b=scoreText(sides[1]);
      scoreBox.querySelector('[data-stats-score-left]').textContent=String(a);
      scoreBox.querySelector('[data-stats-score-right]').textContent=String(b);
      scoreBox.setAttribute('aria-label',`Court ${index+1} score: ${a==='—'?'unavailable':a} to ${b==='—'?'unavailable':b}`);
    }
    window.updatePlayerStats?.(index,result);
  }

  function drawCard(index, result) {
    drawStats(index,result);
    const card = cards[index];
    const state = card.querySelector('[data-state]');
    const name = card.querySelector('[data-name]');
    const kicker = card.querySelector('[data-kicker]');
    const detail = card.querySelector('[data-detail]');
    const meta = card.querySelector('[data-meta]');
    const opener = card.querySelector('[data-open]');
    const courtIndex = card.querySelector('.court-index');
    const input = card.querySelector('[data-url]');
    const kind = result.kind || 'idle';
    card.classList.remove('is-assigned', 'is-error');
    if (kind === 'assigned') card.classList.add('is-assigned');
    if (kind === 'error') card.classList.add('is-error');
    state.className = `state-pill is-${kind}`;
    state.textContent = ({assigned:'ASSIGNED', linked:'LINKED URL', error:'CHECK LINK', loading:'CHECKING', idle:'READY'})[kind] || 'READY';
    const displayName = tournamentDisplayName(result.name);
    name.textContent = displayName;
    name.classList.toggle('is-long',displayName.length > 42);
    name.classList.toggle('is-very-long',displayName.length > 66);
    kicker.textContent = result.kicker || 'TOURNAMENT NAME';
    detail.textContent = result.detail || '';
    meta.textContent = result.meta || '';
    const matchPanel = card.querySelector('[data-matchup]');
    const matchSides = card.querySelector('[data-match-sides]');
    const matchEmpty = card.querySelector('[data-match-empty]');
    const sides = Array.isArray(result.matchup) ? result.matchup : [];
    matchPanel.hidden = !result.sourceType;
    matchSides.hidden = !sides.length;
    matchEmpty.hidden = Boolean(sides.length);
    if (sides.length) {
      const first = card.querySelector('[data-team1]');
      const second = card.querySelector('[data-team2]');
      drawPlayers(first, sides[0], 'Waiting for team');
      drawPlayers(second, sides[1], 'Waiting for opponent');
      updateMatchScores(index,sides);
    } else {
      card.querySelector('[data-team1]').textContent = '';
      card.querySelector('[data-team2]').textContent = '';
      matchEmpty.textContent = result.matchState || 'No active match assigned';
    }
    courtIndex.textContent = 'Court ' + String(index + 1).padStart(2,'0');
    if (result.openUrl) {
      opener.href = result.openUrl;
      opener.hidden = false;
    } else {
      opener.hidden = true;
      opener.removeAttribute('href');
    }
    if (input.value !== urls[index] && document.activeElement !== input) input.value = urls[index];
    const sendButton = card.querySelector('[data-send-vmix]');
    const preview = card.querySelector('[data-widget-preview]');
    sendButton.disabled = !result.widgetUrl;
    sendButton.title = result.widgetUrl ? 'Send this court’s Widget B ScoreMagic Horizontal overlay to vMix' : 'Waiting for a tournament and court assignment';
    if (result.widgetUrl) {
      preview.href = result.widgetUrl;
      preview.hidden = false;
    } else {
      preview.hidden = true;
      preview.removeAttribute('href');
    }
  }

  function commitResult(index, candidate) {
    if (candidate.kind !== 'error') initialized[index] = true;
    results[index] = candidate;
    drawCard(index,candidate);
  }

  function hideAssignmentAlert() {
    clearTimeout(alertTimeout);
    alertTimeout = null;
    assignmentAlert.hidden = true;
    document.body.classList.remove('assignment-pending');
    if (focusBeforeAlert?.isConnected) focusBeforeAlert.focus({preventScroll:true});
    focusBeforeAlert = null;
  }

  function updateAlertTimer() {
    if (!pendingChanges.size) return;
    const remaining = Math.max(0,alertDeadline-Date.now());
    assignmentSeconds.textContent = String(Math.ceil(remaining/1000));
    assignmentTimerBar.style.width = `${remaining/ALERT_DURATION_MS*100}%`;
    if (!remaining) applyPendingChanges();
  }

  function renderAssignmentAlert() {
    assignmentChanges.replaceChildren();
    let tournamentChanged = false;
    let matchupCleared = false;
    let matchupAdded = false;
    for (const [index,candidate] of pendingChanges) {
      const old = results[index];
      const isTournamentChange = old?.name !== candidate.name;
      const isMatchCleared = !isTournamentChange && Boolean(old?.matchup?.length) && !candidate.matchup?.length;
      tournamentChanged ||= isTournamentChange;
      matchupCleared ||= isMatchCleared;
      matchupAdded ||= Boolean(candidate.matchup?.length);
      const row = document.createElement('div');
      row.className = 'assignment-change';
      const label = document.createElement('div');
      label.className = 'assignment-change-label';
      label.textContent = `COURT ${index+1} · ${isTournamentChange?'TOURNAMENT CHANGE':isMatchCleared?'MATCH FINISHED':'MATCHUP CHANGE'}`;
      const names = document.createElement('div');
      names.className = 'assignment-name-line';
      const oldName = document.createElement('div');
      oldName.className = 'assignment-old';
      oldName.textContent = isTournamentChange ? tournamentDisplayName(old?.name) || 'No previous assignment' : matchupText(old);
      const arrow = document.createElement('span');
      arrow.className = 'assignment-arrow';
      arrow.textContent = '→';
      const newName = document.createElement('div');
      newName.className = 'assignment-new';
      newName.textContent = isTournamentChange ? tournamentDisplayName(candidate.name) : matchupText(candidate);
      names.append(oldName,arrow,newName);
      row.append(label,names);
      assignmentChanges.append(row);
    }
    const count = pendingChanges.size;
    assignmentAlertTitle.textContent = tournamentChanged
      ? count === 1 ? 'New tournament headed to a court!' : 'New assignments headed to the courts!'
      : matchupCleared && !matchupAdded
        ? count === 1 ? 'Match finished — court awaiting players' : 'Courts awaiting new matchups'
        : count === 1 ? 'New players assigned to a court!' : 'Matchups changed on the courts!';
    assignmentChangeCount.textContent = `${count} court${count===1?'':'s'} changing`;
    updateAlertTimer();
  }

  function matchupText(result) {
    return result?.matchup?.length
      ? result.matchup.map(side=>side.name).join(' vs ')
      : result?.matchState || 'No active match';
  }

  function applyPendingChanges() {
    if (!pendingChanges.size) return;
    const changes = [...pendingChanges.entries()];
    pendingChanges.clear();
    hideAssignmentAlert();
    for (const [index,candidate] of changes) {
      commitResult(index,candidate);
      cards[index].classList.add('just-updated');
      setTimeout(() => cards[index].classList.remove('just-updated'),3500);
    }
    updateStatus();
  }

  function stageChange(index,candidate) {
    if (pendingChanges.get(index)?.trackingSignature === candidate.trackingSignature) {
      // Keep the latest score for the incoming match without restarting its alert.
      pendingChanges.set(index,candidate);
      return;
    }
    const opening = !pendingChanges.size;
    pendingChanges.set(index,candidate);
    alertDeadline = Date.now()+ALERT_DURATION_MS;
    if (opening) {
      focusBeforeAlert = document.activeElement;
      assignmentAlert.hidden = false;
      document.body.classList.add('assignment-pending');
      assignmentDialog.focus({preventScroll:true});
    }
    clearTimeout(alertTimeout);
    alertTimeout = setTimeout(applyPendingChanges,ALERT_DURATION_MS);
    renderAssignmentAlert();
  }

  function cancelStagedChange(index) {
    if (!pendingChanges.delete(index)) return;
    if (!pendingChanges.size) hideAssignmentAlert();
    else renderAssignmentAlert();
  }

  function handleCandidate(index,candidate) {
    if (candidate.kind !== 'error') window.desktopAssignment(index, candidate.widgetUrl || '');
    const current = results[index];
    if (candidate.kind === 'error' && initialized[index] && current?.kind !== 'error') {
      // Keep a last-known-good court visible through transient network failures.
      return;
    }
    if (pendingChanges.has(index)) {
      if (current?.trackingSignature && candidate.trackingSignature === current.trackingSignature) {
        cancelStagedChange(index);
        return;
      }
      if (candidate.kind === 'error') return;
      stageChange(index,candidate);
      return;
    }
    if (initialized[index] && current?.trackingSignature && candidate.trackingSignature &&
        current.sourceType === candidate.sourceType && current.trackingSignature !== candidate.trackingSignature) {
      stageChange(index,candidate);
      return;
    }
    // Polls with identical assignments must never redraw the four court cards.
    if (current?.trackingSignature && current.trackingSignature === candidate.trackingSignature) {
      drawStats(index,candidate);
      // A point scored is not a new court assignment: update only the numbers.
      if (scoreText(current.matchup?.[0]) !== scoreText(candidate.matchup?.[0]) ||
          scoreText(current.matchup?.[1]) !== scoreText(candidate.matchup?.[1])) {
        results[index] = candidate;
        updateMatchScores(index,candidate.matchup || []);
      }
      return;
    }
    if (current?.kind === candidate.kind && current?.name === candidate.name &&
        current?.detail === candidate.detail && current?.meta === candidate.meta) return;
    commitResult(index,candidate);
  }

  function updateStatus() {
    if(isViewer){
      connectionText.textContent=document.body.classList.contains('companion-stale')?'Main CourtLine connection is stale':'Viewing the main CourtLine device';
      connectionDetail.textContent='Read-only companion · Stats and Telestrator';
      lastSync.textContent=syncCompletedAt?'Latest mirrored court data received':'Waiting for main CourtLine';
      liveLabel.textContent='COMPANION VIEW';nextRefresh.textContent='Updates from Windows Helper';
      liveIndicator.classList.toggle('is-off',document.body.classList.contains('companion-stale'));
      return;
    }
    const configured = urls.filter(s=>s.trim()).length;
    const assigned = results.filter(x=>x?.kind === 'assigned').length;
    const errors = results.filter(x=>x?.kind === 'error').length;
    connectionText.textContent = pollHadError ? 'Connection issue · showing last known assignments' : errors ? `${errors} device${errors===1?' needs':'s need'} attention` : assigned ? `${assigned} live device assignment${assigned===1?'':'s'}` : configured ? 'Monitoring Scoreholio' : 'Ready to monitor';
    connectionDetail.textContent = `${configured} of 4 URLs configured${configured<4?` · ${4-configured} waiting`:''}`;
    lastSync.textContent = syncCompletedAt ? 'Background monitoring active' : 'Connecting…';
    liveIndicator.classList.toggle('is-off', !autoRefresh);
    liveLabel.textContent = 'CONTROL VIEW';
    liveIndicator.title = autoRefresh ? 'Control View · Main device' : 'Control View · Monitoring paused';
    nextRefresh.textContent = autoRefresh ? 'Silent refresh every 2s' : 'Auto refresh paused';
  }

  async function checkAll() {
    if(isViewer)return; // Viewer cards are painted only from main-device snapshots.
    if (activeRequest) {activeRequest.abort();activeRequest = null;}
    const controller = new AbortController();
    activeRequest = controller;
    const seq = ++updateSequence;
    const timedOut = setTimeout(()=>controller.abort(), 9000);
    const parsed = urls.map(url => {try{return {value:parseScoreholioUrl(url)};}catch(error){return {error};}});
    const accounts = [...new Set(parsed.filter(p=>p.value).map(p=>p.value.account))];
    let encounteredError = false;

    for (let i=0;i<4;i++) {
      if (!urls[i].trim()) handleCandidate(i,resultForEmpty());
      else if (parsed[i].error) {
        handleCandidate(i,{kind:'error',name:'Invalid Scoreholio link',detail:parsed[i].error.message,meta:'CHECK URL FORMAT'});
      }
    }

    const devicesByAccount = new Map(accounts.map(account=>[
      account,
      fetchRemoteAssignments(account,controller.signal)
        .then(hits=>({hits}))
        .catch(error=>({error}))
    ]));

    try {
      await Promise.all(parsed.map(async (entry,i) => {
        if (!entry.value) return;
        const target = entry.value;
        const feed = await devicesByAccount.get(target.account);
        if (seq !== updateSequence) return;
        if (feed.error) encounteredError = true;
        const device = feed.hits ? managedDeviceFor(feed.hits,target,i) : null;
        let candidate;

        if (device) {
          const deviceId = String(device.deviceid || '');
          if (target.type === 'scoreboard' && deviceId && (pairings[i]?.deviceId !== deviceId || pairings[i]?.account !== target.account)) {
            pairings[i] = {account:target.account, deviceId};
            save();
          }
          const currentLink = scoreboardLinkFor(device);
          const label = device.devicename || 'Managed device';
          const liveStatus = typeof device.status === 'string' ? device.status.toUpperCase() : 'CONNECTED';
          const assignmentSignature = `remote:${deviceId}:${device.gameid || ''}:${device.court || ''}:${device.gamename || ''}`;
          let matchInfo = {matchup:[],matchState:'No active match assigned',matchSignature:'none'};
          if (device.gamename && device.gameid) {
            try {
              matchInfo = await fetchCurrentMatch(target.account,String(device.gameid),Number(device.court),controller.signal);
            } catch (_) {
              encounteredError = true;
              const last = pendingChanges.get(i) || results[i];
              if (last?.assignmentSignature === assignmentSignature) {
                matchInfo = {matchup:last.matchup || [],matchState:last.matchState,matchSignature:last.matchSignature};
              }
            }
          }
          if (seq !== updateSequence) return;
          const trackingSignature = `${assignmentSignature}#${matchInfo.matchSignature}`;
          const widgetUrl = widgetBUrl(target.account, device.gameid, device.court);
          candidate = device.gamename
            ? {kind:'assigned',name:device.gamename,kicker:'TOURNAMENT NAME',detail:label,meta:`REMOTE MODE · ${liveStatus}`,openUrl:currentLink,widgetUrl,sourceType:'managed',assignmentSignature,trackingSignature,deviceName:label,...matchInfo}
            : {kind:'idle',name:'Awaiting tournament',kicker:'TOURNAMENT NAME',detail:label,meta:`REMOTE MODE · ${liveStatus}`,openUrl:currentLink,sourceType:'managed',assignmentSignature,trackingSignature,deviceName:label,...matchInfo};
        } else if (target.type === 'device') {
          encounteredError = true;
          candidate = {kind:'error',name:feed.error ? 'Cannot reach device feed' : 'Device not found',kicker:'MANAGED DEVICE',detail:feed.error?.message || 'The Widget link did not match a device in this account. Check its account and did values.',meta:'CHECK DEVICE URL'};
        } else {
          if (feed.error && results[i]?.sourceType === 'managed') return;
          // A scoreboard URL displays one tournament. If we cannot identify the device
          // behind it, make that limitation explicit rather than implying live tracking.
          const gameResult = await fetchJson(`accounts/${encodeURIComponent(target.account)}/games/${encodeURIComponent(target.game)}`,controller.signal)
            .then(data=>({name:getField(data.fields,'name'),status:getField(data.fields,'status')}))
            .catch(error=>({error}));
          if (seq !== updateSequence) return;
          if (gameResult.error) encounteredError = true;
          if (gameResult.name) {
            const assignmentSignature = `linked:${target.account}:${target.game}:${gameResult.name}`;
            let matchInfo = {matchup:[],matchState:'No active match assigned',matchSignature:'none'};
            try {
              matchInfo = await fetchCurrentMatch(target.account,target.game,target.court,controller.signal);
            } catch (_) {
              encounteredError = true;
              const last = pendingChanges.get(i) || results[i];
              if (last?.assignmentSignature === assignmentSignature) {
                matchInfo = {matchup:last.matchup || [],matchState:last.matchState,matchSignature:last.matchSignature};
              }
            }
            if (seq !== updateSequence) return;
            candidate = {kind:'linked',name:gameResult.name,kicker:'SCOREBOARD LINK ONLY',detail:feed.error ? 'Device feed unavailable. This is the tournament in the pasted link, not a confirmed new assignment.' : 'This link is not associated with a managed device. Paste its permanent Widget URL to follow reassignment.',meta:`LINKED GAME · ${(gameResult.status || 'STATUS UNKNOWN').toUpperCase()}`,openUrl:target.original,widgetUrl:widgetBUrl(target.account,target.game,target.court),sourceType:'scoreboard',assignmentSignature,trackingSignature:`${assignmentSignature}#${matchInfo.matchSignature}`,...matchInfo};
          } else {
            candidate = {kind:'error',name:'Unable to load tournament',kicker:'CONNECTION ISSUE',detail:gameResult.error?.message || 'No tournament name was returned by Scoreholio.',meta:'TRY REFRESHING',openUrl:target.original};
          }
        }
        handleCandidate(i,candidate);
      }));
    } catch (error) {
      encounteredError = true;
      if (seq === updateSequence) {
        parsed.forEach((entry,i) => {
          if (!entry.value) return;
          handleCandidate(i,{kind:'error',name:'Unable to refresh',kicker:'CONNECTION ISSUE',detail:error?.message || 'The live request failed.',meta:'RETRY ON NEXT CHECK'});
        });
      }
    } finally {
      clearTimeout(timedOut);
    }
    if (seq === updateSequence) {
      activeRequest = null;
      pollHadError = encounteredError;
      syncCompletedAt = new Date();
      nextPollAt = Date.now() + REFRESH_INTERVAL_MS;
      updateStatus();
    }
  }

  function queueCheck() {
    clearTimeout(inputDebounce);
    inputDebounce = setTimeout(()=>{nextPollAt=Date.now()+REFRESH_INTERVAL_MS;checkAll();}, 450);
  }

  function resetSlotForEdit(index) {
    window.desktopAssignment(index, '');
    if (activeRequest) activeRequest.abort();
    activeRequest = null;
    updateSequence++;
    initialized[index] = false;
    cancelStagedChange(index);
    results[index] = null;
    drawCard(index, resultForEmpty());
  }

  const testVmixButton = document.getElementById('testVmixConnection');
  const vmixConnectionResult = document.getElementById('vmixConnectionResult');
  vmixHostField.value = vmixHost;
  try{
    const parts=window.VmixAddress.split(vmixHost);
    vmixAddressField.value=parts.host;vmixPortField.value=parts.port;vmixAddressField.dataset.protocol=parts.protocol;
  }catch(_){vmixAddressField.value=vmixHost;vmixPortField.value='8088';}
  window.desktopValidateVmixAddress=()=>{
    vmixHost=window.VmixAddress.combine(vmixAddressField.value,vmixPortField.value,vmixAddressField.dataset.protocol||'http:');
    vmixHostField.value=vmixHost;
    vmixAddressField.dataset.protocol=new URL(vmixHost).protocol;
    return vmixHost;
  };
  for(const field of [vmixAddressField,vmixPortField])field.addEventListener('input',()=>{
    vmixConnectionResult.textContent='';delete vmixConnectionResult.dataset.state;
    try{window.desktopValidateVmixAddress();save();}
    catch(error){vmixHostField.value='';vmixHost='';vmixConnectionResult.textContent=error.message;vmixConnectionResult.dataset.state='error';}
  });
  testVmixButton.addEventListener('click', async () => {
    testVmixButton.disabled = true;
    vmixConnectionResult.textContent = 'Testing…';
    try {
      window.desktopValidateVmixAddress();
      await window.desktopFlushUI();
      vmixConnectionResult.textContent = await window.pywebview.api.vmix_health(vmixHostField.value);
      vmixConnectionResult.dataset.state = 'success';
    } catch(error) {
      vmixConnectionResult.textContent = 'Failed — ' + error.message;
      vmixConnectionResult.dataset.state = 'error';
    } finally { testVmixButton.disabled = false; }
  });

  cards.forEach((card,index)=>{
    const input=card.querySelector('[data-url]');
    const clear=card.querySelector('[data-clear]');
    const vmixPanel = document.createElement('div');
    vmixPanel.className = 'vmix-card-controls';
    vmixPanel.innerHTML = `
      <div class="vmix-card-heading"><label for="vmixInput${index+1}">COURT ${index+1} → vMix browser input</label><span>INDEPENDENT DESTINATION</span></div>
      <input type="text" id="vmixInput${index+1}" data-vmix-input spellcheck="false" autocomplete="off" placeholder="Enter this court's vMix input name or number" />
      <div class="vmix-card-actions"><button type="button" data-send-vmix disabled>Send Browser Widget to vMix</button><a data-widget-preview target="_blank" rel="noopener noreferrer" hidden>PREVIEW B ↗</a></div>
      <p class="vmix-card-feedback" data-vmix-feedback role="status" aria-live="polite"></p>`;
    card.querySelector('.court-card-bottom').append(vmixPanel);
    const vmixInput = vmixPanel.querySelector('[data-vmix-input]');
    const vmixFeedback = vmixPanel.querySelector('[data-vmix-feedback]');
    // Keep feedback below the send action, in a permanently reserved area.
    const sendGroup = document.createElement('div');
    sendGroup.className = 'vmix-send-group';
    const actions = vmixPanel.querySelector('.vmix-card-actions');
    sendGroup.append(...actions.children, vmixFeedback);
    actions.append(sendGroup);
    vmixInput.value = vmixInputs[index];
    vmixInput.addEventListener('input', () => {
      vmixInputs[index] = vmixInput.value;
      save();
    });
    const sendButton = vmixPanel.querySelector('[data-send-vmix]');
    sendButton.addEventListener('click', async () => {
      sendButton.disabled = true;
      delete vmixFeedback.dataset.state;
      vmixFeedback.textContent = 'Sending…';
      try {
        window.desktopValidateVmixAddress();
        await window.desktopFlushUI();
        const widgetUrl = results[index]?.widgetUrl;
        if (!widgetUrl) throw new Error('Wait for a tournament assignment.');
        vmixFeedback.textContent = await window.pywebview.api.send_widget(index, vmixInputs[index], widgetUrl, vmixHost);
        vmixFeedback.dataset.state = 'success';
      } catch (error) {
        vmixFeedback.dataset.state = 'error';
        vmixFeedback.textContent = 'Failed or unconfirmed — ' + error.message;
      } finally { sendButton.disabled = !results[index]?.widgetUrl; }
    });
    input.value=urls[index];
    input.addEventListener('input',()=>{
      urls[index]=input.value;
      pairings[index]=null;
      resetSlotForEdit(index);
      save();
      queueCheck();
    });
    input.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();input.blur();clearTimeout(inputDebounce);checkAll();}});
    clear.addEventListener('click',()=>{
      urls[index]='';pairings[index]=null;input.value='';resetSlotForEdit(index);save();queueCheck();input.focus();
    });
    drawCard(index,resultForEmpty());
  });

  const emptyLive = document.createElement('p');
  emptyLive.className = 'empty-live-courts';
  emptyLive.textContent = 'No courts selected. Open Settings and check Show in Live view for a court.';
  document.querySelector('.court-grid').append(emptyLive);
  function updateCourtVisibility() {
    document.querySelector('.court-grid').dataset.visibleCount = visibleCourts.filter(Boolean).length;
    cards.forEach((card, i) => card.classList.toggle('court-hidden-live', !visibleCourts[i]));
    emptyLive.hidden = visibleCourts.some(Boolean);
  }
  cards.forEach((card, i) => {
    const label = document.createElement('label');
    label.className = 'court-visibility-toggle';
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = visibleCourts[i];
    checkbox.setAttribute('aria-label', 'Show Court ' + (i + 1) + ' in Live view');
    label.append(checkbox, document.createTextNode('Show in Live view'));
    const top=card.querySelector('.court-card-top');
    const options=document.createElement('div');options.className='court-header-options';
    options.append(label,top.querySelector('[data-state]'));top.append(options);
    checkbox.addEventListener('change', () => {
      visibleCourts[i] = checkbox.checked;
      updateCourtVisibility();
      save();
    });
  });
  updateCourtVisibility();
  autoCheckbox.checked=autoRefresh;
  function setDisplayMode(isLive) {
    if(isViewer)isLive=true;
    if(!isLive&&window.CourtlineSettingsLock?.locked()){window.CourtlineSettingsLock.prompt(()=>setDisplayMode(false));return;}
    if(isLive)window.CourtlineSettingsLock?.relock();
    displayMode = isLive;
    document.body.classList.toggle('display-mode', displayMode);
    arrangeSettingsCourts(displayMode);
    settingsButton.textContent = displayMode ? 'Settings' : 'Back to Live';
    settingsButton.title = displayMode ? 'Open settings' : 'Return to live monitor';
    window.dispatchEvent(new Event('courtline-view-change'));
  }
  window.courtlineGoLive=()=>setDisplayMode(true);
  setDisplayMode(isViewer);
  autoCheckbox.addEventListener('change',()=>{autoRefresh=autoCheckbox.checked;nextPollAt=Date.now()+REFRESH_INTERVAL_MS;save();updateStatus();});
  settingsButton.addEventListener('click',()=>setDisplayMode(!displayMode));
  refreshButton.addEventListener('click',()=>checkAll());
  assignmentApply.addEventListener('click',applyPendingChanges);
  document.addEventListener('keydown',event=>{
    if (/INPUT|SELECT|TEXTAREA/.test(document.activeElement?.tagName || '')) return;
    if(event.key.toLowerCase()==='r') checkAll();
    if(event.key.toLowerCase()==='d') {setDisplayMode(!displayMode);}
    if(event.key==='Escape' && displayMode) {setDisplayMode(false);}
  });
  function updateClock() {
    const now = new Date();
    document.getElementById('timeDisplay').textContent=now.toLocaleTimeString([],{hour:'numeric',minute:'2-digit'});
    document.getElementById('dateDisplay').textContent=now.toLocaleDateString([],{month:'short',day:'numeric',year:'numeric'});
    if(autoRefresh && !activeRequest && Date.now()>=nextPollAt) checkAll();
    updateAlertTimer();
    updateStatus();
  }
  setInterval(updateClock,1000);
  updateClock();
  // Only the main iPad may originate match/assignment data.
  window.captureCompanionState=()=>({courts:results.map(row=>row||resultForEmpty()),visibleCourts:visibleCourts.slice(),vmixAddress:vmixHost});
  window.renderCompanionSnapshot=snapshot=>{
    if(!isViewer||!Array.isArray(snapshot.courts)||snapshot.courts.length!==4)return;
    for(let i=0;i<4;i++){
      visibleCourts[i]=snapshot.visibleCourts?.[i]!==false;
      const value=snapshot.courts[i];
      if(value&&typeof value==='object')commitResult(i,value);
    }
    updateCourtVisibility();syncCompletedAt=new Date();pollHadError=false;
    connectionText.textContent='Viewing the main CourtLine device';
    connectionDetail.textContent='Live Stats · Read-only companion';
    lastSync.textContent='Synchronized from main CourtLine';
  };
  if(!isViewer)checkAll();
});
