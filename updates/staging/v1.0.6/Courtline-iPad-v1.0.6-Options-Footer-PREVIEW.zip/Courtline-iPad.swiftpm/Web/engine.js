'use strict';
(() => {
 const pending=new Map();let serial=0;
 window.platformReply=(id,value,error)=>{const p=pending.get(id);if(!p)return;clearTimeout(p.timer);pending.delete(id);error?p.reject(new Error(error)):p.resolve(value);};
 function call(method,...args){return new Promise((resolve,reject)=>{const fileOperation=['exportSettings','importSettings','statsHelper','scanStatsHelper'].includes(method);const id=String(++serial),timer=setTimeout(()=>{pending.delete(id);reject(new Error(fileOperation?'Settings file operation timed out.':'iPad request timed out; command was not retried.'));},fileOperation?300000:30000);pending.set(id,{resolve,reject,timer});try{CourtlineNative[method](id,...args);}catch(e){clearTimeout(timer);pending.delete(id);reject(e);}});}
 const defaults=()=>({dry_run:true,poll_seconds:.5,alarm_delay:5,rows:[]});
 let config=JSON.parse(CourtlineNative.load());config.ui||={};config.browser='';config.profiles=Array.from({length:4},(_,i)=>({...defaults(),...config.profiles?.[i]}));
 if(!config.ui.vmixHost||/localhost|127\.0\.0\.1/.test(config.ui.vmixHost))config.ui.vmixHost='http://192.168.1.100:8088';
 config.telestrator_profiles=Array.from({length:4},(_,i)=>({...defaults(),...config.telestrator_profiles?.[i]}));
 const slots=Array.from({length:4},()=>({armed:false,running:false,paused:false,url:'',status:{},alarms:[],logs:[],round:null,pair:null,blank:0,generation:0,jobs:[],telestratorGeneration:0,manualSending:0,reading:false,nextRead:0}));
 const save=()=>{if(!CourtlineNative.save(JSON.stringify(config)))throw new Error('Could not save tablet settings');};
 const log=(s,message)=>{s.logs.push({simple:message,advanced:new Date().toLocaleTimeString()+' '+message});if(s.logs.length>150)s.logs.shift();};
 function alarm(s,kind,title,hint,delay=0){if(kind!=='vmix_error'&&s.alarms.some(a=>a.kind===kind))return;s.alarms.push({id:crypto.randomUUID(),kind,title,hint,visible_at:Date.now()+delay*1000});}
 const blocked=s=>s.alarms.some(a=>a.kind==='match_started'||a.kind==='match_complete');
 function base(address){const u=new URL(address);if(!['http:','https:'].includes(u.protocol)||u.username||u.password||u.search||u.hash||!['','/'].includes(u.pathname))throw new Error('Use http://PC-IP:8088 without a path.');if(['localhost','127.0.0.1','[::1]'].includes(u.hostname))throw new Error('Use the vMix computer’s Wi-Fi/LAN IP, not localhost.');return u.origin;}
 function widget(url){const u=new URL(url);if(u.protocol!=='https:'||u.hostname!=='app.scoreholio.com'||u.username||u.password)throw new Error('Use a Scoreholio HTTPS widget URL.');return u.href;}
 function commandQuery(command){command=String(command).trim();const p=new URLSearchParams(/^Function=/i.test(command)?command:'Function='+command);const functions=[...p].filter(([k])=>k.toLowerCase()==='function');if(functions.length!==1||!functions[0][1].trim())throw new Error('Enter exactly one vMix Function.');return p.toString();}
 let commandChain=Promise.resolve();
 function send(i,command,address,guard=()=>true){
   const query=commandQuery(command),host=base(address);
   const work=commandChain.catch(()=>{}).then(async()=>{if(!guard())return 'Canceled';const r=await call('request',host+'/api/?'+query,'GET','','');if(r.status<200||r.status>=300)throw new Error('vMix HTTP '+r.status);log(slots[i],'vMix accepted: '+command);return 'Accepted by vMix';}).catch(e=>{log(slots[i],e.message);alarm(slots[i],'vmix_error','vMix COMMAND FAILED',e.message+' — not automatically retried.');throw e;});commandChain=work;return work;
 }
 function baseline(s){s.round=null;s.pair=null;s.blank=0;}
 function validateProfile(p){if(!Number.isFinite(p.poll_seconds)||p.poll_seconds<.25||p.poll_seconds>10||!Number.isFinite(p.alarm_delay)||p.alarm_delay<0||p.alarm_delay>60)throw new Error('Check poll and alarm delays.');for(const r of p.rows){if(!Number.isFinite(r.delay)||r.delay<0||r.delay>3600)throw new Error('Shortcut delay must be 0–3600 seconds.');if(r.command)commandQuery(r.command);}}
 function queueButton(i,source){
   const s=slots[i];if(!s)throw new Error('Invalid court.');
   if(s.manualSending||s.jobs.some(j=>j.manual))throw new Error('Button commands are already pending for this court.');
   const profile=source==='telestrator'?config.telestrator_profiles[i]:config.profiles[i];
   const rows=profile.rows.filter(r=>r.enabled&&r.command&&r.trigger==='Button press');
   if(!rows.length)throw new Error(source==='telestrator'?'Configure and apply this court’s Telestrator button settings first.':'Add and apply an enabled Button press shortcut for this court first.');
   base(config.ui.vmixHost);rows.forEach(r=>commandQuery(r.command));
   const label=source==='telestrator'?'Telestrator Court '+(i+1)+' button':'Manual button press';
   rows.forEach(r=>s.jobs.push({id:r.id,trigger:'Button press',label,source,manual:true,buttonGeneration:s.telestratorGeneration,elapsed:0,generation:s.generation}));
   log(s,label+' — '+rows.length+' command(s) queued'+(profile.dry_run?' [DRY RUN]':'')+'.');
   return rows.length+' command(s) queued'+(profile.dry_run?' [DRY RUN]':'')+'.';
 }
 function stop(i){const s=slots[i];s.armed=s.running=s.paused=false;s.generation++;s.jobs=[];baseline(s);CourtlineNative.open(i,'');s.status.page={state:'stopped'};}
 function start(i){const s=slots[i];s.armed=true;s.paused=false;if(s.running)return;if(s.url){s.running=true;s.generation++;baseline(s);CourtlineNative.open(i,s.url);s.status.page={state:'connecting'};}log(s,s.url?'Monitoring started.':'Armed — waiting for assignment.');}
 function fire(i,trigger,label){const s=slots[i];if(trigger!=='Match complete'&&blocked(s)){log(s,label+' — shortcuts suppressed until alarms are acknowledged.');return;}for(const r of config.profiles[i].rows){if(r.enabled&&r.command&&r.trigger===trigger)s.jobs.push({id:r.id,trigger,label,elapsed:0,generation:s.generation});}log(s,label);}
 const labels=new Set(['PPR','4IN','IN','ON','OFF','SCORE','SCOREHOLIO','OVERLAY']);
 function parse(text){const match=text.match(/\bRound\s*:\s*(\d+)\b/i),names=[];for(let line of text.split(/\r?\n/)){line=line.replace(/\s+/g,' ').replace(/^[ :|]+|[ :|]+$/g,'');if(!line||/^[+-]?\d+(?:[.,]\d+)?$/.test(line)||/^Round\s*:/i.test(line)||labels.has(line.toUpperCase())||!/[\p{L}]/u.test(line))continue;if(!names.includes(line))names.push(line);if(names.length===2)break;}return {round:match?Number(match[1]):null,pair:names.length===2?JSON.stringify(names.sort((a,b)=>a.toLowerCase().localeCompare(b.toLowerCase()))):null};}
 function ingest(i,text){const s=slots[i],p=parse(text);
   // Track name disappearance even when the completed widget no longer shows Round.
   let complete=false;
   if(p.pair){complete=!!s.pair&&s.pair!==p.pair;s.pair=p.pair;s.blank=0;}
   else if(s.pair&&++s.blank>=3){complete=true;s.pair=null;s.blank=0;}
   if(complete){alarm(s,'match_complete','MATCH COMPLETE','Detected from changed or blank widget names.',config.profiles[i].alarm_delay);fire(i,'Match complete','Match complete');s.round=null;}
   if(p.round!==null){if(s.round!==null&&p.round>s.round){if(s.round===1&&p.round>=2)alarm(s,'match_started','MATCH HAS STARTED','Set your camera/input, then acknowledge.');for(let round=s.round+1;round<=p.round;round++)fire(i,'Round complete','Round '+round+' complete');}s.round=p.round;}
   s.status.page={state:'connected'};
 }
 let healthBusy=false;
 setInterval(async()=>{if(healthBusy||!slots.some(s=>s.running))return;healthBusy=true;try{await api.vmix_health(config.ui.vmixHost);slots.forEach(s=>s.status.vmix={state:'connected'});}catch(e){slots.forEach(s=>s.status.vmix={state:'unavailable',detail:e.message});}finally{healthBusy=false;}},5000);
 const api={
   get_config:async()=>JSON.parse(JSON.stringify(config)),
   scan_stats_helper:()=>call('scanStatsHelper'),
   switch_companion:code=>call('switchCompanion',code),
   stats_helper:(url,refresh=false)=>call('statsHelper',url,refresh),
   settings_lock:(url,value)=>call('settingsLock',url,value),
   companion:(url,action,payload={})=>call('companion',url,action,payload),
   stats_assignments:(url,assignments)=>call('statsAssignments',url,assignments),
   export_settings:text=>call('exportSettings',text),
   pick_settings:()=>call('importSettings'),
   restore_settings:async value=>{
     const restored=window.CourtlineBackup.normalize(value);
     slots.forEach((s,i)=>stop(i));
     await call('persistSettings',JSON.stringify(restored));
     config=restored;
     return true;
   },
   persist_ui:async ui=>{await call('persistSettings',JSON.stringify({...config,ui}));config.ui=ui;return true;},
   save_ui:async ui=>{const prior=config.ui.vmixHost;config.ui=ui;save();if(prior!==ui.vmixHost)slots.forEach(s=>{s.jobs=[];s.generation++;});return true;},
   save_profile:async(i,p)=>{validateProfile(p);config.profiles[i]=p;save();return p;},
   save_telestrator_profile:async(i,p)=>{if(!slots[i])throw new Error('Invalid court.');validateProfile(p);if(p.rows.some(r=>r.trigger!=='Button press'))throw new Error('Telestrator rows must use Button press.');config.telestrator_profiles[i]=p;slots[i].telestratorGeneration++;slots[i].jobs=slots[i].jobs.filter(j=>j.source!=='telestrator');save();return p;},
   set_assignment:async(i,url)=>{const s=slots[i],u=url?widget(url):'';if(u!==s.url){const armed=s.armed;stop(i);s.url=u;s.armed=armed;log(s,'Assignment changed; queued commands canceled.');if(armed)start(i);}return true;},
   control:async(i,action)=>{const s=slots[i];if(action==='start'){if(s.paused)baseline(s);start(i);}else if(action==='stop')stop(i);else if(action==='pause'){s.paused=true;log(s,'Paused.');}else if(action==='resume'){s.paused=false;baseline(s);log(s,'Resumed; events during pause skipped.');}return true;},
   state:async()=>slots.map((s,i)=>({...s,dry_run:config.profiles[i].dry_run,telestrator_count:config.telestrator_profiles[i].rows.filter(r=>r.enabled&&r.command).length,telestrator_dry_run:config.telestrator_profiles[i].dry_run,manual_count:config.profiles[i].rows.filter(r=>r.enabled&&r.command&&r.trigger==='Button press').length,manual_busy:s.manualSending>0||s.jobs.some(j=>j.manual),blocked:blocked(s),alarms:s.alarms.filter(a=>a.visible_at<=Date.now())})),
   manual_trigger:async i=>queueButton(i,'manual'),
   telestrator_trigger:async i=>queueButton(i,'telestrator'),
   // Unlike the queueing button, a shared court switch resolves only after
   // vMix accepts every configured command, so the Helper can safely confirm it.
   telestrator_switch:async i=>{
     const s=slots[i],profile=config.telestrator_profiles[i];
     if(!s||!profile)throw new Error('Invalid court.');
     if(s.manualSending||s.jobs.some(j=>j.manual))throw new Error('This court already has pending button commands.');
     const source=typeof config.ui.telestratorSources?.[i]==='string'?config.ui.telestratorSources[i].trim():'';
     if(source.length>120)throw new Error('Invalid Telestrator Output 2 camera source.');
     const rows=profile.rows.filter(r=>r.enabled&&r.command&&r.trigger==='Button press');
     // Test LIVE sends these same rows directly even when Output 2 has a source.
     // A court selection must not silently skip user-configured live shortcuts.
     // Dry run still applies: switching Output 2 is allowed, but shortcuts are skipped.
     if(!source&&!rows.length)throw new Error('Configure Court '+(i+1)+' Output 2 input or an enabled Telestrator shortcut.');
     if(!source&&profile.dry_run)throw new Error('Turn off Dry run for this court’s Telestrator shortcut.');
     base(config.ui.vmixHost);
     if(!profile.dry_run)rows.forEach(r=>commandQuery(r.command));
     const generation=s.generation,buttonGeneration=s.telestratorGeneration;
     const stillCurrent=()=>s.generation===generation&&s.telestratorGeneration===buttonGeneration;
     s.manualSending++;
     try{
       if(source){
         const query=new URLSearchParams({Function:'SetOutput2',Value:'Input',Input:source}).toString();
         const outcome=await send(i,query,config.ui.vmixHost,stillCurrent);
         if(outcome!=='Accepted by vMix')throw new Error('Output 2 switch canceled.');
       }
       // Court switches are immediate, just like Test LIVE; queued shortcut delays
       // are not used while switching the shared telestrator court.
       if(!profile.dry_run){
         for(const row of rows){
           const outcome=await send(i,row.command,config.ui.vmixHost,()=>stillCurrent()&&!config.telestrator_profiles[i].dry_run);
           if(outcome!=='Accepted by vMix')throw new Error('Court switch canceled before reaching vMix.');
         }
       }
       return 'Court '+(i+1)+' Output 2'+(source?' set to '+source:' unchanged')+
         (rows.length?(profile.dry_run?' · legacy shortcuts skipped (Dry run)':' · '+rows.length+' Telestrator shortcut(s) sent'):'')+'.';
     }finally{s.manualSending--;}
   },
   acknowledge:async(i,id)=>{const s=slots[i];s.alarms=s.alarms.filter(a=>a.id!==id);log(s,'Alert acknowledged.');return true;},
   fetch_scoreholio:(url,method='GET',body='',type='')=>call('request',url,method,body||'',type||''),
   vmix_health:async address=>{const r=await call('request',base(address)+'/api/','GET','','');if(r.status!==200||!/<vmix[\s>]/i.test(r.text))throw new Error('The address did not return vMix XML.');return 'Connected — vMix API verified';},
   send_command:(i,c,a)=>send(i,c,a),
   send_widget:(i,input,url,address)=>{if(!String(input).trim())throw new Error('Set the vMix input first.');return send(i,new URLSearchParams({Function:'BrowserNavigate',Input:input,Value:widget(url)}).toString(),address);},
   shortcut_catalog:async()=>window.VmixShortcutCatalog.categories
 };
 window.pywebview={api};
 window.platformSuspend=()=>{slots.forEach((s,i)=>{const active=s.armed||s.jobs.some(j=>j.manual)||s.manualSending;stop(i);if(active)log(s,'Monitoring and pending commands stopped because Courtline left the foreground. Press Start to resume monitoring.');});};
 let previous=performance.now();
 setInterval(()=>{const now=performance.now(),dt=Math.min(1000,now-previous);previous=now;slots.forEach((s,i)=>{
   if(s.running&&!s.paused&&!s.reading&&now>=s.nextRead){s.reading=true;s.nextRead=now+config.profiles[i].poll_seconds*1000;const generation=s.generation;call('snapshot',i).then(r=>{if(s.running&&!s.paused&&s.generation===generation&&r.url===s.url)ingest(i,r.text);}).catch(e=>{if(s.generation===generation)s.status.page={state:'waiting',detail:e.message};}).finally(()=>s.reading=false);}
   s.jobs=s.jobs.filter(j=>{
     const profile=j.source==='telestrator'?config.telestrator_profiles[i]:config.profiles[i];
     const r=profile.rows.find(r=>r.id===j.id);
     if(j.generation!==s.generation||!r?.enabled||!r.command||r.trigger!==j.trigger||(!j.manual&&j.trigger!=='Match complete'&&blocked(s)))return false;
     if(!j.manual&&(!s.running||s.paused))return true;
     j.elapsed+=dt/1000;if(j.elapsed<r.delay)return true;
     if(profile.dry_run)log(s,'[DRY RUN] '+j.label+' → '+r.command);
     else {const generation=s.generation;if(j.manual)s.manualSending++;
       send(i,r.command,config.ui.vmixHost,()=>s.generation===generation&&(j.source!=='telestrator'||s.telestratorGeneration===j.buttonGeneration)&&!(j.source==='telestrator'?config.telestrator_profiles[i]:config.profiles[i]).dry_run&&(j.manual||(s.running&&!s.paused&&(j.trigger==='Match complete'||!blocked(s))))).catch(()=>{}).finally(()=>{if(j.manual)s.manualSending--;});
     }return false;
   });
 });},100);
 document.addEventListener('DOMContentLoaded',()=>window.dispatchEvent(new Event('pywebviewready')));
 // Expose pure detector only for offline regression tests.
 window.CourtlineDetector={parse,ingest,slots,config};
})();
