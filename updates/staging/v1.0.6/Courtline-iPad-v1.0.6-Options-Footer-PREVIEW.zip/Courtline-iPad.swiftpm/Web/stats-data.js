'use strict';
window.ScoreholioStatsData=(()=>{
  const metrics=['PPR','DPR','OPP PPR','4IN','4IN %','IN','IN %','ON','ON %','OFF','OFF %','Rounds','Total Points','Opp Points'];
  const extraMetrics=['SPR','Overall PPR','Overall DPR','Global Rank','Qualifying Record','Qualifying Record Scope','Bracket Record','Bracket Record Scope'];
  const key=name=>String(name||'').normalize('NFKC').trim().replace(/\s+/g,' ').toLowerCase();
  function event(text){
    const u=new URL(text);
    if(!['http:','https:'].includes(u.protocol)||!u.hostname||['localhost','127.0.0.1','[::1]'].includes(u.hostname)||u.username||u.password||u.hash||u.pathname!=='/api/stats'||!u.searchParams.get('key'))throw Error('Paste the helper’s iPad address from the PC dashboard.');
    return {url:u.href};
  }
  function snapshot(value,allowBundle=true){
    if(allowBundle&&value?.events!==undefined){if(!Array.isArray(value.events)||!value.events.length||value.events.length>4)throw Error('Invalid helper event list.');const events=value.events.map(v=>snapshot(v,false));return {...events[0],events,helperError:value.helperStatus?.lastError||''};}
    if(value?.format!=='courtline-stats'||value.version!==1||!value.event?.account||!value.event?.game||!Number.isFinite(Date.parse(value.exportedAt))||!Array.isArray(value.records)||!value.records.length||value.records.length>20000)throw Error('Invalid helper stats snapshot.');
    const records=value.records.map(r=>{const clean={};for(const k of ['Display Name','Game Name',...metrics]){if(typeof r[k]!=='string'||r[k].length>1000)throw Error('Invalid player stats field.');clean[k]=r[k];}for(const k of extraMetrics){if(r[k]!==undefined&&(typeof r[k]!=='string'||r[k].length>1000))throw Error('Invalid roster or standings field.');clean[k]=r[k]||'';}return clean;});
    return {account:value.event.account,game:value.event.game,at:value.exportedAt,records,helperError:value.helperStatus?.lastError||''};
  }
  function assignment(index,result){
    if(result?.kind!=='assigned'||result.sourceType!=='managed')return null;
    try{const u=new URL(result.widgetUrl),account=u.searchParams.get('account'),game=u.searchParams.get('game');if(u.protocol!=='https:'||u.hostname!=='app.scoreholio.com'||!account||!game)return null;return {slot:index,account,game,name:String(result.name||'')};}catch(_){return null;}
  }
  function forCourt(cached,account,game){return (cached?.events||[cached]).find(event=>event&&event.account===account&&event.game===game)||null;}
  function exportStatus(cached,account,game){
    const data=forCourt(cached,account,game);
    if(!data)return 'No successful export for this court’s current event yet.';
    return 'Last successful export: '+new Date(data.at).toLocaleString()+' · '+data.records.length+' players'+(data.helperError?' · PC export error: '+data.helperError:'');
  }
  function parse(text){
    if(typeof text!=='string'||text.length>4000000)throw Error('Stats CSV is missing or too large.');
    const rows=[];let row=[],cell='',quoted=false;
    text=text.replace(/^\uFEFF/,'');
    for(let i=0;i<text.length;i++){
      const c=text[i];
      if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;}
      else if(c===','&&!quoted){row.push(cell);cell='';}
      else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(v=>v.trim()))rows.push(row);row=[];cell='';}
      else cell+=c;
    }
    if(quoted)throw Error('Incomplete CSV export.');
    row.push(cell);if(row.some(v=>v.trim()))rows.push(row);
    const headers=rows.shift()?.map(v=>v.trim())||[];
    for(const field of ['Display Name','Game Name',...metrics])if(!headers.includes(field))throw Error('Export is missing '+field+'.');
    const records=rows.map(values=>{if(values.length!==headers.length)throw Error('Invalid CSV row.');return Object.fromEntries(headers.map((h,i)=>[h,values[i].trim()]));});
    if(!records.length)throw Error('The event export has no player stats yet.');
    return records.map(r=>Object.fromEntries(['Display Name','First Name','Last Name','Game Name',...metrics].map(k=>[k,r[k]||''])));
  }
  function match(records,name){const matches=records.filter(r=>key(r['Display Name'])===key(name));return matches.length===1?matches[0]:null;}
  function bestValues(records){
    const directions={'PPR':'max','4IN':'max','4IN %':'max','IN':'max','IN %':'max','ON':'max','ON %':'max','DPR':'max','OPP PPR':'min','OFF':'min','OFF %':'min'};
    const numeric=value=>{if(typeof value!=='string'||!/^[-+]?(?:\d+(?:\.\d*)?|\.\d+)\s*%?$/.test(value.trim()))return null;const n=Number(value.trim().replace(/\s*%$/,''));return Number.isFinite(n)?n:null;};
    const best={};
    for(const [metric,direction] of Object.entries(directions)){
      const values=records.map(r=>r?numeric(r[metric]):null).filter(n=>n!==null);
      if(values.length)best[metric]=direction==='min'?Math.min(...values):Math.max(...values);
    }
    return {isBest:(record,metric)=>record&&Object.hasOwn(best,metric)&&numeric(record[metric])===best[metric],values:best};
  }
  async function persist(ui,api,host=window){
    // Queue the freshly collected fields, then wait for native disk-save acknowledgment.
    host.desktopSaveUI(ui);
    await host.desktopFlushUI();
    await api.persist_ui(ui);
    host.localStorage.setItem('courtline-scoreholio-v2',JSON.stringify(ui));
  }
  return {metrics,extraMetrics,key,event,parse,match,snapshot,persist,bestValues,forCourt,assignment,exportStatus};
})();
window.addEventListener('courtline-ready',()=>{
  const D=window.ScoreholioStatsData,api=window.pywebview.api;
  const url=document.getElementById('statsHelperURL'),auto=document.getElementById('statsAutoRefresh'),interval=document.getElementById('statsRefreshSeconds');
  const status=document.getElementById('scoreholioStatsStatus'),liveStatus=document.getElementById('statsRefreshStatus');
  let cached=null,busy=false,paused=false,next=Date.now()+5000;
  const config=JSON.parse(localStorage.getItem('courtline-scoreholio-v2')||'{}').scoreholioStats||{};
  let savedHelperURL=config.helperURL||'',syncBusy=false,syncTimer=null;const desired=new Map();
  async function syncAssignments(){
    if(window.CourtlineCompanion?.role==='viewer')return;
    if(syncBusy||document.hidden||!desired.size||!savedHelperURL||url.value.trim()!==savedHelperURL)return;
    syncBusy=true;
    try{const target=D.event(savedHelperURL);await api.stats_assignments(target.url,[...desired.values()]);}
    catch(e){if(!busy)say('Event sync: '+e.message);}
    finally{syncBusy=false;}
  }
  function scheduleSync(){clearTimeout(syncTimer);syncTimer=setTimeout(syncAssignments,750);}
  setInterval(syncAssignments,15000);
  url.value=config.helperURL||'';auto.checked=!!config.helperURL&&config.auto===true;interval.value=config.helperURL?(config.seconds||10):10;
  if(window.CourtlineCompanion?.role==='viewer'&&config.helperURL)auto.checked=true;
  try{cached=JSON.parse(localStorage.getItem('courtline-stats-cache-v1')||'null');if(cached&&!Array.isArray(cached.records))cached=null;}catch(_){cached=null;}
  window.collectStatsSettings=()=>({helperURL:url.value.trim(),auto:auto.checked,seconds:Math.max(5,Math.min(3600,Number(interval.value)||10))});
  function say(text){status.textContent=text;liveStatus.textContent=text;}
  function updateLiveStatus(){
    const panel=document.querySelector('.stats-court-page:not([hidden])');
    if(panel)liveStatus.textContent=D.exportStatus(cached,panel.dataset.statsAccount,panel.dataset.statsGame);
  }
  window.refreshStatsCourtStatus=updateLiveStatus;
  function render(){
    updateLiveStatus();
    document.querySelectorAll('.stats-court-page').forEach(panel=>{
      const courtData=D.forCourt(cached,panel.dataset.statsAccount,panel.dataset.statsGame);const same=!!courtData;
      const players=[...panel.querySelectorAll('.stats-player')];
      const courtRecords=players.map(player=>same?D.match(courtData.records,player.querySelector('h3').textContent):null);
      const leaders=D.bestValues(courtRecords);
      players.forEach((player,index)=>{
        const name=player.querySelector('h3').textContent,area=player.querySelector('.stats-player-values');
        const record=courtRecords[index];
        const badge=player.querySelector('.stats-spr');badge.hidden=!record;badge.textContent=record?'SPR '+(record.SPR||'—'):'';
        const current=panel.currentMatchStats?.[index]||null;
        const signature=JSON.stringify([name,record,cached?.at,same,leaders.values,current]);if(area.dataset.signature===signature)return;area.dataset.signature=signature;area.replaceChildren();
        const currentRow=document.createElement('div');currentRow.className='stats-current-row';
        const currentHeading=document.createElement('h4');currentHeading.textContent='Current Game';
        const currentList=document.createElement('dl');currentList.className='stats-metrics stats-current-metrics';
        for(const metric of ['PPR','4IN','IN','ON','OFF']){const group=document.createElement('div'),label=document.createElement('dt'),value=document.createElement('dd');group.className='stats-metric';label.textContent=metric;value.textContent=current?.[metric]??'—';group.append(label,value);currentList.append(group);}
        currentRow.append(currentHeading,currentList);area.append(currentRow);
        const eventRow=document.createElement('div');eventRow.className='stats-event-row';const eventHeading=document.createElement('h4');eventHeading.textContent='Event Stats';eventRow.append(eventHeading);area.append(eventRow);
        if(!record){const message=document.createElement('p');message.textContent=name==='Waiting for player'?'':same?'No unique player match in this export.':'Refresh stats for this event to load player totals.';eventRow.append(message);return;}
        const records=document.createElement('div');records.className='stats-record-oval';records.setAttribute('aria-label','Event records');
        [['Qualifying Record','Round Robin','W–L–T'],['Bracket Record','Bracket Play','W–L']].forEach(([field,title,format])=>{
          const group=document.createElement('div'),label=document.createElement('span'),value=document.createElement('strong'),scope=document.createElement('small');
          label.textContent=title;value.textContent=record[field]||'—';scope.textContent=(record[field+' Scope']==='Team'?'Team · ':'')+format;
          group.title=title+' · '+scope.textContent;group.setAttribute('aria-label',group.title+' · '+value.textContent);group.append(label,value);records.append(group);
        });
        const list=document.createElement('dl');list.className='stats-metrics';
        const fields=D.metrics.filter(metric=>!['Rounds','Total Points','Opp Points'].includes(metric));
        const labels={'4IN':'4IN','4IN %':'4IN %','OPP PPR':'OPP PPR'};const fullLabels={'4IN':'Total Four Baggers','4IN %':'Four Bagger %','OPP PPR':'Opponent PPR'};
        fields.forEach(metric=>{const group=document.createElement('div'),label=document.createElement('dt'),value=document.createElement('dd');const best=leaders.isBest(record,metric);group.className=best?'stats-metric stats-metric-featured':'stats-metric';if(best)group.title='Best on this court (ties included)';label.textContent=labels[metric]||metric;label.title=fullLabels[metric]||metric;value.textContent=record[metric]||'—';group.append(label,value);list.append(group);});
        eventRow.append(records);area.append(list);
      });
    });
  }
  window.updatePlayerStats=(index,result)=>{
    const panel=document.getElementById('statsCourt'+(index+1));let u;
    try{u=new URL(result.widgetUrl);}catch(_){}
    const row=D.assignment(index,result),old=JSON.stringify(desired.get(index)||null);
    if(row)desired.set(index,row);else if(result.kind!=='error')desired.delete(index);
    if(old!==JSON.stringify(desired.get(index)||null))scheduleSync();
    panel.currentMatchStats=[0,1].flatMap(team=>[0,1].map(player=>result.matchup?.[team]?.matchStats?.[player]||null));
    panel.dataset.statsAccount=u?.searchParams.get('account')||'';panel.dataset.statsGame=u?.searchParams.get('game')||'';render();
  };
  async function save(){await D.persist(window.desktopCollectUI(),api);savedHelperURL=url.value.trim();scheduleSync();next=Date.now()+window.collectStatsSettings().seconds*1000;}
  [url,auto,interval].forEach(input=>input.addEventListener('change',()=>save().catch(e=>say(e.message))));
  async function refresh(force=true){
    if(busy||paused)return;
    busy=true;document.querySelectorAll('[data-refresh-stats]').forEach(b=>b.disabled=true);
    try{
      const target=D.event(url.value.trim());const viewer=window.CourtlineCompanion?.role==='viewer';if(!viewer)await save();force=force&&!viewer;say(force?'PC helper is exporting stats, roster and standings…':'Reading the PC snapshot…');
      const value=await api.stats_helper(target.url,force);
      const fresh=D.snapshot(value);cached=fresh;
      try{localStorage.setItem('courtline-stats-cache-v1',JSON.stringify(cached));}catch(_){}
      say('Stats snapshots updated.'+(cached.helperError?' · PC export error: '+cached.helperError:''));render();
    }catch(e){say(e.message+(cached?' · Last successful data retained.':''));if(auto.checked){auto.checked=false;if(window.CourtlineCompanion?.role!=='viewer')await save().catch(()=>{});}}
    finally{busy=false;next=Date.now()+window.collectStatsSettings().seconds*1000;document.querySelectorAll('[data-refresh-stats]').forEach(b=>b.disabled=false);}
  }
  document.querySelectorAll('[data-refresh-stats]').forEach(b=>b.addEventListener('click',()=>refresh(true)));
  window.saveScannedStatsHelper=async text=>{const target=D.event(text);url.value=target.url;await save();target.role=await window.CourtlineCompanion?.identify(target.url);return target;};
  document.getElementById('scanStatsHelper').addEventListener('click',async()=>{
    if(busy)return;
    busy=true;say('Scan the QR code on your PC helper dashboard.');
    try{
      const text=await api.scan_stats_helper();
      if(text===null){say('Scan canceled.');return;}
      const target=D.event(text);url.value=target.url;await save();
      if(await window.CourtlineCompanion?.identify(target.url)==='viewer'){location.reload();return;}
      say('Helper QR pairing saved. Reading the latest PC snapshot…');
      cached=D.snapshot(await api.stats_helper(target.url,false));
      try{localStorage.setItem('courtline-stats-cache-v1',JSON.stringify(cached));}catch(_){}
      say('Helper connected. Stats snapshots loaded.');render();
    }catch(e){say(e.message);}
    finally{busy=false;next=Date.now()+window.collectStatsSettings().seconds*1000;}
  });
  window.addEventListener('courtline-monitoring-stopped',()=>{paused=true;say('Auto stats refresh paused after leaving the app. Export & Refresh Now to resume.');});
  document.querySelectorAll('[data-refresh-stats]').forEach(b=>b.addEventListener('click',()=>{paused=false;} ,true));
  setInterval(()=>{if(auto.checked&&!paused&&!document.hidden&&Date.now()>=next)refresh(false);},1000);
  if(cached)say('Event totals · Last saved '+new Date(cached.at).toLocaleString());
  render();
  if(window.CourtlineCompanion?.role==='viewer'&&url.value)setTimeout(()=>refresh(false),1000);
});
