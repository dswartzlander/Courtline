'use strict';
// A native browser occupies this reserved rectangle, avoiding iframe restrictions.
document.addEventListener('DOMContentLoaded', () => {
  const viewport = document.getElementById('telestratorViewport');
  const status = document.getElementById('telestratorStatus');
  const settingsDialog = document.getElementById('telestratorSettingsDialog');
  const openSettings = document.getElementById('openTelestratorSettings');
  const closeSettings = document.getElementById('closeTelestratorSettings');
  const names = ['courts','stats','telestrator'];
  const availableNames = () => document.body.classList.contains('companion-viewer') ? ['stats','telestrator'] : names;
  const tabs = names.map(name=>document.getElementById(name+'Tab'));
  const statsButtons = [1,2,3,4].map(i=>document.getElementById('statsCourtTab'+i));
  function selectStatsCourt(index) {
    const title=document.getElementById('statsCourtTitle');
    if(title)title.textContent='Court '+String(index+1).padStart(2,'0')+' Stats';
    const tournamentTitle=document.getElementById('statsTournamentTitle');
    if(tournamentTitle)tournamentTitle.textContent=document.getElementById('statsCourt'+(index+1)).dataset.statsTournament||'Tournament not assigned';
    statsButtons.forEach((button,i)=>{
      const active=i===index;
      button.setAttribute('aria-selected',String(active));button.tabIndex=active?0:-1;
      document.getElementById('statsCourt'+(i+1)).hidden=!active;
    });
    window.refreshStatsCourtStatus?.();
  }
  // Local-only, one-way link: a Telestrator court choice also prepares Stats.
  // Do not publish this Stats choice to the Helper or feed Stats choices back to Telestrator.
  window.courtlineSelectLocalStatsCourt = index => {
    if (!Number.isInteger(index) || index < 0 || index >= statsButtons.length) return;
    selectStatsCourt(index);
  };
  statsButtons.forEach((button,i)=>{
    button.addEventListener('click',()=>selectStatsCourt(i));
    button.addEventListener('keydown',event=>{
      if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
      event.preventDefault();
      const target=event.key==='Home'?0:event.key==='End'?3:(i+(event.key==='ArrowRight'?1:3))%4;
      selectStatsCourt(target);statsButtons[target].focus();
    });
  });
  let selected = 'courts';
  document.body.dataset.liveTab = selected;
  function selectTab(name) {
    // A Companion has no Courts page; the court data still synchronizes in the background.
    if(!availableNames().includes(name))name='stats';
    selected = name;
    document.body.dataset.liveTab = name;
    tabs.forEach((tab,i)=>{
      const active = names[i]===name;
      tab.setAttribute('aria-selected',String(active));
      tab.tabIndex = active ? 0 : -1;
      if(names[i]==='courts')tab.hidden=document.body.classList.contains('companion-viewer');
    });
    if (settingsDialog.open) settingsDialog.close();
    update();
  }
  tabs.forEach((tab,i)=>{
    tab.addEventListener('click',()=>selectTab(names[i]));
    tab.addEventListener('keydown',event=>{
      if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
      event.preventDefault();
      const visible=availableNames(),position=visible.indexOf(names[i]);
      if(position<0)return;
      const target = event.key==='Home'?0:event.key==='End'?visible.length-1:(position+(event.key==='ArrowRight'?1:visible.length-1))%visible.length;
      selectTab(visible[target]);document.getElementById(visible[target]+'Tab').focus();
    });
  });
  window.addEventListener('courtline-ready',()=>{
    if(!availableNames().includes(selected))selectTab('stats');
    else selectTab(selected);
  });
  window.updateCourtAlertCount = count => {
    document.getElementById('courtAlertCount').textContent = count ? '('+count+' alert'+(count===1?'':'s')+')' : '';
  };
  let pending = false;
  // Court changes can arrive while a tab or settings dialog hides the native browser.
  // Remember the refresh request and use it once the viewport becomes visible.
  let courtReloadQueued = false;
  window.courtlineReloadTelestrator = () => {
    courtReloadQueued = true;
    update();
  };
  window.telestratorStatus = text => { status.textContent = text; status.title = text; };
  function update(reload = false) {
    pending = false;
    if (reload) courtReloadQueued = true;
    const rect = viewport.getBoundingClientRect();
    const visible = selected === 'telestrator' && !document.body.classList.contains('theme-menu-open') && document.body.classList.contains('display-mode') &&
      document.getElementById('assignmentAlert').hidden && !document.querySelector('dialog[open]') &&
      rect.width > 0 && rect.height > 0;
    const refresh = visible && courtReloadQueued;
    if (refresh && window.CourtlineNative?.telestrator) courtReloadQueued = false;
    window.CourtlineNative?.telestrator({visible, x: rect.x, y: rect.y,
      width: rect.width, height: rect.height, viewportWidth: window.innerWidth, reload: refresh});
  }
  function schedule() {
    if (!pending) { pending = true; requestAnimationFrame(() => update()); }
  }
  // Opening any dialog hides the separate native WKWebView before it can cover controls.
  openSettings.addEventListener('click', () => {
    if (settingsDialog.open) return;
    settingsDialog.showModal();
    update();
    window.dispatchEvent(new Event('courtline-modal-change'));
    closeSettings.focus();
  });
  closeSettings.addEventListener('click', () => settingsDialog.close());
  settingsDialog.addEventListener('close', () => {
    update();
    window.dispatchEvent(new Event('courtline-modal-change'));
    openSettings.focus();
  });
  document.getElementById('reloadTelestrator').addEventListener('click', async () => {
    try {
      await window.desktopFlushUI?.();
      // Reload needs a visible viewport. A hidden native WKWebView ignores reload flags.
      if (settingsDialog.open) settingsDialog.close();
      update(true);
    }
    catch (error) { window.telestratorStatus('Settings could not be saved: ' + error.message); }
  });
  new ResizeObserver(schedule).observe(viewport);
  new MutationObserver(schedule).observe(document.body, {attributes: true, attributeFilter: ['class']});
  new MutationObserver(schedule).observe(document.getElementById('assignmentAlert'), {attributes: true, attributeFilter: ['hidden']});
  document.addEventListener('toggle', schedule, true);
  window.addEventListener('resize', schedule);
  window.addEventListener('scroll', schedule);
  window.addEventListener('courtline-ready', schedule);
  window.addEventListener('courtline-view-change', () => update());
  // Explicitly hide the separate native web view before it can cover a modal.
  window.addEventListener('courtline-modal-change', () => update());
  schedule();
});
