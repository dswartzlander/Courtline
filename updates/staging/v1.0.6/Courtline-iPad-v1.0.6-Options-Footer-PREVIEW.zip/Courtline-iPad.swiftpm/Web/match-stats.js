(function(root){
'use strict';
const field=(f,k)=>f?.[k]?.stringValue??f?.[k]?.integerValue??f?.[k]?.doubleValue??null;
function ids(account,game,sides,bracket){if(sides.length!==2)return [];return [sides,[...sides].reverse()].map(([a,b])=>[account,game,a.id,bracket?a.placement:a.timesPlayed,...(bracket?[a.bestWins]:[]),b.id,bracket?b.placement:b.timesPlayed,...(bracket?[b.bestWins]:[])].join('-'));}
function summarize(rows,sides){return sides.map(side=>(side.players||[]).map(name=>{
 if(side.players.filter(p=>p===name).length!==1)return null;
 const rounds=[];for(const row of rows)for(const t of [1,2])if(String(field(row,'team'+t))===side.id&&String(field(row,'team'+t+'playername')).trim()===name.trim())rounds.push({row,prefix:'team'+t});
 if(!rounds.length)return null;
 const sum=k=>{const v=rounds.map(({row,prefix})=>field(row,prefix+k));return v.every(x=>x!==null&&String(x).trim()!==''&&Number.isFinite(Number(x)))?v.reduce((s,x)=>s+Number(x),0):null;};
 const score=sum('score'),inside=sum('in'),on=sum('on'),off=sum('off');return {PPR:score===null?'—':(score/rounds.length).toFixed(2),'4IN':inside===null?'—':String(rounds.filter(({row,prefix})=>Number(field(row,prefix+'in'))===4).length),IN:inside===null?'—':String(inside),ON:on===null?'—':String(on),OFF:off===null?'—':String(off)};
}));}
const api={ids,summarize};if(typeof module!=='undefined')module.exports=api;else root.CourtlineMatchStats=api;
})(typeof window==='undefined'?globalThis:window);
