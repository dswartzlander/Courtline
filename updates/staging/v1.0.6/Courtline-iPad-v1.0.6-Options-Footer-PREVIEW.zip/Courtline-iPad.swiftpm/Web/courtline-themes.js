/* CourtLine local theme selector. Shared between iPad Main/Companion and Android Main/Companion. */
(() => {
  'use strict';
  const KEY = 'courtline-color-theme-v1';
  const THEMES = ['teal','blue','orange','purple','red','white'];
  const themeButton = document.getElementById('themeButton');
  const menu = document.getElementById('themeMenu');
  if(!themeButton || !menu)return;
  // Mount the menu outside app-shell so Telestrator layout and overflow can never
  // place its control cards above the popup. Fixed positioning stays viewport based.
  if (menu.parentNode !== document.body) document.body.appendChild(menu);
  const choices = [...menu.querySelectorAll('[data-theme-option]')];
  let current = 'teal';
  try {
    const saved = localStorage.getItem(KEY);
    if(THEMES.includes(saved))current = saved;
  } catch (_) {}
  function applyTheme(theme) {
    if(!THEMES.includes(theme))return;
    current = theme;
    document.documentElement.dataset.courtlineTheme = theme;
    choices.forEach(button => {
      const active = button.dataset.themeOption === theme;
      button.setAttribute('aria-pressed', String(active));
      button.classList.toggle('selected',active);
    });
    const accent = ({teal:'#27d7b6',blue:'#4ea9ff',orange:'#ffad54',purple:'#bc93ff',red:'#ff6979',white:'#ffffff'})[theme];
    const meta = document.querySelector('meta[name="theme-color"]');
    if(meta)meta.setAttribute('content', theme==='white'?'#f4f7fb':'#07101c');
    themeButton.style.setProperty('--theme-button-accent',accent);
    try {localStorage.setItem(KEY,theme);}catch (_){}
  }
  function showMenu() {
    // Native Telestrator is a separate platform WebView above the page;
    // temporarily hide only that surface while the Theme picker is open.
    document.body.classList.add('theme-menu-open');
    window.dispatchEvent(new Event('courtline-modal-change'));
    menu.hidden=false;
    themeButton.setAttribute('aria-expanded','true');
    const rect=(document.getElementById('optionsButton') || themeButton).getBoundingClientRect();
    const left=Math.max(8,Math.min(window.innerWidth-228,rect.right-218));
    const top=Math.min(Math.max(8,rect.bottom+7),Math.max(8,window.innerHeight-menu.offsetHeight-8));
    menu.style.left=left+'px';menu.style.top=top+'px';
    menu.querySelector('[aria-pressed="true"]')?.focus();
  }
  function hideMenu(returnFocus=false){
    menu.hidden=true;
    document.body.classList.remove('theme-menu-open');
    window.dispatchEvent(new Event('courtline-modal-change'));
    themeButton.setAttribute('aria-expanded','false');
    if(returnFocus)themeButton.focus();
  }
  themeButton.addEventListener('click', e=>{
    e.stopPropagation();
    if(menu.hidden)showMenu();else hideMenu(true);
  });
  choices.forEach(button =>button.addEventListener('click',()=>{
    applyTheme(button.dataset.themeOption);
    hideMenu(true);
  }));
  menu.querySelector('#themeClose')?.addEventListener('click',()=>hideMenu(true));
  document.addEventListener('pointerdown',e=>{
    if(!menu.hidden && !menu.contains(e.target) && !themeButton.contains(e.target))hideMenu();
  });
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!menu.hidden){e.preventDefault();hideMenu(true);}});
  window.addEventListener('resize',()=>{if(!menu.hidden)hideMenu();});
  applyTheme(current);
  window.CourtlineTheme = Object.freeze({apply:applyTheme,current:()=>current,themes:[...THEMES]});
})();
