'use strict';
window.VmixAddress = (() => {
  function parse(value,protocol='http:'){
    const text=String(value||'').trim();
    if(!text)throw new Error('Enter the vMix PC IP address or hostname.');
    let url;
    try{url=new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(text)?text:protocol+'//'+text);}
    catch(_){throw new Error('Enter a valid vMix IP address or hostname.');}
    if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.search||url.hash||url.pathname!=='/')
      throw new Error('Use only the vMix IP address or hostname, without a page path.');
    return url;
  }
  function split(address){
    const url=parse(address);
    return {host:url.hostname,port:url.port||(url.protocol==='https:'?'443':'80'),protocol:url.protocol};
  }
  function combine(host,port,protocol='http:'){
    const url=parse(host,protocol),text=String(port).trim();
    if(url.port)throw new Error('Enter the port number in the separate Port box.');
    if(!/^\d+$/.test(text)||Number(text)<1||Number(text)>65535)
      throw new Error('Enter a port number from 1 to 65535.');
    url.port=String(Number(text));
    return url.origin;
  }
  return {split,combine};
})();
