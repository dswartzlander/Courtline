# CourtLine iPad v0.92 — Crimson Red theme

- Adds **Crimson Red** alongside the existing five themes (including Royal Purple), available in Control and Companion views.
- Layered crimson and burgundy shades cover Stats, Control View Settings, scores, court cards, and Telestrator UI. Embedded third-party video content is unchanged.
- Theme remains local to this device and persists across restarts.
- Swift Playground embedded resources regenerated from updated Web files.
- No changes to court selection, automation, scoring, permissions, networking or vMix commands.
- Code tests and isolated browser color checks passed; still requires iPad hardware testing.
