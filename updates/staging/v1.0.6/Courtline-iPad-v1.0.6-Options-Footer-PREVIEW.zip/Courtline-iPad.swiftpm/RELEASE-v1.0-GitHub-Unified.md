# CourtLine iPad v1.0 — Unified GitHub release

Same existing iPad features, red theme, companion management and updates. App version 1.0, bundle version 100. The updater supports two- and three-component future versions and retains the trusted GitHub Releases domain restriction. Import this Swift Playgrounds project manually; iOS cannot self-install it.
