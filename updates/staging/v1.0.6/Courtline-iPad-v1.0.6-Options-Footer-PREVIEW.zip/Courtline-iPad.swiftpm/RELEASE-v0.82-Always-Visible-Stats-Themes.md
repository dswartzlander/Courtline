# CourtLine v0.82 — Permanently Visible Stats Toolbar + Theme Depth

- Stats court 1–4 selectors and Refresh Stats Now are always visible in both Main/Control and Companion.
- Removed the five-second collapse countdown and tap-to-reveal interception; header tabs and Theme remain directly clickable.
- Maintained the four-column, three-row Event Stats layout for all four players on the selected court.
- Blue, Orange, Purple: distinct gradients/shades on main tiles, highlighted stats, Current Game, record bars, and player headings. Teal unchanged. White Light keeps gray contrast and uses subtle shading on highlighted stats.
- UI layout needs validation on actual tablets. Browser layout tests cover common viewport sizes.
