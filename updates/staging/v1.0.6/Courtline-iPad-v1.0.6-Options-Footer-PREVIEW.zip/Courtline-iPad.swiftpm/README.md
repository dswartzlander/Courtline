> **Current release: v0.77.** See `RELEASE-v0.77.md` for navigation and Stats changes.

# CourtLine iPad v0.74 — Settings and Companion Stats update

- **Independent Settings columns:** Courts 1 and 3 are in the left vertical stack; Courts 2 and 4 are in the right vertical stack. Expanding any Device, Automation, or Telestrator drop-down grows only that court and the other court beneath it in the same column. The adjacent court stays at its own height.
- **Inline Output 2:** Each court's editable Telestrator Output 2 video-input field sits in the header alongside `TELESTRATOR BUTTON · COURT 1–4`, accessible even when the details are collapsed. The field still autosaves on change. Editing it does not expand or collapse the section.
- On narrow layouts, the courts return to a simple Court 1–4 single column. Live view keeps its existing court grid and drawing layout; all controls and monitoring remain available.
- Regenerate Swift resources after any Web edit using `python3 Tests/generate-resources.py`. This update already includes regenerated resources.
- Install by extracting this ZIP, opening `Courtline-iPad.swiftpm` in Swift Playground on iPad, and pressing Run. This is not an IPA and still requires physical iPad/vMix verification.

---

# CourtLine iPad v0.71 — Remove empty Settings divider

**Layout fix:** The unused Live-view activity row is hidden entirely on the Settings screen. It had been accidentally shown as an empty bordered strip between the live vMix commands and Automation for each court. The status/activity/log controls continue to work in Live view. No automation, telestrator, vMix, permissions, or court behavior was changed.

**Install:** Extract ZIP and open `Courtline-iPad.swiftpm` in Swift Playground on the iPad. Rebuild by pressing Run. This is not an IPA.

**Tests:** Run `node Tests/settings-court-spacing.cjs` and the other `.cjs` files in `Tests`. Editable Web assets have been re-embedded in `CourtlineResources.swift` by the generator.

---

# CourtLine iPad v0.69 — Confirmed court-switch auto-refresh

When vMix confirms a shared court change, the telestrator native WKWebView automatically reloads on the Main and all linked Companions. Pending/failed court switches do not reload; refresh requests wait until the Telestrator view is visible (e.g., after closing the settings dialog). Helper control checks occur every 1.5 seconds. The v0.68 top-right Telestrator Settings pop-up and full-width telestrator browser are unchanged.

The Web assets are embedded in CourtlineResources.swift. Run in Swift Playgrounds on iPad to test; not a signed IPA.

## v0.68 · Telestrator Settings in the iPad top bar

- The Telestrator tab now gives the vMix drawing browser the entire available area below the main header, in portrait and landscape.
- **Telestrator Settings** appears in the top header next to the Main/Companion status on the Telestrator tab. The settings dialog contains the editable device name, exclusive control status/request/take/release controls, shared court selection buttons, connection details, manual Reload Browser and command status. Other tabs are unchanged.
- The native WKWebView is hidden while the settings dialog is open; closing the dialog restores the drawing surface without reloading it. Reload Browser closes the dialog first, then reloads the visible browser.
- The existing vMix address, shared drawing permissions, helper protocol, court selection and on-device settings storage remain unchanged. Test the layout and interactive drawing on an actual iPad using Swift Playground; there is no compiled IPA.

## v0.67 · Named telestrator controllers (Android + iPad)

On either device, open the Telestrator tab and find **Device Name** above the shared controls. Enter an identifying name (e.g. *Coach Mike — Galaxy Tab*) and press **Save Name** or Return. This name stays saved on that device even when you reconnect, switch Main/Companion roles, or restart the app. The current drawing holder is identified by this name on every connected device at the next Helper update; while a device is controller, its name is refreshed with each lease heartbeat. Names are labels only and do not grant match access. Multiple devices may enter the same name, so choose distinct labels.

**Compatibility:** Windows Helper v0.34 already accepts a device `name` on each telestrator action. No Helper update is necessary. To see a changed name while waiting in the request queue, withdraw and make a new request. A physical device and live vMix check is still required.

# Courtline iPad v0.66

Prepared from the working Android v0.45 interface for testing on your 12.9-inch iPad Pro (5th generation). This is a Swift Playground source project, not a signed IPA or an App Store installation. Swift Playground must compile it on your iPad before it can run.

## Open on your iPad

1. Install Apple's free **Swift Playground** app from the App Store.
2. Download **Courtline-iPad-v0.66.zip** on the iPad and save it to Files.
3. In Files, tap the ZIP to extract **Courtline-iPad.swiftpm**. Keep the entire package together.
4. Tap **Courtline-iPad.swiftpm** to open it in Swift Playground. If needed, use Share and choose Swift Playground, or browse to the extracted package from Swift Playground.
5. Press Run (the play triangle). Allow any requested local-network access so Courtline can connect to your vMix PC.
6. Confirm **iPAD v0.66** appears at the top. Use landscape orientation for the first four-court test.

The first compile is not yet verified. If Swift Playground reports an error, send the exact first error and filename. If the package opens as a folder instead of a project, report that before moving or renaming anything.

## v0.66 switch Main / Companion from the Live status badge

- In any Live view, tap the badge marked **CONTROL VIEW** (Main) or **COMPANION VIEW** (Viewer), near the top-right. It opens **Switch Main / Companion** with **Cancel · Go Back** and **Scan Helper QR Code**.
- **Cancel** or canceling the native camera scanner leaves the current pairing and permissions unchanged. The scanner uses the iPad camera directly inside CourtLine, not the Camera app.
- Scan **Main Device** from the Windows Helper for Main access, or **Companion Viewer** for read-only courts/stats and optional shared telestrator drawing control. The native iPad bridge verifies the QR token through the Helper `/api/session` route **before** saving the new URL or access role. An invalid, expired, or offline QR does not replace the previous pairing.
- On success, CourtLine reloads so Main-only settings and monitoring are either unlocked by the new Helper role or hidden in Companion Viewer mode. Switching away from Main stops this iPad from publishing court updates, so ensure another Main is connected first.
- Works from Viewer mode, where regular settings writes are prohibited. The only new Viewer-permitted setting change is the validated Helper pairing; the existing settings and vMix command restrictions remain in force.
- The Main/Companion badge remains reachable in portrait on a full-size iPad. Existing Settings PIN prompts and the Settings QR path are still available.

## v0.65 automatic vMix Output 2 camera routing

- On the **iPad Main**, open Settings and expand **TELESTRATOR BUTTON · COURT 1**. In **Telestrator Output 2 video input for Court 1**, enter the actual vMix camera/video input name or number for Court 1. Repeat for Courts 2–4. Leave each field to save its value.
- This is a **separate source field**: do not enter the Scoreholio Browser/widget input. The four existing widget inputs are unchanged.
- On the Companion that holds drawing control, press Court 1–4. Windows Helper v0.33 forwards that request to the foreground iPad Main; Main sends vMix `SetOutput2` for the configured video input. The Helper updates the shared court selection only after vMix reports the HTTP request succeeded. Everyone else continues seeing the current selection until it is confirmed.
- The Main can also switch courts while another device holds drawing control. Viewers without drawing control cannot switch. If a video input is blank, the older per-court non-dry-run, zero-delay Telestrator shortcuts still work as a fallback.
- **Requires:** live vMix Web API at the saved address, Output 2 feeding the vMix Telestrator, the iPad Main running v0.65 or newer in the foreground, and Windows Helper v0.33. Test each camera source and all viewers on your actual vMix LAN before using live.

## v0.64 shared telestrator court selection (requires Windows Helper v0.33)

- Exactly one device holds the exclusive drawing lease. Other devices see the same vMix telestrator feed in read-only mode.
- The Main and whichever device currently holds drawing control can choose Court 1–4 from the telestrator toolbar. A Viewer without drawing control sees only **Showing Court N**, not the court selection buttons.
- A Companion court selection goes to the Windows Helper; the Main processes the request using its locally configured court-specific Telestrator button vMix shortcut. The shared selected court updates only after the vMix API accepts the live command.
- On the Main, configure an enabled, non-dry-run, **zero-delay** shortcut for each court. Use vMix's configured Telestrator video source/output to display the chosen court on every device.
- Test Main selection during a Companion drawing lease, Companion holder selection, a rejected non-holder selection, a missing shortcut, and offline Main. The previous confirmed court remains visible while a switch is pending or fails.
- The iPad Swift Playground project has not been compiled on an iPad in this environment. Verify with actual Main + Companion devices before using it during a match.

## Set up and test

1. Connect the iPad and vMix Windows computer to the same reachable network. Guest Wi-Fi may isolate devices.
2. Open Courtline Settings. Enter your permanent Scoreholio widget URLs and each court's vMix input.
3. Enter the vMix PC address, such as **http://192.168.1.50:8088**. Use your actual PC address; localhost refers to the iPad.
4. Press **Test vMix Connection**. If the first request fails while you answer the Local Network prompt, allow access and test again. Enable the vMix Web API and permit it through the PC firewall.
5. Leave **Dry run ON**, apply each court's automation settings, and press Start on the courts to monitor. Settings must be entered on the iPad; Android settings are not automatically transferred.
6. Confirm names and scores update. During a test match, the transition from round 1 to round 2 should show the red match-start overlay within that court. Acknowledge it. Starting monitoring at round 2 or later establishes a baseline and does not manufacture a match-start alert.
7. Match completion is inferred from changed team names or three readings without team names. It is not triggered solely by a score reaching 21. The configured completion delay applies.
8. Check that an overlay covers only its own court, the other courts stay usable, and the selected court's Acknowledge button dismisses its alert. Confirm Start dims while active and Pause changes to Resume when paused.
9. Switch away and return. Monitoring should stop and show a restart reminder. Press Start again for each monitored court. Missed events and queued commands are not replayed.
10. After the dry-run test succeeds, test **Send Browser Widget to vMix** on a spare input. That button and **Test LIVE** send real commands even while Dry run is enabled. Only turn Dry run off for automation after you have checked the court/input assignments and command rows.

## What is included

- Four-court dashboard, player names and scores, settings, widget sending, connection test, court visibility, court-local activity logs.
- Court-local match alerts and state-aware Start/Pause/Resume/Stop controls from v0.45.
- Native WKWebViews to read Scoreholio widget text and native URLSession requests for Scoreholio data and the configured vMix host.
- Local settings persistence, screen-awake behavior while foregrounded, and a restart reminder after leaving the app.
- Local Network permission declaration and local HTTP networking configuration for the vMix API.

## Validation and remaining limits

Offline JavaScript engine and button-state tests passed, including round-two alerts, acknowledgment blocking, dry-run suppression, name-change completion, completion without the Round label, stop/background cancellation, and control states. JavaScript syntax and the property-list file were checked.

The Swift package has **not been compiled** with Apple's SDK, run in Swift Playground, tested visually on iPad, or connected to live Scoreholio/vMix from iPadOS. The native bridge, permissions, resource loading, and live widget reading require on-device validation. No Mac or Apple SDK is available in the preparation environment.

Keep the app foregrounded. This project does not provide background match monitoring or system push notifications. A vMix request already transmitted cannot be recalled. Closing/removing the project or deleting app data can remove local settings.

The project has no external Swift-package dependencies. AppleProductTypes and the Apple frameworks are supplied by Swift Playground/Xcode. Running the source within Swift Playground is the test route; distributing a separately installed app is a later step.

## Optional developer checks

From this package directory on a computer with Node.js:

    node Tests/engine.cjs
    node Tests/controls.cjs
    node Tests/telestrator.cjs
    node Tests/activity-log.cjs

## Apple references

- Swift Playground: https://developer.apple.com/swift-playground/
- iPad user guide: https://support.apple.com/guide/playgrounds-ipad/welcome/ipados
- Local-network capability: https://developer.apple.com/documentation/swift-playgrounds/project-capabilities
- Local HTTP networking: https://developer.apple.com/documentation/bundleresources/information-property-list/nsapptransportsecurity/nsallowslocalnetworking

## v0.3 build correction
The reported compile error was `Type 'Bundle' has no member 'module'`. This revision embeds the interface files in Swift source and writes them to the app's Application Support directory before loading the dashboard. It does not depend on a generated package resource accessor. The readable Web folder is retained for maintenance but is excluded from resource bundling. Native compilation remains to be verified in Swift Playground. Extract this ZIP in a separate folder and open its project so you do not accidentally run the old copy.

## v0.3 vMix address correction
API path checks accept /api and /api/ using URLComponents instead of the older URL.path property. Host comparison trims surrounding whitespace, normalizes host/scheme case, and compares effective HTTP/HTTPS ports. Requests remain restricted to the saved vMix host. If Test vMix Connection still fails, record the complete error below the button and the address entered. Check iPad Local Network permission. A successful live iPad/vMix test is still required.

## v0.4 telestrator and bottom court row

Live view now reserves the upper area for an interactive native WKWebView and places all four enabled courts in one horizontal row below. Existing court visibility settings still apply. Settings use the full dashboard area and hide the browser. Global assignment alerts temporarily hide the browser so they remain accessible; court-local alerts remain over their own cards.

The browser uses the saved vMix scheme, host and port with `/telestrator`. It does not append that path to `/api/`. Returning from Settings picks up address changes. Reload reconnects the browser without restarting court monitoring. Ordinary score updates and layout changes do not reload the drawing page. The remote page has no access to the Courtline native script bridge.

Before testing, enable Telestrator in vMix Settings → Web Controller and select its video source. See https://www.vmix.com/help29/Telestrator.html. Run the new package in Swift Playground, confirm iPAD v0.34, and test drawing, video playback, Reload, landscape/portrait rotation, Settings, and court alerts against your vMix PC. The browser's page-load status does not verify that the video feed or drawing connection is working.

Offline engine/control tests pass. Native compilation and live iPad/vMix integration remain unverified in this environment.

Browser bridge tests also pass with a mocked native bridge. A rendered layout check could not run because the browser runtime download failed; visual layout remains to be checked on iPad.

## v0.5 embedded telestrator correction and diagnostics

The operator confirmed `http://192.168.1.240:8088/telestrator/` opens in Safari on the same iPad. Set Courtline’s vMix address to `http://192.168.1.240:8088`. The browser now constructs the exact `/telestrator/` path, retaining the configured port. The API base setting remains unchanged; no IP is hard-coded.

This build explicitly permits HTTP content in WKWebView for vMix's browser page. This affects web-view transport policy only, leaving native API request policy unchanged. The telestrator's main navigation remains restricted to the saved vMix origin and its page has no Courtline bridge. A successful Safari test does not establish whether Courtline has Local Network permission or whether its embedded browser can load the page.

The browser status now shows the full URL, HTTP errors, blocked navigation, and native error codes without truncation. “Page loaded” confirms document navigation only, not drawing or video connectivity. If blank, report the full status line after Reload and check iPad Settings → Apps → Courtline iPad → Local Network where available.

The root cause of the v0.4 blank browser has not been confirmed. Native compile, rendering, video, and drawing require on-device verification of this revision.

## v0.6 portrait telestrator layout

In portrait, the bottom court row now uses 32% of the available main area instead of roughly 45%. The telestrator receives the remaining height, and its browser viewport spans the available screen width without the former outer side gutters. All enabled courts remain in one row. The existing fit logic keeps card contents within the shorter cards; video and drawing layers remain together inside the native vMix page. Landscape retains its existing split.

Validate on the iPad in portrait: the white-bordered live image should expand across the browser width, the drawing tools should remain visible, and a test stroke should follow your finger. The remote vMix page controls its own video scaling, so full-width video and touch alignment require a live device check. No image-only stretching or cropping has been applied.

For v0.6, the existing engine, button-state, and telestrator bridge tests pass and embedded resources match the editable files. Browser rendering could not run because a browser executable is unavailable. Native compilation and live feed sizing remain to be checked on iPad.

## v0.7 activity log and stable vMix confirmation

Each court now has a View Activity Log button. It opens a nearly full-screen, scrollable log with a court heading, Advanced details, and Close. The log updates live and preserves your reading position when you scroll away from the latest entries. The native telestrator is temporarily hidden while the log is open and restored without requesting a reload when it closes. Monitoring continues.

Send Browser Widget to vMix shares a row with Start/Pause/Stop. Its confirmation is below the Send button in a fixed-height area that stays reserved when empty; longer errors scroll within that area.

Validation: offline engine, controls, modal/log, and telestrator visibility tests passed; embedded Web assets regenerated and verified. Browser rendering and Apple SDK compilation are unavailable here. On iPad, confirm v0.7, open and close each court log, scroll during updates, toggle Advanced details, rotate the device, and send a widget to verify button alignment before/during/after confirmation.

### v0.7 orientation behavior
Portrait keeps the telestrator above the single court row. Landscape hides the browser and uses the full Live area for a two-by-two court grid (one or two enabled courts expand to fit). Returning to portrait restores the browser without a requested reload. Test rotation both with the activity log closed and open.

## v0.8 court-local activity log

View Activity Log now covers only its own court, with a heading, Advanced details, scrollable entries, and Close. Other courts and the portrait telestrator stay usable. Logs remain outside the card scaling canvas, follow new entries only when you are at the bottom, and can be open on multiple courts independently. Match alerts remain above the log so acknowledgment is accessible.

The user confirmed the v0.7 portrait/landscape behavior works on iPad. This revision preserves that behavior and the reserved vMix confirmation beneath Send. Offline log isolation, scroll/focus, controls, engine, and telestrator tests passed; embedded assets were regenerated and verified. Native compilation and visual verification of v0.8 still require the iPad. Check each court's log in both orientations and close it using Close (or Escape on a keyboard).

The Send Browser Widget to vMix button now shares flexible columns with Start/Pause/Stop instead of using a fixed 190-pixel width. Its label wraps, the monitoring buttons can shrink within their column, and the confirmation stays in reserved space underneath. Verify all four controls are visible with four courts in portrait.

## v0.9 portrait controls arranged vertically

In portrait Live view, Start/Pause/Stop have a full-width row and keep their labels on one line. Send Browser Widget to vMix is on the next full-width row, with its fixed-height confirmation area beneath it. Activity Log remains court-local. Landscape and portrait telestrator behavior are unchanged.

Offline regression checks and embedded-asset verification passed. Native compilation and visual layout verification of v0.9 require the iPad. Confirm all four courts in portrait show Start/Pause/Stop above Send, and confirm a successful send does not shift the layout.

## v0.10 confirmation beside Activity Log

The existing vMix feedback node now sits to the right of View Activity Log in a shared bottom row. Its fixed-height space stays reserved while empty, so success/error messages do not push the controls. Long messages scroll within that space. Portrait retains Start/Pause/Stop on one full-width row and Send below. The log remains court-local, and orientation behavior is preserved. Feedback remains visible in Settings while the Activity Log button is hidden there.

Offline controls, activity-log, and orientation tests passed; embedded resources were regenerated and verified. Check the final layout on iPad with four courts, both before and after sending a widget. Native compilation and visual verification of v0.10 remain device checks.

## v0.11 Live tabs

Live view opens on Courts, with a separate Telestrator tab. Each tab fills the main area in portrait and landscape. Courts use a two-by-two grid for three/four enabled courts; one or two expand to fit. Settings remain available from either tab; Back to Live restores the selected tab.

Switching tabs hides/shows the existing native browser without requesting a reload or sending monitor control commands. Court monitoring continues while Courtline is foregrounded. The Courts tab shows the count of active court alerts so you can return to acknowledge them. Leaving the app still stops monitoring and requires a restart.

This release includes the bottom row with vMix confirmation beside View Activity Log and two-line status formatting: monitoring/mode first, Scoreholio/vMix connections next. The Activity Log remains court-local.

Validation: offline engine, controls, court-local log, tab switching, keyboard navigation, alert count, Settings return, both orientations, and browser visibility/reload tests passed. Embedded assets were regenerated and compared with source bytes. Native compilation and visual layout require verification on iPad.

On iPad, confirm v0.11, start a dry-run court, switch to Telestrator and back, rotate in each tab, open Settings and return, and verify monitoring continues. Check the Courts alert count during a test match.

## v0.12 court-local automation save feedback

Apply automation settings now reports Saving, Automation settings saved, or a save error in the upper-right of that court's automation section, beside the heading. Each court has its own accessible status area. A failed save still prevents Start from continuing.

JavaScript syntax and existing offline controls checks passed. Embedded assets were regenerated and verified against source bytes. Confirm the feedback placement and save behavior on iPad.

## v0.13 separate vMix host and port

Settings now has adjacent IP address / host and Port boxes. Existing saved URLs are split on load, preserving their scheme and effective port; the standard vMix example fills Port with 8088. The application still saves one combined URL for the native API, Test Connection, widget sending, automation, and telestrator. HTTP is assumed for a bare host; an existing HTTPS scheme is preserved, and http:// or https:// can also be entered explicitly in the host box.

Port accepts integers from 1 to 65535. Invalid input is reported before connection tests, applying profiles, or manual widget/command sends. On iPad, verify the old address appears split correctly, test the connection, change/reopen Settings, and confirm a widget send and Telestrator use the configured port. Native compilation and live integration require device testing.

Validation for v0.13: saved-address round trips, custom/default ports, HTTPS/IPv6 handling, invalid input rejection, and existing engine/control/tab tests passed. All nine embedded interface assets match their source files.

## v0.14 configurable manual trigger

Each automation shortcut row now offers Button press alongside Round complete and Match complete. Use the same command field or Select shortcut picker (including Mix, Input and extra parameters), set Delay and Enabled, then Apply automation settings. The live court's Run Manual Commands button runs only that court's applied, enabled Button press rows. For example, configure Cut with the desired input and Mix in the picker. This is a configurable vMix command button, not a new telestrator-input setting or automatic tab switch.

Manual commands honor the court's Dry run mode and each row's delay. They work without starting match monitoring, including while it is paused. Repeated presses are disabled while that court's manual batch is pending. Stop cancels queued commands even when monitoring is stopped; leaving the app, changing the assignment, or changing the vMix host also cancels queued work. Requests already transmitted cannot be recalled. Failures create the existing court-local vMix error alert and are not automatically retried.

Verify on iPad with Dry run first: add Button press rows, Apply, open Courts, press Run Manual Commands, and inspect Activity Log. Then test the intended input/mix using a safe live command. Confirm round/match triggers still run independently. Native compilation and live vMix verification require the device.

Validation for v0.14: offline manual-trigger tests passed for row selection, delays, Dry run, Mix/Input parameters, court isolation, stopped/paused operation, duplicate prevention, cancellation, and failure/no retry. Existing engine, controls, tabs, and address tests passed. All nine embedded assets match source bytes.

## v0.15 full settings backup and restore

In Settings, Export All Settings captures every court URL, remembered device pairing, vMix address/port, browser input, visibility flag, auto-refresh preference, and automation profile/row (including current edits not yet applied). It opens the iPad share sheet: choose Save to Files to keep Courtline-Settings.json for future builds. Runtime scores, logs, pending commands, and monitor state are not included.

Import All Settings opens Files, validates a version-1 Courtline JSON backup, and asks before replacing all four courts. It restores settings including Dry run choices, cancels monitoring/queued commands, and refreshes the interface. No commands are sent by importing; review the fields, then start monitoring manually. Malformed or unsupported files do not replace the configuration.

The native bootstrap is refreshed after saves so importing and reloading reads the restored configuration. The separate old-bridge import remains available for legacy single-court profiles.

On iPad, export to Files, confirm the JSON exists, change a harmless setting, import the file and confirm all four courts return to their saved values with monitoring stopped. Test cancellation and an invalid file. Native compilation, Files picker/share sheet, and end-to-end restore still require device validation.

### v0.15 manual-button visibility correction
An older Live-view rule hid the new manual-command section. A court-specific Live override now displays Run Manual Commands below Send Browser Widget. The button is disabled until an enabled Button press row has been applied. It runs the configured vMix command; it does not automatically change the Courtline tab.

Validation: offline backup round-trip/rejection/persistence-failure/import cancellation tests passed, along with manual-trigger, engine, controls, tabs, address, and activity-log regressions. All ten embedded interface assets match their editable source files. Native share-sheet/Files integration and final layout remain iPad checks.

## v0.16 Telestrator court toolbar and full backup

The Telestrator toolbar now has Court 1–4 buttons between the connection status and Reload. Each court has its own TELESTRATOR BUTTON settings section, separate from round/match automation. Add shortcuts with the existing function picker or full vMix command field, configure Input/Mix/extra parameters and delay, then Apply Telestrator button settings. Dry run is independent for each court's Telestrator button and defaults ON.

Each toolbar button queues only that court's saved Telestrator shortcuts, without starting monitoring, switching Courtline tabs, or reloading the browser. Buttons are disabled until an enabled shortcut is applied, and while button commands for that court are pending. Errors appear in the court log/alerts; the Courts tab shows alert counts.

Export All Settings now includes both automation and Telestrator button sections, including current edited rows. Use Save to Files from the iPad share sheet. Import All Settings restores all four courts after validation/confirmation, with monitoring and queued commands stopped. Version-1 backups without Telestrator sections load with empty, Dry-run-enabled sections.

Offline tests passed for independent Telestrator commands and Dry run, Input/Mix routing, settings round-trip/backward compatibility, rejected files, and existing automation/tab regressions. Native compilation, toolbar layout, share sheet, and Files picker require iPad verification. Configure a test shortcut in Dry run first and press its court on Telestrator; export to Files and test importing that backup before relying on it for a rebuild.

## v0.17 expanded vMix function picker

The shortcut picker now has 780 function names across 16 categories from the official vMix 29 reference, plus standard transitions. Search by name/category or choose a category. Common supported Input, Value, Mix, and Duration fields appear for the selected function, with Extra parameters for other keys. The catalog is embedded and works offline. Function availability depends on the installed vMix version/edition.

LayerOn and LayerOff are in the Input category. For those functions, enter the input containing the layer and the layer number starting at 1. Commands are generated as Function=LayerOn or LayerOff, Input=the containing input, and Value=the layer number. This picker is shared by the independent Telestrator button sections and existing automation sections. Existing saved commands remain unchanged.

Reference: https://www.vmix.com/help29/ShortcutFunctionReference.html (retrieved October 28, 2026). Only function names and parameter keys are embedded; descriptions are not copied.

On iPad, configure a Telestrator shortcut, search LayerOn/LayerOff, fill Input and Layer number, apply the button settings, and test with Dry run first. Native compilation and live layer behavior still require device verification.

Validation for v0.17: catalog and LayerOn/LayerOff command tests passed, including input/layer validation, encoding, duplicate parameter rejection, and existing Input/Mix handling. Manual-trigger, settings-backup, controls, and engine regressions passed. All eleven embedded interface assets match source bytes.

## v0.34 inline split shortcut picker

Categories and functions now use persistent, scrollable button lists inside the shortcut picker instead of native select controls that open iPad popovers. Categories appear on the left, matching functions in the middle, and the selected function's parameters on the right. Selection is highlighted, search filters the functions, and Use shortcut is disabled when no function matches. On narrower displays the parameter pane moves below the two lists.

The 780-function catalog, layer Input/Value handling, Telestrator button configuration, and export/import are retained. Offline picker interaction and command-builder tests passed. Visual spacing, touch scrolling, and native compilation still need an iPad check. Open Select shortcut, choose Input, select LayerOn/LayerOff, fill the parameters, and confirm Use shortcut and Apply retain the command.

## v0.34 settings cleanup

Removed the description panel above the court settings. Export All Settings and Import All Settings now sit beside Refresh. Backup status appears below the toolbar, and the older bridge importer remains available under Legacy profile import. Existing import/export behavior is preserved.

## v0.34 shortcut field sizing

The vMix command fills the available row width beside a compact 84px Delay field. Select shortcut, Test LIVE, and Remove use a separate row. Applies to automation and Telestrator shortcuts.

## v0.34 court settings cleanup

Removed the horizontal widget URL heading, read-only URL field, Copy URL button, and explanatory text from every court. Device Widget URL, vMix input, Preview, and Send Browser Widget remain available; the overlay URL is still generated internally for sending.

## v0.34 Telestrator court selection

The last court button whose shortcut request was accepted stays dark teal. Selecting another court moves the highlight; rejected requests retain the previous selection. This indicates the last accepted button request, including Dry run, rather than confirmation of the current vMix output.

## v0.34 header navigation

Moved Courts and Telestrator tabs into the header between the logo and Settings. The freed navigation row is now available to the court grid or Telestrator in either orientation.

## v0.34 settings header layout

Settings title and description now appear above a full-width controls row: Refresh, Export, Import, refresh interval, Auto refresh, and vMix host/port/connection test. Helper text and confirmations appear underneath. The row scrolls horizontally on narrower screens to preserve usable control sizes.

## v0.34 Live Monitor badge

The header monitoring badge is hidden on Settings and remains available in Live view.

## v0.34 remove legacy manual controls

Court automation offers Round complete and Match complete only. Run Manual Commands is removed from court cards. Existing legacy Button press automation rows are omitted from the editor and removed from that court profile when settings are applied; they are never converted into automatic triggers. Separate Telestrator button settings and toolbar buttons remain available.

## v0.34 Stats workspace

Added Stats beside Courts and Telestrator. Stats shows four empty court outlines in a two-by-two grid in either orientation, ready for future data. Court monitoring continues while switching tabs.

## v0.34 single-court Stats workspace

Stats now has Court 1–4 buttons above one large empty court panel. Buttons switch between independent placeholders, with dark teal selection. The selected court remains selected when switching Live tabs.

## v0.34 player Stats layout

Each Stats court has two team columns with two player sections per team. Names come from the current accepted Scoreholio assignment; teamName is shown above its side only when supplied. Each player has an empty stats area underneath, ready for future stat fields. No player metrics are inferred or fabricated.

## v0.34 authenticated ScoreMagic export

Settings includes an event admin URL, Sign in to Scoreholio, Refresh Stats Now, and an optional 30–3600 second automatic export interval (60 seconds by default). Sign in inside the separate website browser and tap Done. Credentials are managed by Scoreholio/WebKit, never copied into settings or backups. Stats refresh loads the event, opens Stats & Logs / ScoreMagic / Export, and captures the generated CSV locally. No score or tournament controls are changed.

Player metrics are event totals, matched by normalized display name only when the event account and game match the court. Duplicate or missing names show no unique match. Team names still come from live assignments. Successful exports replace the snapshot atomically. Last successful data is retained on errors. Auto-refresh defaults off and pauses on errors or when leaving the app; use Refresh Stats Now to resume. Refresh is foreground-only. One stats event is supported at a time. Connection settings are included in settings backups; session credentials and cached CSV are not.

Offline tests cover CSV quoting, headers, duplicate names, matching, and settings backup compatibility. Native compilation, website login, automatic clicking/export interception, and live refresh require iPad testing; no Apple SDK is available here. If the website changes its export controls, Courtline reports a timeout rather than fabricating stats.

## v0.34 Windows stats helper

Replaces in-app Scoreholio sign-in/export with the Windows helper. Run Courtline-Stats-Helper on the vMix PC, sign in there, and copy its iPad address into Settings → Stats helper address. Export & Refresh Now triggers a PC export; optional iPad auto-refresh polls the latest snapshot (10 seconds by default, minimum 5). The PC’s own automatic-export schedule is configured in its dashboard, at least 30 seconds. Keep the helper running and the PC/iPad on the same LAN. Permit private-network access when Windows/iPad prompts.

The native request is restricted to the exact saved helper address and the stats/refresh endpoints. The helper address includes a private access key and is included in settings backups. Never use localhost on the iPad. No sign-in credentials are stored on the iPad. Previous v0.30 connection settings migrate to a blank helper address, with automatic refresh off. Stats are event snapshots and errors retain the last successful data. Apple SDK compilation and live Windows/Edge/Scoreholio/vMix integration remain unverified in this environment.

## v0.34 QR helper connection

Install helper v0.3 on the PC. Open iPad Settings → Scan Helper QR Code and allow camera access. Scan the locally generated code on the PC helper dashboard. The app validates and saves the address, then reads the most recent snapshot without triggering an export. Cancel leaves the address unchanged. If the PC has no export yet, the address is still saved and the helper error is shown. Use Export & Refresh Now after signing in on the PC. Camera scanning and native compilation require on-device validation.

## v0.34 helper address persistence correction

Adds Save Helper Address with a local success/error message. The previous stats save routine only flushed already-queued settings; it did not queue the edited/scanned helper fields. The corrected routine collects and queues the current fields, flushes them, and waits for the native persistence acknowledgment before asking the helper for stats. This applies to manual save, export/refresh, automatic refresh, and QR pairing. No PC helper update is required.

### v0.34 Settings startup
Courtline now opens on Settings on every launch. Tap Back to Live to open the live tabs.

## v0.34 roster SPR and event records
Use helper v0.13 or later. Each player’s Stats area now shows exported SPR and separate qualifying (W–L–T) and bracket (W–L) records, labeled Player or Team according to standings membership. Overall PPR/DPR and global rank are separate from ScoreMagic event totals. Missing or ambiguous fields show a dash. Existing helper snapshots remain compatible, but a new full PC export is needed for roster and standings values. The helper address and settings remain saved.

## v0.35 Stats display cleanup
Removed Overall PPR, Overall DPR, Global Rank, Total Points, Opp Points and Rounds from the iPad Stats display. SPR, qualifying/bracket records and remaining event metrics are still shown. No helper update is required.

## v0.36 SPR badge
SPR now appears in a teal oval on the far right of each player name row, rather than in the stats grid. Long names wrap while the badge stays aligned. Empty player slots hide the badge; missing SPR shows a dash. No helper update required.

## v0.37 player stat styling
Round Robin and Bracket Play records share one teal oval beneath the player header. Team records retain a Team label. Remaining metrics use compact cards with highlighted PPR/DPR values. 4IN is labeled Total Four Baggers and 4IN % is labeled Four Bagger %. SPR stays beside the player name. No helper update required.

## v0.38 compact stats
Smaller player headings, records and stat values, tighter card padding and gaps, and compact landscape sizing keep the stats within each player box. The name row stays fixed while the stats area can scroll on smaller screens. No helper update required.

## v0.39 court stat leaders
The teal highlight marks the best available value among the current court’s four players, including ties. Higher wins for PPR, Total Four Baggers, Four Bagger %, IN, IN %, ON and ON %. Lower wins for DPR, Opponent PPR, OFF and OFF %. Missing or invalid data is excluded. Highlights update on player assignment changes and snapshot refreshes. Records and SPR retain their oval styling. No helper update required.

## v0.40 stat highlight explanation
A small note below each court heading explains that highlighted stats show the best value among that court’s four players, including ties. No helper update required.

## v0.42 Stats button label
The live Stats refresh button now says Refresh Stats Now. Its refresh action is unchanged.

## v0.43 four-event stats helper
Use helper v0.14 for four event slots. One existing helper address/QR supplies all events. Each court chooses stats by the account and game in its current Scoreholio widget assignment, not by slot number or player name alone. Matching and highlights stay within that event and court. Refresh Stats Now requests all configured event exports sequentially; allow extra time for four first-time page loads. Older single-event helpers remain supported.

## v0.44 responsive live match text
Live tournament names, player names and scores scale to each court card’s measured width and remaining height after its controls. Player text no longer has the old 62.5% reduction. Larger cards use larger text; long titles wrap and the existing card fit handles constrained layouts. Stats typography is unchanged. No helper update required.

## v0.45 highlight explanation placement
The highlight explanation appears once directly below the four court tabs, rather than below each court heading.

## v0.46 compact court stats header
The toolbar title now reads Court 01 Stats and changes with the selected court tab. Separate court headings are removed so the four player areas expand into the recovered space. The highlight explanation stays beneath the court tabs.

## v0.47 highlight note alignment
The larger highlight explanation now sits below the toolbar divider, beside the refresh status and beneath the court tabs.

## v0.48 automatic helper event assignment
With helper v0.17, Courtline sends each confirmed Remote Mode assignment to its corresponding helper slot when the event ID or event name changes. It also resends current assignments periodically while in the foreground so the helper can recover after a restart. Only account/event IDs and event name are sent, through the saved authenticated helper connection. Temporary errors and idle courts do not clear the helper’s saved event. The helper exports changed events automatically; shared events download once. Save/scan the helper address first. The helper’s Follow Courtline checkbox controls each slot; turn it off and Save Event for manual URLs.

For first-time sign-in, use the helper’s general Scoreholio / Sign In button, then return to Dashboard. No placeholder tournament needs to be created. Keep both apps open. Existing Stats auto-refresh remains a separate setting for reading completed exports.

## v0.49 selected-court export status
The live Stats status now shows the selected court’s matching event export date/time and player count. It updates immediately when switching court tabs and on assignment or snapshot changes. A court without matching data shows no successful export instead of another event’s date/count. Shared events use their shared snapshot. No helper update needed.

## v0.50 collapsible settings
Each court’s Automation and Telestrator button settings now start collapsed. Tap the arrow/title to expand either group and see all its options, shortcut rows and Apply controls. Collapsing a group does not change its saved settings or running automation. No helper update required.

## v0.51 live visibility checkbox placement
In Settings, each Show in Live view checkbox now sits at the right of the court header beside its assignment status badge. Visibility and saving behavior remain unchanged.

## v0.52 copy and paste shortcuts
Each Automation and Telestrator group has Copy all shortcuts and Paste shortcuts. Individual rows also have Copy shortcut. The app’s internal clipboard can be pasted into another court or group during the same app session. Paste appends rows and creates fresh IDs; existing rows and group options are preserved. Review and Apply to save/activate changes. Telestrator destinations use Button press; Automation preserves Round/Match complete or defaults a copied Button press row to Round complete. Copy/paste itself sends no vMix commands. No helper update required.

### Device Widget & Event group
Each court’s device URL, Remote Mode link/status and vMix destination fields also start collapsed under Device Widget & Event. Tap its arrow to reveal all fields. Existing autosave and live controls are preserved.

## v0.53 DPR highlight correction
DPR now highlights the highest value among the court’s four players, including ties. Other stat highlight rules are unchanged.


## v0.54 current match stats and Settings PIN
Each player now shows Current Match PPR, 4IN, IN, ON and OFF above Event Stats and records, separated by a divider. Match stats come from the same ScoreMagic round feed used by the scoreboard and refresh with the court polling. Missing round/player bag data shows a dash; event exports remain separate.

Helper v0.25 adds an iPad Settings PIN section. Save a 4–8 digit PIN on the PC; connected iPads receive the policy within 15 seconds. Settings requires the helper to verify the PIN, with five failed attempts triggering a one-minute cooldown. The helper saves a salted scrypt hash, never the PIN; the iPad only caches whether protection is enabled. Returning to Live or backgrounding the app relocks Settings. With protection enabled, unavailable helper connections cannot unlock Settings. Clear the PIN field and save on the PC to remove protection. First-time iPad setup remains available until a helper is connected.


## v0.55 scan helper from unlock window
Unlock Settings now includes Scan Helper QR Code. Scan the PC dashboard QR to save/reconnect the helper without first opening Settings. The app checks the newly connected helper's PIN policy and still requires its PIN when enabled. Scanning does not require a successful event export. Canceling or failing the scan leaves Settings locked. No PC helper update is required beyond v0.25.


## v0.56 PIN protection is opt-in
Settings remains accessible until a connected helper explicitly reports that a PIN has been set. Merely saving/scanning a helper address or failing the first connection no longer triggers the PIN screen. After an enabled policy has been received, Settings stays protected on later launches and during helper outages. Save a PIN in helper v0.25 to enable; clear and save it there to disable. The QR scan option remains on the unlock screen.

## v0.63 multi-device Companion viewing and telestrator ownership (requires Helper v0.32)

The primary CourtLine iPad keeps its existing Main QR pairing and remains the only device publishing the four live court snapshots. Pair any additional iPads by scanning the new **Viewer QR** in the Windows Helper. The viewer role is stored on-device and opens directly into Live view; Settings, automation and vMix commands are unavailable. Viewers independently switch between Courts, Stats and Telestrator. Court cards mirror the main iPad over the Helper every ~3 seconds; event stats are read from the same Helper without triggering an export. If the primary stops publishing, the viewer displays a stale-state indication and keeps the last court snapshot. The primary must remain open in the foreground for live court mirroring.

The Helper coordinates a single 15-second renewable telestrator controller lease. All devices continue seeing the shared vMix canvas, but touch interaction is enabled only for the current holder. A free canvas can be claimed immediately. If occupied, request control; the holder sees the first waiting request and can grant it. The main device may override. The active controller's name appears above the telestrator. Losing the Helper connection does not preserve drawing access beyond the current lease.

Pairing: update the Windows Helper to v0.32, then scan its **Main Device** QR on the primary iPad using the usual Settings scan. On a second iPad, open CourtLine Settings and scan **Read-only Companion Devices** QR. The viewer switches to its locked Live experience after the scan. Pairing keys are different: a Viewer key cannot publish court data, assign events, refresh exports or administer the Helper.

**Device validation still required:** compile/run v0.63 in Swift Playground, test main + two viewers simultaneously, verify vMix's shared telestrator canvas really reflects drawings/undo on all connected screens, test request/grant/release/override/timeout, rotate each iPad, and verify viewers cannot open Settings or trigger vMix commands. The exclusive lock applies to CourtLine's embedded browser; vMix's independent Web Controller remains accessible directly on the LAN and must be secured separately if untrusted users are present. No Apple SDK or live vMix testing was available in the preparation environment.


iPad v0.69: Telestrator auto-reloads after confirmed shared court changes and when unpaired Main switches directly; reloads wait for visible native viewport.


## v0.70 — Visible Telestrator control requests

When another device requests the drawing lease, the Helper includes that request in the existing telestrator status poll (about every 1.5 seconds). The active controller or authenticated Main iPad sees an amber Settings button and a red **N REQUEST(S)** badge even when the Telestrator Settings dialog is closed, another live tab is selected, or the iPad shows the main settings screen. Tap **Telestrator Settings** to see the requester's Device Name and choose **Grant Control** or **Decline**; only the current controller or Main is permitted by the Helper to respond. Viewer-only devices never see someone else's actionable request badge. The badge clears after the request is resolved or expires at the Helper.

The alert is in-app only, not a push notification. The iPad must be open/foregrounded and connected to the running Windows Helper. No change to Helper, Android, single-controller permissions, or vMix execution logic is required.


## v0.73
Settings title is moved into the top header. Telestrator Button expand arrows are enlarged without changing Output 2 position. The Stats Helper QR scan now auto-saves the hidden connection address; the redundant address and save buttons are removed. QR pairing, export, auto-refresh and seconds controls are integrated into the top Settings toolbar. Companion Stats controls hide after 5 seconds with tap-to-reveal, while the court title stays above teams. The player Current Match section is now Current Game with contrasting dark teal styling.

## v0.74 Stats polish
The Main Stats page now auto-retracts the court selectors and manual refresh after five seconds, using the existing Companion safe tap-to-reveal behavior. A live Court score (from the same Scores feed used by the Courts tab) remains visible under the Court Stats heading for each court. Score-only changes update the Stats score without a full card redraw. Player names and SPR badges are larger, the Current Game area sits slightly lower, the Round Robin/Bracket records are more compact, the refresh button is smaller, and the court selectors are right-aligned.
