# CourtLine iPad v0.77 — Compact Player Statistics

- Match Android v0.78 Stats compact spacing for Main and Companion: slimmer boxed score and player-name headings.
- Remove W–L–T / W–L helper lines under Round Robin / Bracket Play records, while retaining values and explanatory accessibility text.
- Compact event stats to six columns on most tablet landscape screens; four-column fallback for narrow/portrait screens.
- Preserve court tabs, five-second hide/reveal, one-tap navigation, and pairing.
