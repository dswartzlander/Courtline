# CourtLine v0.78 – Themes and tablet layout

- Theme icon next to the header clock on both Control View and Companion View.
- Five locally saved choices: Original Teal, Electric Blue, Sunset Orange, Royal Purple, White Light.
- The theme picker stays available on Courts, Stats, and Telestrator screens; it is independent per device.
- Stats size refinement: iPad 12.9-inch panels use extra space; Android adjusts record rows and stat tiles responsively.
- Android Main label uses Control View to match iPad.
- Main and Companion pairing, scoring, and saved court settings have not been changed.
