# CourtLine iPad v0.88 — Independent Destination theme color

The **INDEPENDENT DESTINATION** label in each Main Settings court’s Device Widget & Event area now follows the active Blue, Orange, Purple, or White Light theme accent instead of the fixed teal color. Original Teal styling remains unchanged. No functional changes.

Run `python3 Tests/generate-resources.py` after editing Web to refresh embedded Swift Playground assets.
