# CourtLine iPad v0.90 — Local one-way Telestrator → Stats court selection

- Tapping a Telestrator court button selects the same court in local Stats immediately.
- Selecting a Stats court does not change the Telestrator court or transmit a Telestrator/vMix command.
- A change received through the shared Helper session does not change Stats on other devices.
- Existing vMix Output 2 and enabled Telestrator shortcut behavior from v0.89 is preserved.
- White Light readability and existing theme and layout improvements remain unchanged.
- Use in Swift Playgrounds; device/vMix tests required.
