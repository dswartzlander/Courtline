# CourtLine iPad v0.75 — Companion Navigation and Stats

Based on v0.74 (Stats Main Auto-Hide), preserving the Swift Playgrounds project and native WebView architecture.

- Companion View: **Stats** and **Telestrator** only, in that order, with Stats selected on entry. Courts data continues to synchronize invisibly for live scoring. Court 1–4 selectors inside Stats still work.
- Main Device: **Courts**, **Stats**, **Telestrator**, in that order.
- Companion Stats: court heading left aligned and tournament name right aligned on the same row; updated per selected court and live assignment.
- Stats score: label above the numbers with the colon centered even when the two totals have different digit counts.
- Companion Stats team names enlarged with responsive wrapping and portrait sizing.
- Preserves five-second Stats controls auto-hide/reveal, player SPR circles, and dark-teal Current Game sections.

## Run
Extract this archive and open `Courtline-iPad.swiftpm` in Swift Playgrounds on the iPad. Press Run. Existing Main and Companion connections should remain configured.

## Source/test information
Edit files under `Web/`, then run `python3 Tests/generate-resources.py` to regenerate `CourtlineResources.swift`. The archive already includes the regenerated embedded resources. From the SwiftPM project directory run `node Tests/*.cjs` individually (or loop over them). Web/JS test coverage is not an iPadOS native compilation or hardware confirmation.
