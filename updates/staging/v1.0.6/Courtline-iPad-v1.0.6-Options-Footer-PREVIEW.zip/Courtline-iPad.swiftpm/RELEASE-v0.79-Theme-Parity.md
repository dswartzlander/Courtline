# CourtLine iPad v0.79 — theme parity and contrast

- All Stats team names, score tiles, SPR badges, record rows and stat cards honor theme colors.
- Telestrator left-side control cards, court buttons and labels use the theme palette.
- Theme popup mounts directly under body to stay above controls.
- White Light has gray panel backgrounds, high-contrast borders, darker text and legible metrics.
- Same five presets; local theme selection and all scoring/connection behavior preserved.
- Android APK counterpart: CourtLine v0.80.
