# CourtLine iPad v0.84 — Main Settings Theme Accent Cleanup

Fixes residual Teal appearing in Blue, Orange, Purple and White Light on the Main management Settings view, including Court headers/section chevrons, Auto-refresh switch track, Back to Live button, assignment badges, focus rings and other control/status accents. The original Teal appearance remains unchanged.

No changes to networking, saved court assignments, score feeds, vMix commands, Stats layouts or Telestrator behavior. All editable Web assets must be regenerated into CourtlineResources.swift using Tests/generate-resources.py before opening in Swift Playgrounds.
