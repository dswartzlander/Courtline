# CourtLine iPad v0.91 — Control View palette cleanup

- Fixed the vMix API verified success status color in Main/Control View so it follows the selected accent instead of always using teal.
- Fixed court tournament names in Main/Control View to use the selected theme's readable text tint. White Light uses dark text.
- Applied the same correction to per-court vMix success feedback.
- Preserves all theme colors in Original Teal and all underlying vMix, Stats, and Telestrator functions.
- Regenerated CourtlineResources.swift with the edited Web files.
