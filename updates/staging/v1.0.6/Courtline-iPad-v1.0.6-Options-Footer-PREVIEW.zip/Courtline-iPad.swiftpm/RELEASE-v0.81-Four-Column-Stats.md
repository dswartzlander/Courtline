# CourtLine iPad v0.81 — Four-column, three-row Event Stats

- Main/Control and Companion Stats retain exactly one selected court.
- The 12.9-inch iPad's four player cards show 11 Event Stats in four columns and three rows, with OFF and OFF % visible on the bottom row.
- Current Game and Round Robin/Bracket Play records remain distinct sections; space/padding optimized to fit without internal scrolling at the intended full-screen iPad size.
- Keep the existing responsive fallback for atypical zoom/small windows. No change to stats content, themes, or telestrator controls.
- Embedded Swift Web resources regenerated after the CSS update.
- Verify visual fit in Swift Playgrounds on the actual iPad 12.9-inch device; this environment does not contain the iOS simulator/SDK.
