# CourtLine iPad v0.83 — Control/Settings Theme Parity

- In the Main management Settings view, Court panels, headers, lower configuration controls, vMix fields, helper panel, status strip and button accents now use Blue, Orange, Purple or White Light palette variants rather than hard-coded Teal colors.
- White Light now has dark, legible text, contrasted gray-blue panels, visible labels, form borders, and readable muted controls.
- Original Teal and the previously approved Stats and Telestrator themes remain unchanged.
- No changes to court assignments, saved addresses, QR pairing, automation commands or monitoring.
- iPad Swift Playgrounds project; the native binary still requires launching in Playgrounds on the iPad. UI browser previews and JS tests do not substitute for real-device confirmation.
