# CourtLine iPad 1.0.12 secure reconnect candidate

Not a released or device-validated build yet.

## Existing paired iPads

Scan the **secure reconnect / migration QR** on the trusted Backend PC once. This verifies its pinned TLS certificate and stable Backend identity, then reopens the existing device registration. It does not create another device or grant Control. A Device PIN still controls promotion.

A secure enrollment QR is only for an unregistered or revoked device. The old HTTP pairing remains supported for older Backend versions, but it does not enable automatic discovery. Once secure trust is saved, the app never falls back to HTTP or substitutes a different certificate.

## Startup and network changes

Try the saved secure address first. If unavailable, browse `_courtline._tcp` on the active Wi-Fi/Ethernet network. Advertisements are only candidates: verify the existing certificate pin and Backend UUID before sending any device key. Persist the new address only when the existing registered device is confirmed. Initial startup always reopens Companion; relocating an already-open session preserves its Control grant when the server confirms it.

No subnet scan, credential broadcasts, cellular discovery, automatic enrollment, PIN replay, mutation retries or automatic trust replacement. Permission denial, AP isolation or blocked Bonjour can prevent discovery. Existing pairing is kept on failure. Backgrounding cancels secure work without discarding the Control grant; a fresh app process still requires Control unlock.

## Validation limits

Linux cannot execute the iOS SDK. CI typecheck/link and fake-network Swift tests are required before delivery. Physical iPad/Swift Playgrounds, LAN Bonjour, real certificate challenge and changed-network testing must also be checked; source tests are not proof of those flows.

## Certificate expiry and explicit renewal

New Backend certificates last 365 days; incorrect device clocks or expired certificates fail closed. Discovery never replaces a certificate. After an owner-controlled renewal, scan the new reconnect QR directly on the trusted PC. The iPad shows the old and new fingerprints and requires **Trust New Certificate**. It accepts only the same Backend ID, verifies the new pinned TLS endpoint before sending the saved device credential, and commits only after that same device registration is confirmed. Cancelling or failed verification leaves the old pairing intact. Reopening Control still needs the device PIN. This does not renew the Backend certificate automatically or bypass its owner repair process.
