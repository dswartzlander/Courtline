const {JSDOM,ResourceLoader,VirtualConsole}=require('/workspace/scratch/4d9aa462dfa7/android_source/test-tools/node_modules/jsdom');const fs=require('fs'),path=require('path'),assert=require('assert/strict');
const dir=path.resolve(__dirname,'../Web'),clone=x=>JSON.parse(JSON.stringify(x));
const sections={vmix:{revision:'vmix-r1',value:{address:'http://192.0.2.50:8088'}}};
for(let i=0;i<4;i++)for(const [kind,value] of Object.entries({connection:{eventSlot:i,court:i+1,visible:true,remoteURL:'https://app.scoreholio.com/overlay?account=fixture-account&did=device'+i},event:{adminURL:'',name:'Event '+i},exports:{auto:false,seconds:60},matchup:{enabled:false},automation:{dry_run:true,poll_seconds:.5,alarm_delay:5,match_alerts:false,require_matchup_stats:false,rows:[{id:'a'+i,enabled:true,trigger:'Round complete',command:'Function=Cut&Input=2',delay:3,matchup:'singles'}]},telestrator:{source:'Camera '+(i+1),profile:{dry_run:false,rows:[{id:'t'+i,enabled:true,trigger:'Button press',command:'Function=Cut&Input=3',delay:0}]}}}))sections[kind+':'+i]={revision:kind+'-'+i+'-r1',value};
const snapshot=()=>clone({schemaVersion:1,sections,capabilities:{editable:Object.keys(sections),readOnly:[],actions:[],backendOnly:[],unavailable:[]},lock:{enabled:false,revision:''}});
const automation=Array.from({length:4},()=>({running:false,armed:false,status:{},alarms:[],logs:[],dry_run:true}));
let scanResult=null;let nativePrompts=0;let patches=[],calls=[],errors=[],offline=false,failAuth=false,n=1,holdGet=false,releaseGet=null,unsupported=0,saveWarning=false,rejectPatch=false,dropRestore=false;
class Loader extends ResourceLoader{fetch(url){const file=path.join(dir,new URL(url).pathname.split('/').pop());return fs.existsSync(file)?Promise.resolve(fs.readFileSync(file)):Promise.resolve(Buffer.from(''));}}
const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(fs.readFileSync(path.join(dir,'index.html'),'utf8'),{url:'https://courtline.test/index.html',runScripts:'dangerously',resources:new Loader(),pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
 w.matchMedia=()=>({matches:false,addEventListener(){},removeEventListener(){}});w.ResizeObserver=class{observe(){}disconnect(){}};w.confirm=()=>true;w.HTMLElement.prototype.scrollIntoView=function(){};w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;this.dispatchEvent(new w.Event('close'));};w.fetch=async()=>({ok:true,json:async()=>({})});
 const config={ui:{urls:['','','',''],pairings:[null,null,null,null],visibleCourts:[true,true,true,true],vmixInputs:['local-browser','','',''],telestratorSources:['','','',''],vmixHost:'http://192.0.2.9:8088',scoreholioStats:{helperURL:'http://192.0.2.40:8765/api/stats?key=fixture',auto:false,seconds:10}}};
 w.CourtlineAndroid={unlockSettings:()=>{nativePrompts++;},load:()=>JSON.stringify(config),save:()=>true,dispatch(text){const {method,args}=JSON.parse(text);calls.push({method,args});const [id,url,op,payload]=args;const reply=(value,error)=>setTimeout(()=>w.platformReply(id,value,error),0);
 if(['open','telestrator'].includes(method))return;
 if(method==='scanStatsHelper')return scanResult instanceof Error?reply(null,scanResult.message):reply(scanResult);
 if(method==='companion'){if(op==='session')return reply({role:'main',dataAuthority:'backend',settingsLock:{enabled:false,revision:''}});if(op==='getLive')return reply({snapshot:null,updatedAt:1,stale:false});return reply({holder:null,waiting:[],selection:{court:null,revision:0,pending:null,error:''}});}
 if(method==='settingsLock')return reply({enabled:false,revision:'',nativeUnlocked:true});
 if(method==='controlSettings'){
  if(offline)return reply(null,'Offline');if(op==='get'){if(unsupported===404)return reply({httpStatus:404,error:'Not found.'});const snap=snapshot();if(unsupported===99)snap.schemaVersion=99;if(holdGet){releaseGet=()=>reply(snap);return;}return reply(snap);}if(op==='state')return reply({automation,live:{},telestrator:{}});
  if(op==='action')return reply({ok:true,state:{automation}});
  if(op==='backup')return reply({format:'courtline-backend-settings',schemaVersion:1,createdAt:new Date().toISOString(),sections:Object.fromEntries(Object.entries(sections).map(([n,s])=>[n,clone(s.value)])),httpStatus:200});
  if(op==='restore'){
   if(payload.action==='preview'){w.fixtureRestore=payload.backup;return reply({previewId:'fixture-preview',changes:['vmix'],stagedSections:clone(payload.backup.sections),derivedEvents:[],automationWillStop:true,controlSettings:snapshot()});}
   if(rejectPatch)return reply({httpStatus:409,error:'Restore conflict',code:'conflict',controlSettings:snapshot()});
   for(const [n,v] of Object.entries(w.fixtureRestore.sections)){sections[n].value=clone(v);sections[n].revision='restored-'+(++nRestore);}
   if(dropRestore)return reply(null,'Connection lost after request');
   return reply({...snapshot(),restored:true,changed:true,automationStopped:true});
  }
  if(op==='patch'){patches.push(clone(payload));if(rejectPatch)return reply({httpStatus:400,error:'Fixture validation: choose a valid court'});if(failAuth)return reply({httpStatus:403,error:'Unlock expired'});const old=sections[payload.section];if(old.revision!==payload.expectedRevision)return reply({httpStatus:409,error:'Conflict',code:'conflict',controlSettings:snapshot()});old.value=clone(payload.value);old.revision='new-'+(++n);return reply({...snapshot(),...(saveWarning?{warning:'Settings saved; runtime needs Backend restart.'}:{})});}
 }
 if(method==='restoreLocalPreferences'){config.ui.vmixInputs=clone(op.vmixInputs);config.ui.autoRefresh=op.autoRefresh;config.ui.scoreholioStats.auto=op.statsAuto;config.ui.scoreholioStats.seconds=op.statsSeconds;return reply(clone(config));}
 if(method==='persistSettings')return reply(true);
 if(method==='statsHelper')return reply({records:[]});if(method==='request')return reply({status:200,text:'{}'});if(method==='checkUpdates')return reply({status:200,text:'[]'});
 reply(null,'Unsupported mock '+method);
 }};

 const mock=w.CourtlineAndroid;delete w.CourtlineAndroid;
 w.CourtlinePageID='ios-fixture-page';w.CourtlineIOS={sessionRole:()=>mock.sessionRole?.()||'main',settingsUnlocked:()=>mock.settingsUnlocked?.()??true};
 w.CourtlineNative={load:mock.load,save:mock.save,unlockSettings:()=>mock.unlockSettings?.(),switchRole:()=>{}};
 for(const name of ['open','telestrator','scanStatsHelper','statsHelper','statsAssignments','settingsLock','companion','controlSettings','restoreLocalPreferences','exportSettings','importSettings','persistSettings','snapshot','request','checkUpdates','downloadUpdate'])w.CourtlineNative[name]=(...args)=>mock.dispatch(JSON.stringify({pageId:w.CourtlinePageID,method:name,args}));
}});
let nRestore=0;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{await sleep(650);const w=dom.window,d=w.document,pair=d.getElementById('courtlineOptionsPair'),status=d.getElementById('courtlinePairStatus');assert.equal(errors.length,0);let before=0;
 for(const [code,expect] of [['PAIR_OFFLINE','could not be reached'],['PAIR_CONNECT','could not connect'],['PAIR_CHANGED','connection changed'],['PAIR_TRANSPORT_POLICY','network security'],['PAIR_TIMEOUT','in time'],['PAIR_LOCAL_NETWORK','Local Network'],['PAIR_NETWORK','Wi-Fi'],['PAIR_RESPONSE_INVALID','verify'],['PAIR_EXPIRED','expired'],['PAIR_STORAGE','securely'],['PAIR_INVALID_QR','not a valid'],['PAIR_BUSY','still open'],['PAIR_CAMERA_DENIED','Camera'],['PAIR_CAMERA_UNAVAILABLE','scanner'],['PAIR_BACKEND_REJECTED','did not accept'],['raw http://pc/api/stats?key=en_SECRET PIN=1234','not confirmed']]){
  scanResult=new Error(code);before=calls.filter(c=>c.method==='scanStatsHelper').length;pair.click();for(let i=0;i<100&&pair.disabled;i++)await sleep(5);assert.equal(calls.filter(c=>c.method==='scanStatsHelper').length,before+1);assert(status.textContent.includes(expect),status.textContent);assert(!status.textContent.includes('en_SECRET'));assert(!status.textContent.includes('1234'));assert(!d.getElementById('courtlineOptionsMenu').hidden);assert(!pair.disabled);
 }
 for(const [code,expect] of [["Pair this device using the enrollment QR first.", "This running app has no usable save"], ["Use the secure reconnect QR to keep this device registration.", "This app already has a registration"], ["Secure Backend identity could not be verified. Pairing unchanged.", "Secure Backend verification failed."], ["Backend did not confirm this device. Pairing unchanged.", "The secure Backend did not confirm "], ["Backend certificate differs. Scan its current reconnect QR and explicitly confirm replacement on this iPad. Existing pairing was kept.", "The scanned certificate differs fro"], ["Connection changed. Pairing unchanged.", "The app connection changed while ch"], ["Finish the current connection request first.", "Another connection request is in pr"], ["Use the secure pairing or migration QR on your Backend. HTTP fallback is disabled.", "This device requires the secure Bac"], ["Secure Backend connection failed. Check the network or rescan the trusted Backend QR.", "The secure connection failed. Check"], ["Secure Backend request timed out.", "The secure Backend request timed ou"], ["Connection cancelled.", "The connection was cancelled. Saved"], ["Invalid Backend response.", "The secure Backend response could n"], ["Invalid device credential.", "The Backend returned an invalid dev"], ["Invalid secure Backend address.", "The secure QR has an unsupported Ba"]]){
  scanResult=new Error(code);pair.click();for(let i=0;i<100&&pair.disabled;i++)await sleep(5);assert(status.textContent.includes(expect),status.textContent);
  scanResult=new Error(code+' http://pc/?key=en_SECRET PIN=1234');pair.click();for(let i=0;i<100&&pair.disabled;i++)await sleep(5);assert(status.textContent.includes('Pairing was not confirmed'));assert(!status.textContent.includes('en_SECRET'));assert(!status.textContent.includes('1234'));
 }
 for(const code of ["Confirm recovery from the trusted Backend device row first.", "Recovery may have completed before the app was interrupted. Ask the owner for a new recovery QR for this same device.", "Recovery was not confirmed. It may have completed on the Backend. Ask the owner for a new recovery QR for this same device; do not enroll a new device.", "Recovery returned an invalid credential. Ask the owner for a new recovery QR for this same device.", "Recovery completed on the Backend but could not be saved on this iPad. Ask the owner for a new recovery QR for this same device."]){scanResult=new Error(code);pair.click();for(let i=0;i<100&&pair.disabled;i++)await sleep(5);assert.equal(status.textContent,code);scanResult=new Error(code+" rc_SECRET");pair.click();for(let i=0;i<100&&pair.disabled;i++)await sleep(5);assert(!status.textContent.includes("rc_SECRET"));}
 for(const [state,label] of Object.entries({ready:'TCP path ready',localNetworkDenied:'local-network denial',wifiDenied:'Wi-Fi denial',cellularDenied:'cellular denial',notAvailable:'path not available',unavailable:'diagnostic unavailable',cancelled:'check cancelled',timeout:'check timed out'})){
  for(const bits of ['0:0:0:0','1:1:1:1','1:0:1:0']){
   scanResult=new Error('PAIR_OFFLINE_DETAIL:'+state+':'+bits);before=calls.filter(c=>c.method==='scanStatsHelper').length;pair.click();for(let i=0;i<100&&pair.disabled;i++)await sleep(5);
   assert(status.textContent.includes(label),status.textContent);const b=bits.split(':');
   assert(status.textContent.includes('usage description: '+(b[0]==='1'?'present':'absent')));
   assert(status.textContent.includes('constrained networks: '+(b[1]==='1'?'yes':'no')));
   assert(status.textContent.includes('expensive networks: '+(b[2]==='1'?'yes':'no')));
   assert(status.textContent.includes('waits for connectivity: '+(b[3]==='1'?'yes':'no')));
   assert.equal(calls.filter(c=>c.method==='scanStatsHelper').length,before+1);assert(!pair.disabled);
  }
 }
 for(const code of ['PAIR_OFFLINE_DETAIL:evil:1:1:1:1','PAIR_OFFLINE_DETAIL:ready:2:1:1:1','PAIR_OFFLINE_DETAIL:ready:1:1:1','PAIR_OFFLINE_DETAIL:ready:1:1:1:1:extra','PAIR_OFFLINE_DETAIL:ready:1:1:1:1\n','PAIR_OFFLINE_DETAIL:ready:1:1:1:1 http://pc/?key=en_SECRET PIN=1234']){
  scanResult=new Error(code);pair.click();for(let i=0;i<100&&pair.disabled;i++)await sleep(5);assert(status.textContent.includes('Pairing was not confirmed'));assert(!status.textContent.includes('en_SECRET'));assert(!status.textContent.includes('1234'));assert(!status.textContent.includes('TCP path'));
 }
 for(const value of [null,{paired:true,handled:true}]){scanResult=value;pair.click();for(let i=0;i<100&&pair.disabled;i++)await sleep(5);assert(status.textContent.includes(value===null?'canceled':'handled'));assert(!pair.disabled);}
 assert.equal(nativePrompts,0,'Pair action never invokes PIN');assert.equal(patches.length,0);assert.equal(errors.length,0);console.log('PASS actual Options→engine page-prefixed scan→native reply: bounded diagnostics, no raw ticket/PIN/URL, no retry, cancel/handled success and no Settings PIN gate.');w.close();})().catch(e=>{console.error(e);dom.window.close();process.exitCode=1;});
