import Foundation
import Security
import Network

// All state and completion handlers are confined to the main queue. Only the
// stable Companion credential is stored; Control and PIN grants stay in RAM.
final class CourtlineSessionBroker: NSObject, URLSessionTaskDelegate {
    struct Stamp { let page: String; let epoch: Int; let grant: Int }
    private(set) var page = UUID().uuidString
    private(set) var epoch = 0
    private(set) var grantEpoch = 0
    private(set) var ready = false
    private(set) var role = "viewer"
    private(set) var deviceID = ""
    private(set) var controlAllowed = false
    private(set) var pinAvailable = false
    private(set) var revoked = false
    private var origin: URL?
    private var lastDiagnosticOrigin:URL?
    var diagnosticSuggestedOrigin:String {(lastDiagnosticOrigin ?? origin)?.absoluteString ?? ""}
    private var viewerKey = ""
    #if COURTLINE_TESTING
    private var testPersist: ((URL,String,String,BackendTrust?)->Void)?
    #endif
    private var backendTrust: BackendTrust?
    private var secureRequests: [UUID:PinnedBackendRequest] = [:]
    private var discovery: BackendDiscovery?
    private var reconnecting = false
    private var nextDiscovery: TimeInterval = 0
    private var foreground = true
    private var connectionEpoch = 0
    func setForeground(_ value:Bool) {
        foreground=value
        if !value {connectionEpoch += 1;discovery?.cancel();discovery=nil;Array(secureRequests.values).forEach{$0.cancel()}}
    }
    private var mainKey = ""
    private var grant = ""
    private var revision = ""
    private var grantExpiry: Double?
    private var sessionBound = false
    private var busy = false
    private var actionUptime: () -> TimeInterval = { ProcessInfo.processInfo.systemUptime }
    private var pathProbe:(URL,@escaping(String)->Void)->Void = CourtlineSessionBroker.probePath
    var changed: (() -> Void)?
    var accessLost: (() -> Void)?
    private let keychainService = "com.cerberus.courtline.ipadtest.backend-pairing.v1"
    private lazy var network: URLSession = {
        let c = URLSessionConfiguration.ephemeral
        c.httpCookieStorage = nil; c.urlCache = nil
        c.requestCachePolicy = .reloadIgnoringLocalCacheData
        c.timeoutIntervalForRequest = 20; c.timeoutIntervalForResource = 320
        return URLSession(configuration: c, delegate: self, delegateQueue: nil)
    }()
    override init() { super.init(); restorePairing() }
    var helperURL: String { origin?.appendingPathComponent("api/stats").absoluteString ?? "" }
    var unlocked: Bool { role == "main" && !mainKey.isEmpty && !grant.isEmpty && (sessionBound || (grantExpiry ?? 0) > Date().timeIntervalSince1970 * 1000) }
    var stamp: Stamp { Stamp(page: page, epoch: epoch, grant: grantEpoch) }
    func valid(_ s: Stamp, mutation: Bool = false) -> Bool { s.page == page && s.epoch == epoch && (!mutation || s.grant == grantEpoch) }
    func newPage() -> String { page = UUID().uuidString; return page }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
    static func lanOrigin(_ text: String) -> URL? {
        guard let u = URLComponents(string: text), ["http","https"].contains(u.scheme?.lowercased() ?? ""), let h = u.host?.lowercased(), u.user == nil, u.password == nil, u.fragment == nil else { return nil }
        let labels = h.split(separator: ".", omittingEmptySubsequences: false)
        let v = labels.compactMap { Int($0) }
        let privateV4 = labels.count == 4 && labels.allSatisfy { !$0.isEmpty && $0.allSatisfy { $0.isASCII && $0.isNumber } } && v.count == 4 && v.allSatisfy { (0...255).contains($0) } && (v[0] == 10 || (v[0] == 192 && v[1] == 168) || (v[0] == 172 && (16...31).contains(v[1])))
        let localName = h.range(of:"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*\\.local$",options:.regularExpression) != nil
        guard privateV4 || localName else { return nil }
        guard u.port == nil || (1...65535).contains(u.port!) else { return nil }
        var clean = URLComponents(); clean.scheme = u.scheme?.lowercased(); clean.host = h; clean.port = u.port
        return clean.url
    }
    private func restorePairing() {
        let q: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:keychainService,kSecAttrAccount as String:"viewer",kSecReturnData as String:true,kSecMatchLimit as String:kSecMatchLimitOne]
        var item: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary,&item) == errSecSuccess, let d = item as? Data, let o = try? JSONSerialization.jsonObject(with:d) as? [String:String], let host = o["origin"], let key = o["viewerKey"], key.range(of:"^ds_[a-f0-9]{64}$",options:.regularExpression) != nil, let u = Self.lanOrigin(host) else { return }
        origin = u; viewerKey = key; deviceID = o["deviceId"] ?? ""
        if let id=o["backendId"],let pin=o["certificateSha256"],BackendTrust.valid(id,pin),u.scheme=="https" {backendTrust=BackendTrust(backendId:id,certificateSha256:pin)}
        else if o["backendId"] != nil || o["certificateSha256"] != nil {origin=nil;viewerKey=""}
    }
    private func persist(_ host: URL, _ key: String, _ id: String, trust:BackendTrust? = nil) throws {
        #if COURTLINE_TESTING
        if let hook=testPersist {hook(host,key,id,trust ?? backendTrust);return}
        #endif
        var record=["origin":host.absoluteString,"viewerKey":key,"deviceId":id]
        if let t=trust ?? backendTrust {record["backendId"]=t.backendId;record["certificateSha256"]=t.certificateSha256}
        let d = try JSONSerialization.data(withJSONObject:record)
        let q: [String:Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:keychainService,kSecAttrAccount as String:"viewer"]
        let attrs: [String:Any] = [kSecValueData as String:d,kSecAttrAccessible as String:kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        let result = SecItemUpdate(q as CFDictionary,attrs as CFDictionary)
        if result == errSecItemNotFound { var add=q;attrs.forEach{add[$0.key]=$0.value};guard SecItemAdd(add as CFDictionary,nil) == errSecSuccess else { throw failure("PAIR_STORAGE") } }
        else if result != errSecSuccess { throw failure("PAIR_STORAGE") }
    }
    private func failure(_ text: String) -> NSError { NSError(domain:"CourtLine",code:1,userInfo:[NSLocalizedDescriptionKey:text]) }
    private func clearControl() { mainKey="";grant="";revision="";grantExpiry=nil;sessionBound=false;role="viewer";grantEpoch += 1;epoch += 1;page=UUID().uuidString }
    func coldStart(_ done: @escaping (Error?) -> Void) {
        guard !busy else {done(failure("A connection request is already in progress."));return}
        clearControl(); ready=false
        guard origin != nil, !viewerKey.isEmpty else { done(nil);return }
        if let trust=backendTrust {reconnect(trust:trust,done:done)}
        else {sessionAction("reopen",fields:[:],done:done)}
    }
    struct CertificateReplacement {
        let oldPin:String
        let newPin:String
        fileprivate let oldTrust:BackendTrust
        fileprivate let text:String
        fileprivate let stamp:Stamp
        fileprivate let activity:Int
    }
    func certificateReplacement(_ text:String)->CertificateReplacement? {
        guard foreground,!busy,!reconnecting,!revoked,!viewerKey.isEmpty,
              let old=backendTrust,let qr=SecureBackendQR(text),qr.purpose=="migrate",
              qr.trust.backendId==old.backendId,qr.trust.certificateSha256 != old.certificateSha256 else{return nil}
        return CertificateReplacement(oldPin:old.certificateSha256,newPin:qr.trust.certificateSha256,oldTrust:old,text:text,stamp:stamp,activity:connectionEpoch)
    }
    func enroll(_ text: String, confirmedReplacement:CertificateReplacement? = nil, done: @escaping (Error?) -> Void) {
        if let qr=SecureBackendQR(text) {
            let replace=confirmedReplacement.map{ $0.text==text && $0.oldTrust==backendTrust && valid($0.stamp) && $0.activity==connectionEpoch } ?? false
            securePair(qr,replaceCertificate:replace,done:done);return
        }
        guard backendTrust == nil else{done(failure("Use the secure pairing or migration QR on your Backend. HTTP fallback is disabled."));return}
        guard let u=URLComponents(string:text), let host=Self.lanOrigin(text), u.path == "/api/stats", let pairs=u.queryItems, pairs.count==1, pairs[0].name=="key", let ticket=pairs[0].value, ticket.range(of:"^en_[a-f0-9]{64}$",options:.regularExpression) != nil else { done(failure("PAIR_INVALID_QR"));return }
        lastDiagnosticOrigin=host
        if host == origin && !viewerKey.isEmpty && !revoked { refreshSession { [weak self] error in guard let self=self else{return};if self.revoked {self.enroll(text,done:done)}else{done(error)} };return }
        guard !busy else { done(failure("PAIR_BUSY"));return };busy=true
        let captured=stamp
        fetch(host:host,key:ticket,path:"/api/device-session",body:["action":"enroll","platform":"ios","model":"iPad","appVersion":"1.0.12"],timeout:20){ [weak self] status,result,error in
            guard let self=self else{return};self.busy=false
            guard self.valid(captured) else {done(self.failure("PAIR_CHANGED"));return}
            if let error=error {
                let e=error as NSError
                let code:String
                if e.domain == "CourtLineTransport" && e.userInfo["sourceDomain"] as? String == "NSURLErrorDomain" {
                    if e.code == NSURLErrorNotConnectedToInternet {
                        self.busy=true
                        self.diagnoseOffline(host:host,captured:captured){message in self.busy=false;done(self.failure(message))};return
                    }
                    switch e.code {
                    case NSURLErrorAppTransportSecurityRequiresSecureConnection: code="PAIR_TRANSPORT_POLICY"
                    case NSURLErrorTimedOut: code="PAIR_TIMEOUT"
                    case NSURLErrorDataNotAllowed: code="PAIR_LOCAL_NETWORK"
                    case NSURLErrorNotConnectedToInternet: code="PAIR_OFFLINE"
                    case NSURLErrorCannotConnectToHost: code="PAIR_CONNECT"
                    default: code="PAIR_NETWORK"
                    }
                } else {code="PAIR_RESPONSE_INVALID"}
                done(self.failure(code));return
            }
            guard status==200 else { let code=result["code"] as? String ?? "";done(self.failure(["enrollment_invalid","enrollment_expired","enrollment_used"].contains(code) ? "PAIR_EXPIRED" : "PAIR_BACKEND_REJECTED"));return }
            guard let key=result["viewerKey"] as? String,key.range(of:"^ds_[a-f0-9]{64}$",options:.regularExpression) != nil,let id=result["deviceId"] as? String, let family=result["sessionId"] as? String, UUID(uuidString:family) != nil, id == "session_"+family, result["role"] as? String == "viewer", result["perDeviceControlPINs"] as? Bool == true else {done(self.failure("PAIR_RESPONSE_INVALID"));return}
            do {try self.persist(host,key,id);self.origin=host;self.viewerKey=key;self.deviceID=id;self.revoked=false;self.clearControl();self.ready=true;self.acceptMetadata(result);done(nil);self.changed?()}catch{done(error)}
        }
    }
    private func acceptMetadata(_ r: [String:Any]) { controlAllowed=r["controlAllowed"] as? Bool ?? controlAllowed;pinAvailable=r["pinAvailable"] as? Bool ?? r["rolePINAvailable"] as? Bool ?? pinAvailable;if let id=r["deviceId"] as? String {deviceID=id} }
    func promote(_ pin: String, done: @escaping (Error?) -> Void) {
        guard ready,!revoked,controlAllowed else {done(failure("Ask the Backend owner to enable Control for this device."));return}
        guard pinAvailable else {done(failure("Ask the Backend owner to set this device’s PIN."));return}
        guard pin.range(of:"^[0-9]{4,8}$",options:.regularExpression) != nil else {done(failure("Enter a 4–8 digit Device PIN."));return}
        sessionAction("promote-pin",fields:["pin":pin,"perDeviceControlPINs":true,"sessionBoundSettings":true],done:done)
    }
    func downgrade(_ done: @escaping (Error?) -> Void) { clearControl();ready=false;changed?();sessionAction("downgrade",fields:["confirmed":true],done:done) }
    private func sessionAction(_ action: String, fields: [String:Any], done: @escaping (Error?) -> Void) {
        guard let host=origin,!viewerKey.isEmpty,!revoked else{done(failure("Pair this device with Backend first."));return}
        guard !busy else {done(failure("Finish the current connection request first."));return};busy=true
        let captured=stamp,expectedDevice=deviceID;var body=fields;body["action"]=action
        fetch(host:host,key:viewerKey,path:"/api/device-session",body:body,timeout:20){[weak self] status,r,error in
            guard let self=self else{return};self.busy=false;guard self.valid(captured) else{done(self.failure("Device session changed."));return}
            guard error == nil,status==200 else {if r["code"] as? String == "device_revoked"{self.loseAccess()};done(error ?? self.failure(r["error"] as? String ?? "Backend could not confirm this change."));return}
            guard r["deviceId"] as? String == expectedDevice, let family=r["sessionId"] as? String, expectedDevice == "session_"+family, r["perDeviceControlPINs"] as? Bool == true else {done(self.failure("Backend returned a different device identity."));return}
            if action=="promote-pin" {
                guard r["role"] as? String == "main",let key=r["sessionKey"] as? String,key.range(of:"^ds_[a-f0-9]{64}$",options:.regularExpression) != nil else{done(self.failure("Control was not confirmed."));return}
                self.clearControl();self.acceptMetadata(r);self.ready=true;self.mainKey=key;self.role="main";self.acceptGrant(r["settingsGrant"] as? [String:Any])
            } else {
                guard r["role"] as? String == "viewer" else{done(self.failure("Companion was not confirmed."));return}
                self.clearControl();self.acceptMetadata(r);self.ready=true
            }
            done(nil);self.changed?()
        }
    }
    private func acceptGrant(_ g: [String:Any]?) {
        grant="";revision="";sessionBound=false;grantExpiry=nil;grantEpoch += 1
        guard role=="main",let g=g,let token=g["unlockToken"] as? String,!token.isEmpty,let rev=g["revision"] as? String,!rev.isEmpty else{return}
        let bound=g["sessionBound"] as? Bool == true && g["expiresAt"] is NSNull
        let expiry=(g["expiresAt"] as? NSNumber)?.doubleValue
        guard bound || (expiry ?? 0)>Date().timeIntervalSince1970*1000 else{return}
        grant=token;revision=rev;sessionBound=bound;grantExpiry=expiry
    }
    private func loseAccess() {let notify = !revoked;revoked=true;ready=false;clearControl();changed?();if notify{accessLost?()}}
    func refreshSession(_ done: @escaping (Error?) -> Void) {
        guard !busy else {done(failure("A connection request is already in progress."));return}
        guard let host=origin,!viewerKey.isEmpty,!revoked else{done(failure("Pair this device with Backend first."));return}
        if !ready {coldStart(done);return}
        let captured=stamp,key=mainKey.isEmpty ? viewerKey : mainKey
        fetch(host:host,key:key,path:"/api/session",body:nil,timeout:15){[weak self] status,r,error in
            guard let self=self,self.valid(captured) else{return}
            if status==401 && !self.mainKey.isEmpty {self.clearControl();self.ready=false;self.changed?();self.coldStart(done);return}
            if r["code"] as? String == "device_revoked" {self.loseAccess();done(self.failure("Access lost. Please see your administrator."));return}
            guard error==nil,status==200 else{
                if error != nil,let trust=self.backendTrust,self.foreground,ProcessInfo.processInfo.systemUptime>=self.nextDiscovery {self.reconnect(trust:trust,done:done);return}
                done(error ?? self.failure("Backend is unavailable."));return
            }
            self.acceptMetadata(r);self.applyPolicy(r["settingsLock"] as? [String:Any]);done(nil)
        }
    }
    private func applyPolicy(_ p: [String:Any]?) {if let p=p,!revision.isEmpty,revision != (p["revision"] as? String ?? ""){grant="";revision="";grantEpoch += 1}}
    func request(_ kind:String, action:String, payload:Any?, stamp captured:Stamp, done:@escaping ([String:Any]?,Error?)->Void) {
        guard valid(captured),ready,!revoked,let host=origin else{done(nil,failure("Backend pairing is not ready. Reconnect first."));return}
        var route="",body:[String:Any]?,mutation=false,needsControl=false,timeout:TimeInterval=25
        switch kind {
        case "companion":
            switch action {case "session":route="/api/session";case "getLive":route="/api/live";case "telestrator":route="/api/telestrator";body=payload as? [String:Any];body?["deviceId"]=deviceID;default:done(nil,failure("Backend owns live data."));return}
        case "statsHelper":route="/api/stats"
        case "settingsLock":
            guard let p=payload as? [String:Any],let a=p["action"] as? String,["policy","watch","lock"].contains(a) else{done(nil,failure("Use the native Device PIN screen."));return}
            route="/api/settings-lock";body=p;needsControl=true;mutation=a=="lock";body?["deviceId"]=deviceID;body?["unlockToken"]=grant
        case "controlSettings":
            let routes=["get":"/api/control-settings","state":"/api/control-state","patch":"/api/control-settings","action":"/api/control-actions","backup":"/api/control-backup","restore":"/api/control-restore"]
            guard let r=routes[action] else{done(nil,failure("Unsupported Backend operation."));return};route=r;needsControl=true;mutation=["patch","action","restore"].contains(action)
            if mutation {guard let p=payload as? [String:Any] else{done(nil,failure("Invalid request."));return};body=p;body?["deviceId"]=deviceID;body?["unlockToken"]=grant
                if ["refresh-stats","refresh-matchup"].contains(body?["action"] as? String ?? ""){timeout=300}
            }
        default:done(nil,failure("Unsupported Backend request."));return
        }
        guard !needsControl || role=="main" else{done(nil,failure("Companion cannot change settings."));return}
        guard valid(captured,mutation:mutation), !mutation || action=="lock" || unlocked else{done(nil,failure("Unlock Control settings with your Device PIN."));return}
        let credential=mainKey.isEmpty ? viewerKey : mainKey
        fetch(host:host,key:credential,path:route,body:body,timeout:timeout){[weak self] status,r,error in
            guard let self=self,self.valid(captured,mutation:mutation) else{return}
            if r["code"] as? String == "device_revoked"{self.loseAccess();done(nil,self.failure("Access lost. Please see your administrator."));return}
            if status==401 && !self.mainKey.isEmpty{self.clearControl();self.ready=false;self.changed?();done(nil,self.failure("Control access ended. Return to Companion and unlock again."));return}
            var result=r
            if status==200 {
                if kind=="settingsLock" {self.applyPolicy(r);if body?["action"] as? String == "lock"{self.grant="";self.revision="";self.grantEpoch += 1};result["nativeUnlocked"]=self.unlocked}
                if route=="/api/session"{self.acceptMetadata(r);self.applyPolicy(r["settingsLock"] as? [String:Any]);var policy=r["settingsLock"] as? [String:Any] ?? [:];policy["nativeUnlocked"]=self.unlocked;result["settingsLock"]=policy}
                result.removeValue(forKey:"unlockToken");result.removeValue(forKey:"sessionKey");result.removeValue(forKey:"viewerKey");result.removeValue(forKey:"settingsGrant")
            }
            result["httpStatus"]=status
            if let error=error{done(nil,error)}else{done(result,nil)}
        }
    }
    private func secureFetch(host:URL,trust:BackendTrust,key:String?,path:String,body:[String:Any]?,timeout:TimeInterval,done:@escaping(Int,[String:Any],Error?)->Void) {
        guard foreground else{done(0,[:],failure("Backend request paused while app is in background."));return}
        let id=UUID(),request=PinnedBackendRequest(trust:trust,origin:host);secureRequests[id]=request
        request.start(path:path,key:key,body:body,timeout:timeout){[weak self] status,result,error in self?.secureRequests.removeValue(forKey:id);done(status,result,error)}
    }
    private func verify(host:URL,trust:BackendTrust,done:@escaping(Bool)->Void) {
        secureFetch(host:host,trust:trust,key:nil,path:"/api/server-identity",body:nil,timeout:4){status,r,error in
            done(error==nil && status==200 && r["version"] as? Int==1 && (r["backendId"] as? String)?.lowercased()==trust.backendId.lowercased())
        }
    }
    private func securePair(_ qr:SecureBackendQR,replaceCertificate:Bool=false,done:@escaping(Error?)->Void) {
        guard !busy,!reconnecting,foreground else{done(failure("Finish the current connection request first."));return}
        if let existing=backendTrust,existing != qr.trust {
            guard replaceCertificate,qr.purpose=="migrate",existing.backendId==qr.trust.backendId else {
                done(failure("Backend certificate differs. Scan its current reconnect QR and explicitly confirm replacement on this iPad. Existing pairing was kept."));return
            }
        }
        if qr.purpose=="migrate" && (viewerKey.isEmpty || revoked) {done(failure("Pair this device using the enrollment QR first."));return}
        // A registered device uses migration, never silently creates a duplicate.
        if qr.purpose=="enroll" && !viewerKey.isEmpty && !revoked {done(failure("Use the secure reconnect QR to keep this device registration."));return}
        busy=true;let captured=stamp,expected=deviceID,activity=connectionEpoch
        verify(host:qr.origin,trust:qr.trust){[weak self] valid in
            guard let self=self else{return}
            guard self.valid(captured),self.connectionEpoch==activity,self.foreground,valid else{self.busy=false;done(self.failure("Secure Backend identity could not be verified. Pairing unchanged."));return}
            let migration=qr.purpose=="migrate"
            let key=migration ? self.viewerKey:qr.ticket!
            let body:[String:Any]=migration ? ["action":"reopen"]:["action":"enroll","platform":"ios","model":"iPad","appVersion":"1.0.12"]
            self.secureFetch(host:qr.origin,trust:qr.trust,key:key,path:"/api/device-session",body:body,timeout:20){status,r,error in
                self.busy=false
                guard self.valid(captured),self.connectionEpoch==activity,self.foreground else{done(self.failure("Connection changed. Pairing unchanged."));return}
                guard error==nil,status==200,r["role"] as? String=="viewer",r["perDeviceControlPINs"] as? Bool==true,
                      let family=r["sessionId"] as? String,UUID(uuidString:family) != nil,let id=r["deviceId"] as? String,id=="session_"+family,
                      !migration || id==expected else{done(error ?? self.failure("Backend did not confirm this device. Pairing unchanged."));return}
                let viewer=migration ? self.viewerKey:(r["viewerKey"] as? String ?? "")
                guard viewer.range(of:"^ds_[a-f0-9]{64}$",options:.regularExpression) != nil else{done(self.failure("Invalid device credential."));return}
                do {try self.persist(qr.origin,viewer,id,trust:qr.trust);self.backendTrust=qr.trust;self.origin=qr.origin;self.viewerKey=viewer;self.deviceID=id;self.revoked=false;self.clearControl();self.acceptMetadata(r);self.ready=true;done(nil);self.changed?()}catch{done(error)}
            }
        }
    }
    // Saved endpoint first. On transport failure, discover candidates without
    // secrets, verify the pinned server, then reopen only this registered family.
    private func reconnect(trust:BackendTrust,done:@escaping(Error?)->Void) {
        guard foreground,!busy,!reconnecting,!revoked,ProcessInfo.processInfo.systemUptime>=nextDiscovery,let saved=origin else{done(failure("Backend reconnect is unavailable."));return}
        reconnecting=true;busy=true;nextDiscovery=ProcessInfo.processInfo.systemUptime+30
        let captured=stamp,expected=deviceID,activity=connectionEpoch,key=viewerKey,wasReady=ready,activeKey=mainKey.isEmpty ? viewerKey:mainKey,deadline=ProcessInfo.processInfo.systemUptime+24
        func finish(_ error:Error?){self.reconnecting=false;self.busy=false;done(error)}
        func accept(_ candidate:URL) {
            guard self.valid(captured),self.connectionEpoch==activity,self.foreground else{finish(self.failure("Reconnect cancelled."));return}
            self.secureFetch(host:candidate,trust:trust,key:wasReady ? activeKey:key,path:wasReady ? "/api/session":"/api/device-session",body:wasReady ? nil:["action":"reopen"],timeout:8){status,r,error in
                guard self.valid(captured),self.connectionEpoch==activity,self.foreground else{finish(self.failure("Reconnect cancelled."));return}
                if r["code"] as? String=="device_revoked" {self.loseAccess();finish(self.failure("Access lost. Please see your administrator."));return}
                guard error==nil,status==200,r["deviceId"] as? String==expected,r["role"] as? String==(wasReady ? self.role:"viewer"),r["perDeviceControlPINs"] as? Bool==true else{finish(error ?? self.failure("Backend did not confirm this registered device."));return}
                do{try self.persist(candidate,key,expected,trust:trust);self.origin=candidate;if !wasReady {self.clearControl()};self.acceptMetadata(r);if wasReady {self.applyPolicy(r["settingsLock"] as? [String:Any])};self.ready=true;finish(nil);self.changed?()}catch{finish(error)}
            }
        }
        func candidates(_ values:[URL],_ index:Int) {
            guard self.valid(captured),self.connectionEpoch==activity,self.foreground,ProcessInfo.processInfo.systemUptime<deadline,index<min(values.count,3) else{finish(self.failure("Registered Backend not found on this network. Pairing was kept."));return}
            let candidate=values[index]
            self.verify(host:candidate,trust:trust){ok in if ok{accept(candidate)}else{candidates(values,index+1)}}
        }
        verify(host:saved,trust:trust){[weak self] ok in
            guard let self=self else{return}
            guard self.valid(captured),self.connectionEpoch==activity,self.foreground else{finish(self.failure("Reconnect cancelled."));return}
            if ok{accept(saved);return}
            let discovery=BackendDiscovery();self.discovery=discovery
            discovery.start(id:trust.backendId){[weak self] values in self?.discovery=nil;candidates(values.filter{$0 != saved},0)}
        }
    }
    // Dedicated explicit widget action. No caller-controlled method, function or headers.
    // The PC's canonical vMix address is re-read under the current Main credential
    // immediately before sending. Backend credentials never go to vMix.
    func sendWidget(slot:Int,input:String,widget:String,candidate:String,stamp captured:Stamp,canSend:@escaping()->Bool,done:@escaping([String:Any]?,Error?)->Void) {
        let deadline=actionUptime()+25
        let allowed = { canSend() && self.actionUptime()<deadline }
        guard (0...3).contains(slot),allowed(),valid(captured,mutation:true),ready,!revoked,role=="main",unlocked else {
            done(nil,failure("Unlock Control settings before sending a browser widget."));return
        }
        let targetInput=input.trimmingCharacters(in:.whitespacesAndNewlines)
        guard !targetInput.isEmpty,targetInput.count<=120,!targetInput.unicodeScalars.contains(where:CharacterSet.controlCharacters.contains),
              let w=URLComponents(string:widget),widget.utf8.count<=20000,w.scheme=="https",w.host=="app.scoreholio.com",w.user==nil,w.password==nil,w.port==nil,w.fragment==nil,
              let widgetURL=w.url,
              let c=URLComponents(string:candidate),c.query==nil,c.fragment==nil,["","/"].contains(c.path),let candidateOrigin=Self.lanOrigin(candidate) else {
            done(nil,failure("Use a valid vMix input, saved LAN address and Scoreholio HTTPS widget."));return
        }
        request("controlSettings",action:"get",payload:nil,stamp:captured){[weak self] result,error in
            guard let self=self else{return}
            guard allowed(),self.valid(captured,mutation:true),self.ready,!self.revoked,self.role=="main",self.unlocked else {
                done(nil,self.failure("Control or page changed. No widget was sent."));return
            }
            if let error=error {done(nil,error);return}
            guard let result=result,result["httpStatus"] as? Int==200,
                  let lock=result["lock"] as? [String:Any],lock["enabled"] as? Bool==true,lock["revision"] as? String==self.revision,
                  let sections=result["sections"] as? [String:Any],let vmix=sections["vmix"] as? [String:Any],let value=vmix["value"] as? [String:Any],
                  let stored=value["address"] as? String,let canonical=URLComponents(string:stored),canonical.query==nil,canonical.fragment==nil,["","/"].contains(canonical.path),
                  let host=Self.lanOrigin(stored),host==candidateOrigin else {
                done(nil,self.failure("Backend address or settings authorization changed. Pull settings and test the address before sending."));return
            }
            self.request("companion",action:"getLive",payload:nil,stamp:captured){[weak self] live,error in
                guard let self=self else{return}
                guard allowed(),self.valid(captured,mutation:true),self.ready,!self.revoked,self.role=="main",self.unlocked else {
                    done(nil,self.failure("Control, input or page changed. No widget was sent."));return
                }
                if let error=error{done(nil,error);return}
                guard let live=live,live["httpStatus"] as? Int==200,
                      let metadata=live["courts"] as? [[String:Any]],metadata.indices.contains(slot),metadata[slot]["stale"] as? Bool==false,
                      (metadata[slot]["error"] as? String ?? "").isEmpty,
                      let snapshot=live["snapshot"] as? [String:Any],let courts=snapshot["courts"] as? [[String:Any]],courts.indices.contains(slot),
                      courts[slot]["kind"] as? String=="assigned",courts[slot]["widgetUrl"] as? String==widgetURL.absoluteString,
                      let liveAddress=snapshot["vmixAddress"] as? String,Self.lanOrigin(liveAddress)==host else {
                    done(nil,self.failure("Court assignment or vMix address changed. Refresh before sending the widget."));return
                }
            var destination=URLComponents(url:host,resolvingAgainstBaseURL:false)!
            destination.path="/api/"
            destination.queryItems=[URLQueryItem(name:"Function",value:"BrowserNavigate"),URLQueryItem(name:"Input",value:targetInput),URLQueryItem(name:"Value",value:widgetURL.absoluteString)]
            guard let url=destination.url,allowed(),self.valid(captured,mutation:true),self.unlocked else {
                done(nil,self.failure("Control changed. No widget was sent."));return
            }
            var request=URLRequest(url:url,cachePolicy:.reloadIgnoringLocalCacheData,timeoutInterval:min(12,max(0.1,deadline-self.actionUptime())))
            request.httpMethod="GET"
            let task=self.network.dataTask(with:request){[weak self] data,response,error in DispatchQueue.main.async {
                guard let self=self else{return}
                guard self.valid(captured,mutation:true) else{return}
                guard self.actionUptime()<deadline else {
                    done(nil,self.failure("vMix confirmation arrived too late. The command may have been sent; it was not retried."));return
                }
                guard error==nil,let response=response as? HTTPURLResponse,let data=data,data.count<=1_000_000 else {
                    done(nil,self.failure("vMix did not confirm the widget command. It was not retried."));return
                }
                done(["status":response.statusCode,"text":String(decoding:data,as:UTF8.self)],nil)
            }}
            guard allowed(),self.valid(captured,mutation:true),self.unlocked else {task.cancel();done(nil,self.failure("Control changed. No widget was sent."));return}
            task.resume()
            }
        }
    }
    // A failed URLSession request is never retried here. This sends no HTTP or
    // credentials: a bounded TCP path check to the same already-validated origin.
    private func diagnoseOffline(host:URL,captured:Stamp,done:@escaping(String)->Void) {
        guard valid(captured),Self.lanOrigin(host.absoluteString)==host,
              host.host != nil else {done("PAIR_CHANGED");return}
        let c=network.configuration
        let usage=(Bundle.main.object(forInfoDictionaryKey:"NSLocalNetworkUsageDescription") as? String)?.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty == false
        let suffix=":"+(usage ? "1":"0")+":"+(c.allowsConstrainedNetworkAccess ? "1":"0")+":"+(c.allowsExpensiveNetworkAccess ? "1":"0")+":"+(c.waitsForConnectivity ? "1":"0")
        pathProbe(host){[weak self] state in
            guard let self=self,self.valid(captured) else{done("PAIR_CHANGED");return}
            let allowed=["ready","localNetworkDenied","wifiDenied","cellularDenied","notAvailable","unavailable","cancelled","timeout"]
            done("PAIR_OFFLINE_DETAIL:"+(allowed.contains(state) ? state:"unavailable")+suffix)
        }
    }
    private static func probePath(_ host:URL,done:@escaping(String)->Void) {
        guard Self.lanOrigin(host.absoluteString)==host,let name=host.host,
              let port=NWEndpoint.Port(rawValue:UInt16(host.port ?? (host.scheme=="https" ? 443:80))) else{done("unavailable");return}
        let connection=NWConnection(host:NWEndpoint.Host(name),port:port,using:.tcp)
        var finished=false
        func finish(_ state:String) {
            guard !finished else{return};finished=true
            connection.stateUpdateHandler=nil;connection.cancel()
            done(state)
        }
        connection.stateUpdateHandler={state in DispatchQueue.main.async {
            guard !finished else{return}
            switch state {
            case .ready:finish("ready")
            case .waiting,.failed:
                switch connection.currentPath?.unsatisfiedReason {
                case .localNetworkDenied?:finish("localNetworkDenied")
                case .wifiDenied?:finish("wifiDenied")
                case .cellularDenied?:finish("cellularDenied")
                case .notAvailable?:finish("notAvailable")
                default:finish("unavailable")
                }
            case .cancelled:finish("cancelled")
            default:break
            }
        }}
        connection.start(queue:DispatchQueue(label:"courtline.pairing.path"))
        DispatchQueue.main.asyncAfter(deadline:.now()+3){finish("timeout")}
    }
    private func fetch(host:URL,key:String,path:String,body:[String:Any]?,timeout:TimeInterval,done:@escaping(Int,[String:Any],Error?)->Void) {
        if let trust=backendTrust {secureFetch(host:host,trust:trust,key:key,path:path,body:body,timeout:timeout,done:done);return}
        var req=URLRequest(url:host.appendingPathComponent(String(path.dropFirst())),cachePolicy:.reloadIgnoringLocalCacheData,timeoutInterval:timeout)
        req.setValue(key,forHTTPHeaderField:"X-Courtline-Key");req.setValue("application/json",forHTTPHeaderField:"Accept")
        if let body=body{guard let d=try? JSONSerialization.data(withJSONObject:body),d.count<=4_000_000 else{done(0,[:],failure("Invalid or oversized request."));return};req.httpMethod="POST";req.httpBody=d;req.setValue("application/json",forHTTPHeaderField:"Content-Type")}
        network.dataTask(with:req){[weak self] data,response,error in DispatchQueue.main.async{
            guard let self=self else{return}
            if let error=error {done(0,[:],NSError(domain:"CourtLineTransport",code:(error as NSError).code,userInfo:[NSLocalizedDescriptionKey:"Cannot reach Backend. Check the shared Wi-Fi connection.","sourceDomain":(error as NSError).domain == NSURLErrorDomain ? "NSURLErrorDomain":"other"]));return}
            guard let data=data,data.count<=4_000_000,let response=response as? HTTPURLResponse,let result=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] else{done(0,[:],self.failure("Invalid Backend response."));return};done(response.statusCode,result,nil)
        }}.resume()
    }
}
