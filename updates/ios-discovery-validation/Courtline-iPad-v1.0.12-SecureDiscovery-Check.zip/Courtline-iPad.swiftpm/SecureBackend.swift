import Foundation
import Security
import CryptoKit
import Network

struct BackendTrust: Codable, Equatable {
    let backendId: String
    let certificateSha256: String
    static func valid(_ id: String, _ pin: String) -> Bool {
        UUID(uuidString:id) != nil && pin.range(of:"^[a-f0-9]{64}$",options:.regularExpression) != nil
    }
}
struct SecureBackendQR {
    let trust: BackendTrust
    let origin: URL
    let purpose: String
    let ticket: String?
    init?(_ text: String) {
        guard text.utf8.count <= 4096,let data=text.data(using:.utf8),
              let j=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any],
              j["type"] as? String == "courtline-secure",j["version"] as? Int == 1,
              let purpose=j["purpose"] as? String,["enroll","migrate"].contains(purpose),
              let id=j["backendId"] as? String,let pin=j["certificateSha256"] as? String,BackendTrust.valid(id,pin),
              let address=j["origin"] as? String,let c=URLComponents(string:address),c.scheme=="https",c.query==nil,c.fragment==nil,["","/"].contains(c.path),
              let origin=CourtlineSessionBroker.lanOrigin(address) else{return nil}
        let ticket=j["enrollmentKey"] as? String
        guard purpose=="enroll" ? ticket?.range(of:"^en_[a-f0-9]{64}$",options:.regularExpression) != nil : j["enrollmentKey"] == nil else{return nil}
        self.trust=BackendTrust(backendId:id.lowercased(),certificateSha256:pin);self.origin=origin;self.purpose=purpose;self.ticket=ticket
    }
}
// Explicit leaf validity check also covers self-signed anchors, whose dates
// platform trust implementations may treat differently from intermediates.
enum BackendCertificateDates {
    static func valid(_ data:Data,now:Date=Date())->Bool {
        let b=[UInt8](data)
        func node(_ offset:Int,_ limit:Int)->(UInt8,Range<Int>,Int)? {
            guard offset>=0,offset+2<=limit,limit<=b.count else{return nil}
            let tag=b[offset],first=Int(b[offset+1]);var length=first,start=offset+2
            if first>=128 {let count=first&127;guard count>0,count<=4,start+count<=limit,b[start] != 0 else{return nil};length=0
                for j in 0..<count {length=length*256+Int(b[start+j])};start += count;guard length>=128 else{return nil}}
            guard length>=0,length<=limit-start else{return nil};return(tag,start..<(start+length),start+length)
        }
        guard let cert=node(0,b.count),cert.0==0x30,cert.2==b.count,let tbs=node(cert.1.lowerBound,cert.1.upperBound),tbs.0==0x30 else{return false}
        var pos=tbs.1.lowerBound
        if let version=node(pos,tbs.1.upperBound),version.0==0xa0 {pos=version.2}
        for _ in 0..<3 {guard let field=node(pos,tbs.1.upperBound) else{return false};pos=field.2}
        guard let validity=node(pos,tbs.1.upperBound),validity.0==0x30,let first=node(validity.1.lowerBound,validity.1.upperBound),let last=node(first.2,validity.1.upperBound),last.2==validity.1.upperBound else{return false}
        func date(_ n:(UInt8,Range<Int>,Int))->Date? {
            guard let value=String(bytes:b[n.1],encoding:.ascii) else{return nil}
            let pattern=n.0==0x17 ? "^[0-9]{12}Z$":n.0==0x18 ? "^[0-9]{14}Z$":"!"
            guard value.range(of:pattern,options:.regularExpression) != nil else{return nil}
            var normalized=value
            if n.0==0x17 {let year=Int(value.prefix(2))!;normalized=(year>=50 ? "19":"20")+value}
            let f=DateFormatter();f.locale=Locale(identifier:"en_US_POSIX");f.calendar=Calendar(identifier:.gregorian);f.timeZone=TimeZone(secondsFromGMT:0);f.dateFormat="yyyyMMddHHmmss'Z'";f.isLenient=false
            guard let d=f.date(from:normalized),f.string(from:d)==normalized else{return nil};return d
        }
        guard let start=date(first),let end=date(last) else{return false};return start<=now && now<=end && start<end
    }
}
// One immutable trust/origin per operation. No redirects, cookies, credential
// storage, HTTP fallback or platform default trust after a pin mismatch.
final class PinnedBackendRequest: NSObject, URLSessionTaskDelegate {
    let trust: BackendTrust
    let origin: URL
    #if COURTLINE_TESTING
    static var testProtocols:[AnyClass]?
    #endif
    private var session: URLSession?
    private var task: URLSessionDataTask?
    private var completion: ((Int,[String:Any],Error?)->Void)?
    init(trust:BackendTrust,origin:URL) {self.trust=trust;self.origin=origin}
    static func error(_ message:String)->NSError {NSError(domain:"CourtLineSecure",code:1,userInfo:[NSLocalizedDescriptionKey:message])}
    func start(path:String,key:String?,body:[String:Any]?,timeout:TimeInterval,done:@escaping(Int,[String:Any],Error?)->Void) {
        guard origin.scheme=="https",CourtlineSessionBroker.lanOrigin(origin.absoluteString)==origin else{done(0,[:],Self.error("Invalid secure Backend address."));return}
        completion=done
        let c=URLSessionConfiguration.ephemeral
        #if COURTLINE_TESTING
        c.protocolClasses=Self.testProtocols
        #endif
        c.httpCookieStorage=nil;c.httpShouldSetCookies=false;c.urlCredentialStorage=nil;c.urlCache=nil
        c.allowsCellularAccess=false;c.waitsForConnectivity=false
        c.requestCachePolicy = .reloadIgnoringLocalCacheData;c.timeoutIntervalForRequest=timeout;c.timeoutIntervalForResource=timeout
        let session=URLSession(configuration:c,delegate:self,delegateQueue:nil);self.session=session
        var r=URLRequest(url:origin.appendingPathComponent(String(path.dropFirst())),cachePolicy:.reloadIgnoringLocalCacheData,timeoutInterval:timeout)
        r.setValue("application/json",forHTTPHeaderField:"Accept")
        if let key=key {r.setValue(key,forHTTPHeaderField:"X-Courtline-Key")}
        if let body=body {guard let d=try? JSONSerialization.data(withJSONObject:body),d.count<=4_000_000 else{finish(0,[:],Self.error("Invalid request."));return};r.httpBody=d;r.httpMethod="POST";r.setValue("application/json",forHTTPHeaderField:"Content-Type")}
        task=session.dataTask(with:r){[weak self] data,response,error in DispatchQueue.main.async {
            guard let self=self else{return}
            guard error==nil else{self.finish(0,[:],Self.error("Secure Backend connection failed. Check the network or rescan the trusted Backend QR."));return}
            guard let data=data,data.count<=4_000_000,let response=response as? HTTPURLResponse,let json=(try? JSONSerialization.jsonObject(with:data)) as? [String:Any] else{self.finish(0,[:],Self.error("Invalid Backend response."));return}
            self.finish(response.statusCode,json,nil)
        }}
        task?.resume()
        DispatchQueue.main.asyncAfter(deadline:.now()+timeout+1){[weak self] in self?.finish(0,[:],Self.error("Secure Backend request timed out."))}
    }
    private func finish(_ status:Int,_ result:[String:Any],_ error:Error?) {
        guard let done=completion else{return};completion=nil;task?.cancel();task=nil;session?.invalidateAndCancel();session=nil;done(status,result,error)
    }
    func cancel(){finish(0,[:],Self.error("Connection cancelled."))}
    func urlSession(_ session:URLSession,task:URLSessionTask,willPerformHTTPRedirection response:HTTPURLResponse,newRequest request:URLRequest,completionHandler:@escaping(URLRequest?)->Void){completionHandler(nil)}
    func urlSession(_ session:URLSession,task:URLSessionTask,didReceive challenge:URLAuthenticationChallenge,completionHandler:@escaping(URLSession.AuthChallengeDisposition,URLCredential?)->Void) {
        guard challenge.protectionSpace.authenticationMethod==NSURLAuthenticationMethodServerTrust,
              challenge.protectionSpace.host.lowercased()==origin.host?.lowercased(),
              let serverTrust=challenge.protectionSpace.serverTrust,let cert=SecTrustGetCertificateAtIndex(serverTrust,0) else{completionHandler(.cancelAuthenticationChallenge,nil);return}
        guard Self.validate(serverTrust:serverTrust,cert:cert,pin:trust.certificateSha256) else{completionHandler(.cancelAuthenticationChallenge,nil);return}
        completionHandler(.useCredential,URLCredential(trust:serverTrust))
    }
    static func validate(serverTrust:SecTrust,cert:SecCertificate,pin:String)->Bool {
        let der=SecCertificateCopyData(cert) as Data
        guard BackendCertificateDates.valid(der) else{return false}
        let hash=SHA256.hash(data:der).map{String(format:"%02x",$0)}.joined()
        guard hash==pin else{return false}
        // Exact QR-pinned certificate provides server identity across IP changes.
        // X509 evaluation still checks dates and TLS server usage, not a volatile IP.
        SecTrustSetPolicies(serverTrust,SecPolicyCreateSSL(true,nil))
        SecTrustSetAnchorCertificates(serverTrust,[cert] as CFArray)
        SecTrustSetAnchorCertificatesOnly(serverTrust,true)
        SecTrustSetNetworkFetchAllowed(serverTrust,false)
        guard SecTrustEvaluateWithError(serverTrust,nil) else{return false}
        return true
    }

}

// Advertisements identify candidates only, never trust. No address sweeps and no
// credential is transmitted by discovery. Caller verifies TLS + Backend ID.
final class BackendDiscovery: NSObject, NetServiceBrowserDelegate, NetServiceDelegate {
    private let browser=NetServiceBrowser()
    private var services:[NetService]=[]
    private var candidates:[URL]=[]
    private var completion:(([URL])->Void)?
    private var backendId=""
    private var monitor:NWPathMonitor?
    func start(id:String,done:@escaping([URL])->Void) {
        backendId=id.lowercased();completion=done
        let monitor=NWPathMonitor();self.monitor=monitor
        monitor.pathUpdateHandler={[weak self] path in DispatchQueue.main.async {
            guard let self=self,self.completion != nil else{return};self.monitor?.cancel();self.monitor=nil
            guard path.status == .satisfied,(path.usesInterfaceType(.wifi)||path.usesInterfaceType(.wiredEthernet)) else{self.finish();return}
            self.browser.delegate=self;self.browser.searchForServices(ofType:"_courtline._tcp.",inDomain:"local.")
        }}
        monitor.start(queue:DispatchQueue(label:"courtline.discovery.path"))
        DispatchQueue.main.asyncAfter(deadline:.now()+8){[weak self] in self?.finish()}
    }
    func cancel(){finish()}
    private func finish(){guard let done=completion else{return};completion=nil;monitor?.cancel();monitor=nil;browser.stop();browser.delegate=nil;services.forEach{$0.stop();$0.delegate=nil};services=[];done(candidates)}
    func netServiceBrowser(_ browser:NetServiceBrowser,didFind service:NetService,moreComing:Bool){guard completion != nil,services.count<16 else{return};services.append(service);service.delegate=self;service.resolve(withTimeout:3)}
    func netServiceBrowser(_ browser:NetServiceBrowser,didNotSearch errorDict:[String:NSNumber]){finish()}
    func netServiceDidResolveAddress(_ sender:NetService){
        guard completion != nil,let data=sender.txtRecordData() else{return}
        let txt=NetService.dictionary(fromTXTRecord:data)
        func value(_ k:String)->String{txt[k].flatMap{String(data:$0,encoding:.utf8)} ?? ""}
        guard value("v")=="1",value("tls")=="1",value("id").lowercased()==backendId,let name=sender.hostName,(1...65535).contains(sender.port) else{return}
        var c=URLComponents();c.scheme="https";c.host=name.hasSuffix(".") ? String(name.dropLast()):name;c.port=sender.port
        guard let u=c.url,let origin=CourtlineSessionBroker.lanOrigin(u.absoluteString),!candidates.contains(origin) else{return};candidates.append(origin)
    }
}
