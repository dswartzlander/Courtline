Unreleased diagnostic candidate based on CourtLine1.0.13. Same bundle and pairing identity: do not install alongside or replace live project without preserving it. Adds runtime ATS flag and fixed bounded identity verification stage/error domain+code only. No error descriptions, response contents, tickets or keys logged. Transport/security unchanged. Not a release.

Diagnostic2 (build1132) repairs the Options error formatter with an exact prefix and bounded stage/domain/numeric grammar. Unknown, malformed, oversized or appended text still uses the generic safe fallback. No native transport changes from Diagnostic1.


Diagnostic3 corrects Diagnostic2 packaging: embedded Web resources regenerated and checked byte-for-byte against editable Web sources. Tests run on decoded shipping resources. Security/transport/registration unchanged.
