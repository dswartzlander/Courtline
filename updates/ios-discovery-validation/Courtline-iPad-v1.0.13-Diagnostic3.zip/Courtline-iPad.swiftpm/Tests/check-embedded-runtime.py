"""Validate shipping embedded bytes, then run regression tests on extracted bytes."""
import base64,pathlib,re,tempfile,shutil,subprocess
root=pathlib.Path(__file__).resolve().parent.parent
source=(root/'CourtlineResources.swift').read_text()
pairs=re.findall(r'        "([^"/]+)": """\n(.*?)\n        """',source,re.S)
assert pairs and len(pairs)==len(dict(pairs)), 'Missing or duplicate embedded files'
files={n:base64.b64decode(''.join(v.split()),validate=True) for n,v in pairs}
expected={p.name:p.read_bytes() for p in (root/'Web').iterdir() if p.is_file()}
assert files.keys()==expected.keys(),'Embedded file inventory mismatch'
for n,b in files.items():assert b==expected[n],f'Embedded/source mismatch: {n}'
print(f'PASS: all {len(files)} embedded resources match Web source',flush=True)
assert b'const verification=' in files['courtline-options.js'],'Missing diagnostic stage renderer'
with tempfile.TemporaryDirectory(prefix='courtline-shipping-test-') as d:
 p=pathlib.Path(d);(p/'Web').mkdir();shutil.copytree(root/'Tests',p/'Tests')
 for n,b in files.items():(p/'Web'/n).write_bytes(b)
 for n in ['ios107-pairing-handled.cjs','ios109-pair-errors.cjs','ios110-native-diagnostics.cjs','ios111-options-diagnostics.cjs','ios111-native-health.cjs']:
  # Source-contract checks also read native files; copy unchanged shipping Swift sources.
  for f in root.glob('*.swift'):shutil.copyfile(f,p/f.name)
  subprocess.run(['node',str(p/'Tests'/n)],cwd=p,check=True,timeout=60)
print('PASS: five tests executed against decoded shipping Web resources')
