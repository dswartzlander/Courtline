import Foundation
import MachO

// Read-only, credential-free diagnostics. Never use this transport for app APIs.
final class ConnectionDiagnostics:NSObject,URLSessionDataDelegate {
    private var session:URLSession?
    private var task:URLSessionDataTask?
    private var deadline:DispatchWorkItem?
    private var completion:((String)->Void)?
    private var finished=false
    private var observations:[String]=[]
    private var configuration:()->URLSessionConfiguration = {.ephemeral}
    static func identity()->String {
        let b=Bundle.main
        func safe(_ v:String?)->String {String((v ?? "unavailable").unicodeScalars.filter{!CharacterSet.controlCharacters.contains($0)}.prefix(160))}
        let usage=(b.object(forInfoDictionaryKey:"NSLocalNetworkUsageDescription") as? String)?.trimmingCharacters(in:.whitespacesAndNewlines).isEmpty == false
        return "OS: "+safe(ProcessInfo.processInfo.operatingSystemVersionString)+"\nBundle: "+safe(b.bundleIdentifier)+"\nName: "+safe(b.object(forInfoDictionaryKey:"CFBundleDisplayName") as? String ?? b.object(forInfoDictionaryKey:"CFBundleName") as? String)+"\nVersion: "+safe(b.object(forInfoDictionaryKey:"CFBundleShortVersionString") as? String)+" ("+safe(b.object(forInfoDictionaryKey:"CFBundleVersion") as? String)+")\nProcess: "+safe(ProcessInfo.processInfo.processName)+"\nExecutable UUID: "+executableUUID()+"\nLocal Network description: "+(usage ? "present":"missing")+"\nEffective ATS: "+atsSummary(b)
    }
    private static func atsSummary(_ bundle:Bundle)->String {
        guard let ats=bundle.object(forInfoDictionaryKey:"NSAppTransportSecurity") as? [String:Any] else{return "dictionary absent"}
        let keys=["NSAllowsLocalNetworking","NSAllowsArbitraryLoads","NSAllowsArbitraryLoadsInWebContent","NSAllowsArbitraryLoadsForMedia"]
        return keys.map { key in
            guard let value=ats[key] else{return key+"=absent"}
            guard let number=value as? NSNumber else{return key+"=non-boolean"}
            return key+"="+(number.boolValue ? "true":"false")
        }.joined(separator:", ")+"; exceptionDomains="+(ats["NSExceptionDomains"] == nil ? "absent":"present")
    }
    private static func executableUUID()->String {
        guard let header=_dyld_get_image_header(0),header.pointee.magic==MH_MAGIC_64 else{return "unavailable"}
        let h=UnsafeRawPointer(header).assumingMemoryBound(to:mach_header_64.self).pointee
        var cursor=UnsafeRawPointer(header).advanced(by:MemoryLayout<mach_header_64>.size)
        var remaining=Int(h.sizeofcmds)
        for _ in 0..<h.ncmds {
            guard remaining>=MemoryLayout<load_command>.size else{return "unavailable"}
            let c=cursor.assumingMemoryBound(to:load_command.self).pointee,size=Int(c.cmdsize)
            guard size>=MemoryLayout<load_command>.size,size<=remaining else{return "unavailable"}
            if c.cmd==LC_UUID,size>=MemoryLayout<uuid_command>.size{return UUID(uuid:cursor.assumingMemoryBound(to:uuid_command.self).pointee.uuid).uuidString}
            cursor=cursor.advanced(by:size);remaining -= size
        }
        return "unavailable"
    }
    static func origin(_ text:String)->URL? {
        guard let u=URLComponents(string:text.trimmingCharacters(in:.whitespacesAndNewlines)),u.query==nil,u.fragment==nil,["","/"].contains(u.path) else{return nil}
        return LANOrigin.parse(text.trimmingCharacters(in:.whitespacesAndNewlines))
    }
    func start(origin:URL,waitForConnectivity:Bool=true,done:@escaping(String)->Void) {
        guard Self.origin(origin.absoluteString)==origin else{done("Invalid LAN origin. Use http://PC-IP:port without a path or key.");return}
        completion=done
        let c=configuration();c.httpCookieStorage=nil;c.urlCredentialStorage=nil;c.urlCache=nil;c.httpShouldSetCookies=false
        c.requestCachePolicy = .reloadIgnoringLocalCacheData;c.waitsForConnectivity=waitForConnectivity;c.timeoutIntervalForRequest=15;c.timeoutIntervalForResource=20
        observations=["Session: ephemeral; waitsForConnectivity=\(c.waitsForConnectivity); constrained=\(c.allowsConstrainedNetworkAccess); expensive=\(c.allowsExpensiveNetworkAccess); cellular=\(c.allowsCellularAccess); requestTimeout=15s; resourceDeadline=20s; no credentials/cookies."]
        session=URLSession(configuration:c,delegate:self,delegateQueue:OperationQueue.main)
        var req=URLRequest(url:origin.appendingPathComponent("api/session"));req.httpMethod="GET";req.timeoutInterval=15;req.httpShouldHandleCookies=false
        task=session?.dataTask(with:req)
        let timer=DispatchWorkItem{[weak self] in self?.finish("Deadline reached after 20 seconds. No enrollment was attempted.")};deadline=timer
        DispatchQueue.main.asyncAfter(deadline:.now()+20,execute:timer);task?.resume()
    }
    func cancel(){finish("Check cancelled. No enrollment was attempted.")}
    private func finish(_ text:String) {
        guard !finished else{return};finished=true;deadline?.cancel();deadline=nil;task?.cancel();task=nil
        session?.invalidateAndCancel();session=nil;let done=completion;completion=nil;done?((observations+[text]).joined(separator:"\n"))
    }
    func urlSession(_ session:URLSession,dataTask:URLSessionDataTask,didReceive response:URLResponse,completionHandler:@escaping(URLSession.ResponseDisposition)->Void) {
        // Record the header result before cancelling. A cancellation completion
        // must never overwrite an already received HTTP status.
        if let r=response as? HTTPURLResponse {finish("HTTP "+String(r.statusCode)+". Any HTTP response, including 401, confirms native reachability. Response body was not read.")}
        else{finish("No HTTP response. No enrollment was attempted.")}
        completionHandler(.cancel)
    }
    func urlSession(_ session:URLSession,task:URLSessionTask,didCompleteWithError error:Error?) {
        guard !finished else{return}
        if let e=error as NSError? {let domain=e.domain==NSURLErrorDomain ? "NSURLErrorDomain":"other";let underlying=e.userInfo[NSUnderlyingErrorKey] as? NSError
            if let u=underlying {let allowed=[NSURLErrorDomain,NSPOSIXErrorDomain,"kCFErrorDomainCFNetwork"];observations.append("Underlying error: "+(allowed.contains(u.domain) ? u.domain:"other")+" "+String(u.code))}
            finish("Native request failed: "+domain+" "+String(e.code)+". No enrollment was attempted.")}
        else{finish("Request ended without an HTTP response. No enrollment was attempted.")}
    }
    func urlSession(_ session:URLSession,taskIsWaitingForConnectivity task:URLSessionTask) {
        guard !finished else{return};observations.append("URLSession entered waitingForConnectivity.")
    }
    func urlSession(_ session:URLSession,task:URLSessionTask,didFinishCollecting metrics:URLSessionTaskMetrics) {
        guard !finished else{return}
        observations.append("Metrics: transactions="+String(metrics.transactionMetrics.count)+"; redirects="+String(metrics.redirectCount))
        if let m=metrics.transactionMetrics.last {
            observations.append("Last transaction: connectStarted=\(m.connectStartDate != nil); connectEnded=\(m.connectEndDate != nil); responseStarted=\(m.responseStartDate != nil); cellular=\(m.isCellular); proxy=\(m.isProxyConnection)")
        }
    }
    func urlSession(_ session:URLSession,task:URLSessionTask,willPerformHTTPRedirection response:HTTPURLResponse,newRequest request:URLRequest,completionHandler:@escaping(URLRequest?)->Void) {
        finish("HTTP "+String(response.statusCode)+" redirect refused. No redirected request or enrollment was attempted.");completionHandler(nil)
    }
}
