# CourtLine Network Test 1.1

A separate, read-only comparison project, not a CourtLine update or network-permission workaround. It uses a distinct bundle identifier and may create a separate Local Network permission entry. The owner decides whether to run it and grant permission.

Open the SwiftPM project in Swift Playgrounds. Enter the PC LAN origin (http://IP:port, no key/path) and tap Test Connection. No network activity occurs automatically. The endpoint is /api/session. Expected Backend response is HTTP401; it proves native reachability, not authentication. A -1009 result or HTTP deadline additionally triggers one bounded, data-free TCP observation against the same entered host/port. The maximum configured HTTP deadline is20seconds and TCP observation3seconds.

No QR, pairing, PIN, Keychain, CourtLine settings, cookies, persistent storage, automatic retries, or response-body display. No CourtLine project is imported or modified. The address is memory-only. No public host, loopback, credentials, query, or fragment is accepted. Redirects are refused.

If this separate project works while CourtLine fails, it narrows the issue toward the existing project/runtime identity or configuration; it does not prove a specific OS bug. If both fail, it narrows the issue toward the shared Playgrounds/OS environment. Do not use the project to carry app traffic.

Validation: exact-package Apple SDK and fake-network runtime results are supplied separately. Physical iPad permission behavior remains untested until the owner runs it. Swift Playgrounds may generate a development bundle identifier different from the manifest, shown in the diagnostics.

Current reported environment for comparison: Swift Playgrounds4.7 and iPadOS26.6.2, as stated by the owner. The app displays the OS version actually reported at runtime; it does not guess or detect the Playgrounds version. Copy Diagnostics copies only the displayed safe identity/result text, not the address or credentials.

Leaving the view or becoming background cancels the check. Inactive system prompts do not cancel the bounded request. Compare the default waiting-enabled run with an explicit fresh run after permissions settle; the optional toggle allows a waiting-disabled comparison. There is no automatic retry, and this instruction does not promise permission will take effect.

Effective ATS booleans, runtime identity, session flags, sanitized underlying error domain/code, waiting state and available connection metrics are displayed. Metrics may be absent when cancellation happens before delivery; absence is not evidence no packets were sent. No raw error dictionaries, URLs, bodies, device settings or secrets are copied. Source ATS remains unchanged; no relaxation.
