import Foundation
import Network

enum PathObservation {
    static func observe(_ host:URL,done:@escaping(String)->Void)->()->Void {
        guard LANOrigin.parse(host.absoluteString)==host,let name=host.host,
              let port=NWEndpoint.Port(rawValue:UInt16(host.port ?? (host.scheme=="https" ? 443:80))) else{done("unavailable");return {}}
        let connection=NWConnection(host:NWEndpoint.Host(name),port:port,using:.tcp)
        var finished=false
        func finish(_ state:String) {
            guard !finished else{return};finished=true
            connection.stateUpdateHandler=nil;connection.cancel()
            done(state)
        }
        connection.stateUpdateHandler={state in DispatchQueue.main.async {
            guard !finished else{return}
            switch state {
            case .ready:finish("ready")
            case .waiting,.failed:
                switch connection.currentPath?.unsatisfiedReason {
                case .localNetworkDenied?:finish("localNetworkDenied")
                case .wifiDenied?:finish("wifiDenied")
                case .cellularDenied?:finish("cellularDenied")
                case .notAvailable?:finish("notAvailable")
                default:finish("unavailable")
                }
            case .cancelled:finish("cancelled")
            default:break
            }
        }}
        connection.start(queue:DispatchQueue(label:"courtline.pairing.path"))
        DispatchQueue.main.asyncAfter(deadline:.now()+3){finish("timeout")}
        return {finish("cancelled")}
    }
}
