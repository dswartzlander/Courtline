import Foundation
import Combine

final class NetworkTestModel:ObservableObject {
    @Published var busy=false
    @Published var waitForConnectivity=true
    @Published var result="No request has been made."
    private var probe:ConnectionDiagnostics?
    private var makeProbe:()->ConnectionDiagnostics = {ConnectionDiagnostics()}
    private var generation=0
    private var active=true
    private var cancelPath:(()->Void)?
    private var observe:(URL,@escaping(String)->Void)->()->Void = PathObservation.observe
    func setActive(_ value:Bool) {
        active=value
        guard !value else{return}
        generation += 1;probe?.cancel();probe=nil;cancelPath?();cancelPath=nil
        if busy {result="Check cancelled after leaving this view. Tap Test to start a new check."}
        busy=false
    }
    func test(_ text:String) {
        guard active,!busy else{return}
        guard let origin=ConnectionDiagnostics.origin(text) else{result="Enter a private LAN IP or .local host, with optional port. No path, key, username, or query is allowed.";return}
        busy=true;generation += 1;let own=generation
        result="Checking the address you entered. No credentials are sent."
        let p=makeProbe();probe=p
        p.start(origin:origin,waitForConnectivity:waitForConnectivity){[weak self] text in
            guard let self=self,self.generation==own else{return}
            self.probe=nil
            guard text.contains("NSURLErrorDomain -1009.") || text.contains("Deadline reached") else{self.result=text;self.busy=false;return}
            self.cancelPath=self.observe(origin){[weak self] state in
                guard let self=self,self.generation==own else{return}
                let allowed=["ready","localNetworkDenied","wifiDenied","cellularDenied","notAvailable","unavailable","cancelled","timeout"]
                self.result=text+"\nEndpoint path observation: "+(allowed.contains(state) ? state:"unavailable")+". This observation is not a diagnosis of the cause."
                self.busy=false
            }
        }
    }
}
