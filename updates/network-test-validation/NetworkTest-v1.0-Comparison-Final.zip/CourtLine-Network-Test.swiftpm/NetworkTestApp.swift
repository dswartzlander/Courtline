import SwiftUI
import UIKit

@main struct NetworkTestApp:App {
    var body:some Scene {WindowGroup {NetworkTestView()}}
}
struct NetworkTestView:View {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var model=NetworkTestModel()
    @State private var address=""
    var body:some View {
        NavigationStack {
            Form {
                Section("Separate diagnostic, not a repair") {
                    Text("This project has its own identity and may ask for Local Network permission. It does not open, modify, or pair your CourtLine app. No request runs until you tap Test.")
                    Text("Test sends one unauthenticated GET to /api/health. If the OS reports -1009, it also makes one bounded TCP connection to the same address without sending data. No QR, PIN, credentials, or response body are read.")
                }
                Section("PC address") {
                    TextField("http://PC-IP:port",text:$address).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL).disabled(model.busy)
                    Button(model.busy ? "Testing…":"Test Connection") {model.test(address)}.disabled(model.busy)
                }
                Section("Result") {
                    Text(model.result).textSelection(.enabled)
                    Button("Copy Diagnostics") {UIPasteboard.general.string=ConnectionDiagnostics.identity()+"\n\n"+model.result}
                }
                Section("This running project") {Text(ConnectionDiagnostics.identity()).font(.system(.footnote,design:.monospaced)).textSelection(.enabled)}
                Section {Text("HTTP 401 is expected from an unauthenticated Backend and confirms reachability, not permission to control it. A failed test does not change your CourtLine settings. No automatic retries or saved addresses. If a permission prompt cancels the check, choose whether to Allow, then tap Test again after returning.")}
            }.navigationTitle("CourtLine Network Test")
             .onChange(of:scenePhase){phase in model.setActive(phase == .active)}
             .onDisappear{model.setActive(false)}
             .onAppear{model.setActive(scenePhase == .active)}
        }
    }
}
