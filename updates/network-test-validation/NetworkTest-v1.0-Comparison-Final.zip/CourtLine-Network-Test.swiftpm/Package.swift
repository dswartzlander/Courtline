// swift-tools-version: 5.9
import PackageDescription
import AppleProductTypes
let package = Package(
 name: "CourtLine Network Test",
 platforms: [.iOS("18.0")],
 products: [.iOSApplication(name: "CourtLine Network Test", targets: ["NetworkTest"],
 bundleIdentifier: "com.cerberus.courtline.networkdiagnostic", displayVersion: "1.0", bundleVersion: "1",
 appIcon: .placeholder(icon: .star), accentColor: .presetColor(.blue), supportedDeviceFamilies: [.pad],
 supportedInterfaceOrientations: [.portrait, .portraitUpsideDown, .landscapeLeft, .landscapeRight],
 capabilities: [.localNetwork(purposeString: "This separate diagnostic checks the PC address you enter. It does not pair with CourtLine or access your settings.")],
 additionalInfoPlistContentFilePath: "AppInfo.plist")],
 targets: [.executableTarget(name: "NetworkTest", path: ".", exclude: ["AppInfo.plist", "README.md"])],
 swiftLanguageVersions: [.v5]
)
